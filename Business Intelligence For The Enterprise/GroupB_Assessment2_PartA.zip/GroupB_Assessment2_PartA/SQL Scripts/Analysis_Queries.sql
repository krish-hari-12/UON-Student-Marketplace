--Store Performance By Month
USE FinalStage;
GO

SELECT 
    ds.store_location,
    dd.month,
    dd.year,
    COUNT(DISTINCT f.transaction_id) AS transaction_count,
    ROUND(SUM(f.line_total), 2) AS total_revenue,
    ROUND(SUM(f.line_total) / COUNT(DISTINCT f.transaction_id), 2) AS avg_transaction_value,
    ROUND(SUM(CASE WHEN dc.loyalty_member = 'Yes' THEN 1.0 ELSE 0 END) / COUNT(f.transaction_id) * 100, 2) AS loyalty_transaction_pct,
    ROUND(SUM(f.discount_applied), 2) AS total_discount_applied
FROM fact_sales f
INNER JOIN dim_store ds ON f.store_key = ds.store_key
INNER JOIN dim_date dd ON f.date_key = dd.date_key
LEFT JOIN dim_customer dc ON f.customer_key = dc.customer_key
WHERE dd.year = 2025 AND dd.month IN (3, 4)
GROUP BY ds.store_location, dd.month, dd.year
ORDER BY ds.store_location, dd.year, dd.month;

--Employee Performance
SELECT TOP 5
    de.employee_id,
    de.first_name,
    de.last_name,
    de.role,
    ds.store_location AS primary_store,
    COUNT(DISTINCT f.transaction_id) AS transaction_count,
    ROUND(SUM(f.line_total), 2) AS total_revenue,
    ROUND(SUM(f.line_total) / COUNT(DISTINCT f.transaction_id), 2) AS avg_transaction_value,
    ROUND(SUM(CASE WHEN dc.loyalty_member = 'Yes' THEN 1.0 ELSE 0 END) / COUNT(f.transaction_id) * 100, 2) AS loyalty_transaction_pct,
    ROUND(SUM(f.discount_applied), 2) AS total_discount_applied
FROM fact_sales f
INNER JOIN dim_employee de ON f.employee_key = de.employee_key
INNER JOIN dim_store ds ON f.store_key = ds.store_key
LEFT JOIN dim_customer dc ON f.customer_key = dc.customer_key
WHERE f.line_total > 0
GROUP BY de.employee_id, de.first_name, de.last_name, de.role, ds.store_location
HAVING COUNT(DISTINCT f.transaction_id) > 10
ORDER BY total_revenue DESC;

--Customer Loyalty Analysis
WITH CustomerMetrics AS (
    SELECT 
        dc.customer_id,
        dc.loyalty_member,
        COUNT(DISTINCT f.transaction_id) AS transaction_count,
        ROUND(SUM(f.line_total), 2) AS total_spend,
        ROUND(SUM(f.discount_applied), 2) AS total_discount
    FROM fact_sales f
    LEFT JOIN dim_customer dc ON f.customer_key = dc.customer_key
    GROUP BY dc.customer_id, dc.loyalty_member
)
SELECT 
    loyalty_member,
    COUNT(DISTINCT customer_id) AS unique_customers,
    ROUND(AVG(CAST(transaction_count AS FLOAT)), 2) AS avg_transactions_per_customer,
    ROUND(AVG(total_spend), 2) AS avg_spend_per_customer,
    ROUND(SUM(total_discount), 2) AS total_discount
FROM CustomerMetrics
GROUP BY loyalty_member;

--Product Performance by Category
SELECT 
    dp.description,
    COUNT(f.sales_key) AS items_sold,
    ROUND(SUM(f.line_total), 2) AS total_revenue,
    ROUND(SUM(f.discount_applied), 2) AS total_discount
FROM fact_sales f
INNER JOIN dim_product dp ON f.product_key = dp.product_key
GROUP BY dp.description
ORDER BY total_revenue DESC;

--Day-of-Week Sales Trends
SELECT 
    dd.day_of_week,
    COUNT(DISTINCT f.transaction_id) AS transaction_count,
    ROUND(SUM(f.line_total), 2) AS total_revenue,
    ROUND(SUM(f.line_total) / COUNT(DISTINCT f.transaction_id), 2) AS avg_transaction_value
FROM fact_sales f
INNER JOIN dim_date dd ON f.date_key = dd.date_key
GROUP BY dd.day_of_week
ORDER BY total_revenue DESC;

--Store-Specific Product Performance
SELECT 
    ds.store_location,
    dp.description,
    COUNT(f.sales_key) AS items_sold,
    ROUND(SUM(f.line_total), 2) AS total_revenue
FROM fact_sales f
INNER JOIN dim_store ds ON f.store_key = ds.store_key
INNER JOIN dim_product dp ON f.product_key = dp.product_key
GROUP BY ds.store_location, dp.description
ORDER BY ds.store_location, total_revenue DESC;

--Employee Role Performance
SELECT 
    de.role,
    COUNT(DISTINCT f.transaction_id) AS transaction_count,
    ROUND(SUM(f.line_total), 2) AS total_revenue,
    ROUND(SUM(f.line_total) / COUNT(DISTINCT f.transaction_id), 2) AS avg_transaction_value
FROM fact_sales f
INNER JOIN dim_employee de ON f.employee_key = de.employee_key
GROUP BY de.role
ORDER BY total_revenue DESC;

--Discount Impact Analysis
SELECT 
    CASE WHEN f.discount_applied > 0 THEN 'Discounted' ELSE 'Non-Discounted' END AS discount_status,
    COUNT(DISTINCT f.transaction_id) AS transaction_count,
    ROUND(SUM(f.line_total), 2) AS total_revenue,
    ROUND(SUM(f.discount_applied), 2) AS total_discount
FROM fact_sales f
GROUP BY CASE WHEN f.discount_applied > 0 THEN 'Discounted' ELSE 'Non-Discounted' END;