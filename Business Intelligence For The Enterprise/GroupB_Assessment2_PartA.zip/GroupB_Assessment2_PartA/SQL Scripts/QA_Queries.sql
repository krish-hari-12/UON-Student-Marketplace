use FinalStage;
--  Verify SalesData_Clean population
SELECT 
    COUNT(*) AS clean_rows, 
    COUNT(DISTINCT TransactionID) AS unique_transactions
FROM [dbo].[SalesData_Clean];

-- Verify dim_product population (expect 10 rows)
SELECT 
    product_id, 
    description, 
    unit_price, 
    effective_start_date, 
    effective_end_date
FROM dim_product
ORDER BY product_id;

-- Check for unmatched ProductIDs in SalesData_Clean
SELECT 
    ProductID, 
    ProductDescription, 
    COUNT(*) AS row_count
FROM [dbo].[SalesData_Clean]
WHERE ProductID NOT IN ('P001', 'P002', 'P003', 'P004', 'P005', 'P006', 'P007', 'P008', 'P009', 'P010')
   OR ProductID IS NULL
GROUP BY ProductID, ProductDescription;

-- Verify discounts applied
SELECT 
    transaction_id,
    SUM(discount_applied) AS total_discount,
    SUM(line_total) AS total_after_discount
FROM fact_sales
WHERE discount_applied > 0
GROUP BY transaction_id;

-- Validate fact_sales population
SELECT 
    COUNT(*) AS fact_sales_rows,
    COUNT(DISTINCT transaction_id) AS unique_transactions,
    ROUND(SUM(line_total), 2) AS total_revenue,
    ROUND(SUM(discount_applied), 2) AS total_discount
FROM fact_sales;

-- Compare row counts between tables
SELECT 
    (SELECT COUNT(*) FROM [dbo].[SalesData_Staging]) AS staging_rows,
    (SELECT COUNT(*) FROM [dbo].[SalesData_Clean]) AS clean_rows,
    (SELECT COUNT(*) FROM fact_sales) AS fact_sales_rows;

-- Identify unmatched ProductIDs causing NULL product_key
SELECT 
    sc.ProductID, 
    sc.ProductDescription, 
    COUNT(*) AS row_count
FROM [dbo].[SalesData_Clean] sc
LEFT JOIN dim_product dp 
    ON sc.ProductID = dp.product_id
WHERE dp.product_key IS NULL
GROUP BY sc.ProductID, sc.ProductDescription;
GO

-- Compare row counts between tables
SELECT 
    (SELECT COUNT(*) FROM [dbo].[SalesData_Staging]) AS staging_rows,
    (SELECT COUNT(*) FROM [dbo].[SalesData_Clean]) AS clean_rows,
    (SELECT COUNT(*) FROM fact_sales) AS fact_sales_rows;

-- Identify unmatched ProductIDs causing NULL product_key
SELECT 
    sc.ProductID, 
    sc.ProductDescription, 
    COUNT(*) AS row_count
FROM [dbo].[SalesData_Clean] sc
LEFT JOIN dim_product dp 
    ON sc.ProductID = dp.product_id
WHERE dp.product_key IS NULL
GROUP BY sc.ProductID, sc.ProductDescription;
GO

--Check for  duplicates having trnasaction ID
SELECT TransactionID, COUNT(*) AS DuplicateCount
FROM [dbo].[SalesData_Clean]
GROUP BY TransactionID
HAVING COUNT(*) > 1;

-- Validate LineTotal
SELECT TransactionID, LineTotal, (UnitPrice * Quantity) AS CalculatedTotal
FROM [dbo].[SalesData_Clean]
WHERE ABS(LineTotal - (UnitPrice * Quantity)) > 0.01;
-- Expected: 0 rows (all LineTotal correct).

-- Verify discount application
SELECT 
    transaction_id,
    SUM(discount_applied) AS TotalDiscount,
    SUM(line_total) AS TotalAfterDiscount
FROM fact_sales
WHERE discount_applied > 0
GROUP BY transaction_id;


-- Check nulls post-clean
SELECT 
    SUM(CASE WHEN ProductID IS NULL THEN 1 ELSE 0 END) AS MissingProductID,
    SUM(CASE WHEN CustomerID IS NULL THEN 1 ELSE 0 END) AS MissingCustomerID,
    SUM(CASE WHEN TransactionID IS NULL THEN 1 ELSE 0 END) AS MissingTransactionID
FROM [dbo].[SalesData_Clean];
-- Expected: 0 for all counts.

-- Validate fact_sales population
SELECT 
    COUNT(*) AS fact_sales_rows,
    COUNT(DISTINCT transaction_id) AS unique_transactions,
    ROUND(SUM(line_total), 2) AS total_revenue,
    ROUND(SUM(discount_applied), 2) AS total_discount
FROM fact_sales;
