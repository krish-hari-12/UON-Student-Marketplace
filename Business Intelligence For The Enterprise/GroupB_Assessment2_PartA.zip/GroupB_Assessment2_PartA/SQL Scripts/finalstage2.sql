USE FinalStage;
GO

-- Drop tables if they exist
IF OBJECT_ID('[dbo].[SalesData_Clean]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SalesData_Clean];
IF OBJECT_ID('fact_sales', 'U') IS NOT NULL DROP TABLE fact_sales;
IF OBJECT_ID('dim_date', 'U') IS NOT NULL DROP TABLE dim_date;
IF OBJECT_ID('dim_customer', 'U') IS NOT NULL DROP TABLE dim_customer;
IF OBJECT_ID('dim_employee', 'U') IS NOT NULL DROP TABLE dim_employee;
IF OBJECT_ID('dim_store', 'U') IS NOT NULL DROP TABLE dim_store;
IF OBJECT_ID('dim_product', 'U') IS NOT NULL DROP TABLE dim_product;
GO

-- Create clean table
CREATE TABLE [dbo].[SalesData_Clean] (
    [TransactionDate] DATE NULL,
    [LoyaltyMember] NVARCHAR(50) NULL,
    [TransactionID] NVARCHAR(50) NULL,
    [CustomerID] NVARCHAR(50) NULL,
    [CustomerFirstName] NVARCHAR(100) NULL,
    [CustomerLastName] NVARCHAR(100) NULL,
    [EmployeeID] NVARCHAR(50) NULL,
    [EmployeeFirstName] NVARCHAR(100) NULL,
    [EmployeeLastName] NVARCHAR(100) NULL,
    [EmployeeRole] NVARCHAR(50) NULL,
    [StoreLocation] NVARCHAR(100) NULL,
    [ProductID] NVARCHAR(50) NULL,
    [ProductDescription] NVARCHAR(100) NULL,
    [UnitPrice] DECIMAL(10,2) NULL,
    [Quantity] INT NULL,
    [LineTotal] DECIMAL(10,2) NULL
);
GO

-- Step 1: Get latest TransactionDate per CustomerID
WITH LatestCustomerDate AS (
    SELECT 
        CustomerID,
        MAX(TransactionDate) AS MaxTransactionDate
    FROM [dbo].[SalesData_Staging]
    WHERE CustomerID IS NOT NULL
    GROUP BY CustomerID
),
-- Step 2: Consolidate CustomerID attributes
CustomerCanonical AS (
    SELECT 
        s.CustomerID,
        LTRIM(RTRIM(COALESCE(MAX(s.CustomerFirstName), 'NA'))) AS CustomerFirstName,
        LTRIM(RTRIM(COALESCE(MAX(s.CustomerLastName), 'NA'))) AS CustomerLastName,
        CASE 
            WHEN MAX(CASE WHEN LOWER(LTRIM(RTRIM(COALESCE(s.LoyaltyMember, '')))) IN ('y', 'yes', 'yes ') THEN 1 ELSE 0 END) = 1 THEN 'Yes'
            ELSE 'No'
        END AS LoyaltyMember
    FROM [dbo].[SalesData_Staging] s
    INNER JOIN LatestCustomerDate lcd ON s.CustomerID = lcd.CustomerID AND s.TransactionDate = lcd.MaxTransactionDate
    WHERE s.CustomerID IS NOT NULL
    GROUP BY s.CustomerID
),
-- Step 3: Get latest TransactionDate per EmployeeID
LatestEmployeeDate AS (
    SELECT 
        EmployeeID,
        MAX(TransactionDate) AS MaxTransactionDate
    FROM [dbo].[SalesData_Staging]
    WHERE EmployeeID IS NOT NULL
    GROUP BY EmployeeID
),
-- Step 4: Consolidate EmployeeID attributes
EmployeeCanonical AS (
    SELECT 
        s.EmployeeID,
        LTRIM(RTRIM(COALESCE(MAX(s.EmployeeFirstName), 'NA'))) AS EmployeeFirstName,
        LTRIM(RTRIM(COALESCE(MAX(s.EmployeeLastName), 'NA'))) AS EmployeeLastName,
        CASE LOWER(LTRIM(RTRIM(COALESCE(MAX(s.EmployeeRole), ''))))
            WHEN 'barista' THEN 'Barista'
            WHEN 'cashier' THEN 'Cashier'
            WHEN 'shift supervisor' THEN 'Shift Supervisor'
            WHEN 'baristaa' THEN 'Barista'
            WHEN 'barsta' THEN 'Barista'
            WHEN 'cashr' THEN 'Cashier'
            WHEN 'shift sup' THEN 'Shift Supervisor'
            WHEN 'shiftsuper' THEN 'Shift Supervisor'
            WHEN 'cashier ' THEN 'Cashier'
            ELSE 'Unknown'
        END AS EmployeeRole
    FROM [dbo].[SalesData_Staging] s
    INNER JOIN LatestEmployeeDate led ON s.EmployeeID = led.EmployeeID AND s.TransactionDate = led.MaxTransactionDate
    WHERE s.EmployeeID IS NOT NULL
    GROUP BY s.EmployeeID
),
-- Step 5: Apply canonical attributes and standardize fields
StandardizedData AS (
    SELECT 
        DATEADD(DAY, CAST(s.TransactionDate AS INT) - 2, '1900-01-01') AS TransactionDate,
        cust.LoyaltyMember,
        s.TransactionID,
        s.CustomerID,
        cust.CustomerFirstName,
        cust.CustomerLastName,
        s.EmployeeID,
        emp.EmployeeFirstName,
        emp.EmployeeLastName,
        emp.EmployeeRole,
        CASE 
            WHEN LOWER(LTRIM(RTRIM(COALESCE(s.StoreLocation, '')))) LIKE '%newcastle%cbd%' THEN 'Newcastle CBD'
            WHEN LOWER(LTRIM(RTRIM(COALESCE(s.StoreLocation, '')))) LIKE '%charlestown%' THEN 'Charlestown'
            WHEN LOWER(LTRIM(RTRIM(COALESCE(s.StoreLocation, '')))) LIKE '%hamilton%' THEN 'Hamilton'
            ELSE LTRIM(RTRIM(COALESCE(s.StoreLocation, '')))
        END AS StoreLocation,
        CASE 
            WHEN s.ProductID IS NULL OR LTRIM(RTRIM(COALESCE(s.ProductID, ''))) = '' OR LTRIM(RTRIM(COALESCE(s.ProductID, ''))) = 'Unknown' THEN 
                CASE LTRIM(RTRIM(COALESCE(s.ProductDescription, '')))
                    WHEN 'Cappuccino' THEN 'P002'
                    WHEN 'Almond Croissant' THEN 'P003'
                    WHEN 'Mocha' THEN 'P009'
                    WHEN 'Espresso' THEN 'P008'
                    WHEN 'Iced Latte' THEN 'P005'
                    WHEN 'Chai Latte' THEN 'P007'
                    WHEN 'Blueberry Muffin' THEN 'P004'
                    WHEN 'Vegan Brownie' THEN 'P010'
                    WHEN 'Flat White' THEN 'P001'
                    WHEN 'Avocado Toast' THEN 'P006'
                    ELSE 'P999' -- Default for unknown products
                END
            ELSE LTRIM(RTRIM(s.ProductID))
        END AS ProductID,
        CASE 
            WHEN s.ProductID IS NULL OR LTRIM(RTRIM(COALESCE(s.ProductDescription, ''))) = '' THEN 
                CASE LTRIM(RTRIM(COALESCE(s.ProductDescription, '')))
                    WHEN 'Cappuccino' THEN 'Cappuccino'
                    WHEN 'Almond Croissant' THEN 'Almond Croissant'
                    WHEN 'Mocha' THEN 'Mocha'
                    WHEN 'Espresso' THEN 'Espresso'
                    WHEN 'Iced Latte' THEN 'Iced Latte'
                    WHEN 'Chai Latte' THEN 'Chai Latte'
                    WHEN 'Blueberry Muffin' THEN 'Blueberry Muffin'
                    WHEN 'Vegan Brownie' THEN 'Vegan Brownie'
                    WHEN 'Flat White' THEN 'Flat White'
                    WHEN 'Avocado Toast' THEN 'Avocado Toast'
                    ELSE 'Unknown Product'
                END
            ELSE LTRIM(RTRIM(COALESCE(s.ProductDescription, 'Unknown Product')))
        END AS ProductDescription,
        ROUND(CAST(COALESCE(s.UnitPrice, 0) AS DECIMAL(10,2)), 2) AS UnitPrice,
        CAST(COALESCE(s.Quantity, 0) AS INT) AS Quantity,
        ROUND(CAST(COALESCE(s.UnitPrice * s.Quantity, 0) AS DECIMAL(10,2)), 2) AS LineTotal
    FROM [dbo].[SalesData_Staging] s
    LEFT JOIN CustomerCanonical cust ON s.CustomerID = cust.CustomerID
    LEFT JOIN EmployeeCanonical emp ON s.EmployeeID = emp.EmployeeID
    WHERE s.TransactionID IS NOT NULL
),
-- Step 6: Identify duplicate TransactionIDs
EligibleTransactionIDs AS (
    SELECT 
        TransactionID
    FROM StandardizedData
    GROUP BY TransactionID
    HAVING COUNT(*) > 1 
       AND (COUNT(DISTINCT StoreLocation) > 1 OR COUNT(DISTINCT CustomerID) > 1 OR COUNT(DISTINCT EmployeeID) > 1)
),
-- Step 7: Identify canonical values for duplicate TransactionIDs
CanonicalTransactionValues AS (
    SELECT 
        s.TransactionID,
        s.TransactionDate,
        s.CustomerID,
        s.CustomerFirstName,
        s.CustomerLastName,
        s.LoyaltyMember,
        s.EmployeeID,
        s.EmployeeFirstName,
        s.EmployeeLastName,
        s.EmployeeRole,
        s.StoreLocation,
        ROW_NUMBER() OVER (PARTITION BY s.TransactionID ORDER BY s.TransactionDate DESC, s.CustomerID ASC, s.StoreLocation ASC) AS rn
    FROM StandardizedData s
    INNER JOIN EligibleTransactionIDs e ON s.TransactionID = e.TransactionID
),
-- Step 8: Final cleaned data
CleanedData AS (
    SELECT 
        COALESCE(c.TransactionDate, s.TransactionDate) AS TransactionDate,
        COALESCE(c.LoyaltyMember, s.LoyaltyMember) AS LoyaltyMember,
        s.TransactionID,
        COALESCE(c.CustomerID, s.CustomerID) AS CustomerID,
        COALESCE(c.CustomerFirstName, s.CustomerFirstName) AS CustomerFirstName,
        COALESCE(c.CustomerLastName, s.CustomerLastName) AS CustomerLastName,
        COALESCE(c.EmployeeID, s.EmployeeID) AS EmployeeID,
        COALESCE(c.EmployeeFirstName, s.EmployeeFirstName) AS EmployeeFirstName,
        COALESCE(c.EmployeeLastName, s.EmployeeLastName) AS EmployeeLastName,
        COALESCE(c.EmployeeRole, s.EmployeeRole) AS EmployeeRole,
        COALESCE(c.StoreLocation, s.StoreLocation) AS StoreLocation,
        s.ProductID,
        s.ProductDescription,
        s.UnitPrice,
        s.Quantity,
        s.LineTotal
    FROM StandardizedData s
    LEFT JOIN CanonicalTransactionValues c 
        ON s.TransactionID = c.TransactionID 
        AND c.rn = 1
)
-- Step 9: Insert cleaned data
INSERT INTO [dbo].[SalesData_Clean] (
    TransactionDate, LoyaltyMember, TransactionID, CustomerID, CustomerFirstName,
    CustomerLastName, EmployeeID, EmployeeFirstName, EmployeeLastName, EmployeeRole,
    StoreLocation, ProductID, ProductDescription, UnitPrice, Quantity, LineTotal
)
SELECT 
    TransactionDate, LoyaltyMember, TransactionID, CustomerID, CustomerFirstName,
    CustomerLastName, EmployeeID, EmployeeFirstName, EmployeeLastName, EmployeeRole,
    StoreLocation, ProductID, ProductDescription, UnitPrice, Quantity, LineTotal
FROM CleanedData;

-- Step 10: Update LoyaltyMember for multi-visit customers
WITH CustomerVisits AS (
    SELECT 
        CustomerID,
        COUNT(DISTINCT TransactionDate) AS VisitCount
    FROM [dbo].[SalesData_Clean]
    GROUP BY CustomerID
)
UPDATE c
SET c.LoyaltyMember = 'Yes'
FROM [dbo].[SalesData_Clean] c
INNER JOIN CustomerVisits v ON c.CustomerID = v.CustomerID
WHERE v.VisitCount > 1;
GO