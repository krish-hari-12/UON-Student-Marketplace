USE FinalStage;
GO

-- Create dim_date
CREATE TABLE dim_date (
    date_key INT IDENTITY(1,1) PRIMARY KEY,
    full_date DATE NOT NULL,
    year INT NOT NULL,
    quarter INT NOT NULL,
    month INT NOT NULL,
    day INT NOT NULL,
    day_of_week VARCHAR(10) NOT NULL
);

-- Populate dim_date
INSERT INTO dim_date (full_date, year, quarter, month, day, day_of_week)
SELECT 
    d.TransactionDate,
    YEAR(d.TransactionDate),
    DATEPART(QUARTER, d.TransactionDate),
    MONTH(d.TransactionDate),
    DAY(d.TransactionDate),
    DATENAME(WEEKDAY, d.TransactionDate)
FROM (
    SELECT DISTINCT TransactionDate
    FROM [dbo].[SalesData_Clean]
    WHERE TransactionDate IS NOT NULL
) d;

-- Create dim_customer
CREATE TABLE dim_customer (
    customer_key INT IDENTITY(1,1) PRIMARY KEY,
    customer_id NVARCHAR(50) NOT NULL,
    first_name NVARCHAR(100) NOT NULL,
    last_name NVARCHAR(100) NOT NULL,
    loyalty_member NVARCHAR(50) NOT NULL
);

-- Populate dim_customer
INSERT INTO dim_customer (customer_id, first_name, last_name, loyalty_member)
SELECT DISTINCT 
    CustomerID, 
    COALESCE(CustomerFirstName, 'NA'),
    COALESCE(CustomerLastName, 'NA'), 
    COALESCE(LoyaltyMember, 'No')
FROM [dbo].[SalesData_Clean]
WHERE CustomerID IS NOT NULL;

-- Create dim_employee
CREATE TABLE dim_employee (
    employee_key INT IDENTITY(1,1) PRIMARY KEY,
    employee_id NVARCHAR(50) NOT NULL,
    first_name NVARCHAR(100) NOT NULL,
    last_name NVARCHAR(100) NOT NULL,
    role NVARCHAR(50) NOT NULL
);

-- Populate dim_employee
INSERT INTO dim_employee (employee_id, first_name, last_name, role)
SELECT DISTINCT 
    EmployeeID, 
    COALESCE(EmployeeFirstName, 'NA'), 
    COALESCE(EmployeeLastName, 'NA'), 
    COALESCE(EmployeeRole, 'Unknown')
FROM [dbo].[SalesData_Clean]
WHERE EmployeeID IS NOT NULL;

-- Create dim_store
CREATE TABLE dim_store (
    store_key INT IDENTITY(1,1) PRIMARY KEY,
    store_location NVARCHAR(100) NOT NULL
);

-- Populate dim_store
INSERT INTO dim_store (store_location)
SELECT DISTINCT StoreLocation
FROM [dbo].[SalesData_Clean]
WHERE StoreLocation IS NOT NULL;

-- Create dim_product without is_current
CREATE TABLE dim_product (
    product_key INT IDENTITY(1,1) PRIMARY KEY,
    product_id NVARCHAR(50) NOT NULL,
    description NVARCHAR(100) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    effective_start_date DATE NOT NULL,
    effective_end_date DATE NULL
);

-- Populate dim_product with exactly 10 products
WITH ProductPrices AS (
    SELECT 
        ProductID,
        COALESCE(MAX(ProductDescription), 'Unknown') AS ProductDescription,
        COALESCE(MAX(UnitPrice), 0) AS UnitPrice
    FROM [dbo].[SalesData_Clean]
    WHERE ProductID IN ('P001', 'P002', 'P003', 'P004', 'P005', 'P006', 'P007', 'P008', 'P009', 'P010')
    GROUP BY ProductID
)
INSERT INTO dim_product (product_id, description, unit_price, effective_start_date, effective_end_date)
SELECT 
    ProductID,
    ProductDescription,
    UnitPrice,
    CAST(GETDATE() AS DATE) AS effective_start_date,
    CAST('2050-12-12' AS DATE) AS effective_end_date
FROM ProductPrices;

-- Create fact_sales with discount_applied
CREATE TABLE fact_sales (
    sales_key INT IDENTITY(1,1) PRIMARY KEY,
    date_key INT NOT NULL FOREIGN KEY REFERENCES dim_date(date_key),
    customer_key INT NULL FOREIGN KEY REFERENCES dim_customer(customer_key),
    employee_key INT NULL FOREIGN KEY REFERENCES dim_employee(employee_key),
    store_key INT NOT NULL FOREIGN KEY REFERENCES dim_store(store_key),
    product_key INT NOT NULL FOREIGN KEY REFERENCES dim_product(product_key),
    transaction_id NVARCHAR(50) NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    line_total DECIMAL(10,2) NOT NULL,
    discount_applied DECIMAL(10,2) NOT NULL DEFAULT 0.00
);

-- Identify eligible transactions for 12.5% discount
WITH EligibleTransactions AS (
    SELECT 
        TransactionID,
        COUNT(DISTINCT ProductID) AS UniqueProducts,
        SUM(LineTotal) AS TransactionTotal,
        MAX(CASE WHEN LoyaltyMember = 'Yes' THEN 1 ELSE 0 END) AS IsLoyaltyMember
    FROM [dbo].[SalesData_Clean]
    WHERE ProductID IN ('P001', 'P002', 'P003', 'P004', 'P005', 'P006', 'P007', 'P008', 'P009', 'P010')
    GROUP BY TransactionID
    HAVING COUNT(DISTINCT ProductID) >= 5 AND MAX(CASE WHEN LoyaltyMember = 'Yes' THEN 1 ELSE 0 END) = 1
),
-- Calculate discount per transaction
DiscountedTransactions AS (
    SELECT 
        TransactionID,
        TransactionTotal,
        ROUND(TransactionTotal * 0.125, 2) AS TotalDiscount
    FROM EligibleTransactions
),
-- Distribute discount proportionally across line items
SalesWithDiscount AS (
    SELECT 
        sc.TransactionDate,
        sc.LoyaltyMember,
        sc.TransactionID,
        sc.CustomerID,
        sc.CustomerFirstName,
        sc.CustomerLastName,
        sc.EmployeeID,
        sc.EmployeeFirstName,
        sc.EmployeeLastName,
        sc.EmployeeRole,
        sc.StoreLocation,
        sc.ProductID,
        sc.ProductDescription,
        COALESCE(dp.unit_price, sc.UnitPrice, 0) AS UnitPrice,
        COALESCE(sc.Quantity, 0) AS Quantity,
        ROUND(COALESCE(dp.unit_price, sc.UnitPrice, 0) * COALESCE(sc.Quantity, 0), 2) AS LineTotal,
        COALESCE(
            ROUND((ROUND(COALESCE(dp.unit_price, sc.UnitPrice, 0) * COALESCE(sc.Quantity, 0), 2) / NULLIF(dt.TransactionTotal, 0)) * dt.TotalDiscount, 2),
            0.00
        ) AS discount_applied,
        ROUND((COALESCE(dp.unit_price, sc.UnitPrice, 0) * COALESCE(sc.Quantity, 0)) - COALESCE((ROUND(COALESCE(dp.unit_price, sc.UnitPrice, 0) * COALESCE(sc.Quantity, 0), 2) / NULLIF(dt.TransactionTotal, 0)) * dt.TotalDiscount, 0.00), 2) AS adjusted_line_total
    FROM [dbo].[SalesData_Clean] sc
    INNER JOIN dim_product dp 
        ON sc.ProductID = dp.product_id
    LEFT JOIN DiscountedTransactions dt ON sc.TransactionID = dt.TransactionID
    WHERE sc.ProductID IN ('P001', 'P002', 'P003', 'P004', 'P005', 'P006', 'P007', 'P008', 'P009', 'P010')
)
-- Populate fact_sales
INSERT INTO fact_sales (
    date_key, customer_key, employee_key, store_key, product_key, 
    transaction_id, quantity, unit_price, line_total, discount_applied
)
SELECT 
    dd.date_key,
    dc.customer_key,
    de.employee_key,
    ds.store_key,
    dp.product_key,
    sc.TransactionID,
    sc.Quantity,
    sc.UnitPrice,
    sc.adjusted_line_total,
    sc.discount_applied
FROM SalesWithDiscount sc
LEFT JOIN dim_date dd ON sc.TransactionDate = dd.full_date
LEFT JOIN dim_customer dc ON sc.CustomerID = dc.customer_id
LEFT JOIN dim_employee de ON sc.EmployeeID = de.employee_id
LEFT JOIN dim_store ds ON sc.StoreLocation = ds.store_location
INNER JOIN dim_product dp 
    ON sc.ProductID = dp.product_id
WHERE sc.TransactionID IS NOT NULL;