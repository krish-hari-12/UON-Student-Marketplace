#!/usr/bin/env python3
"""
Bean & Bloom – 12-Month Sales Forecast
Deliverable 4 – Forecasting & Predictive Insights (20%)

Features:
    • All 10 stores + Nationwide total
    • Linear Regression + Trend Adjustment + Seasonality
    • Clean, professional, board-ready plots
    • No overlapping lines
    • 3x4 grid (12 subplots: 10 stores + 1 national + 1 blank)
    • All outputs in ./forecast_output/
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from datetime import datetime
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import warnings

warnings.filterwarnings("ignore")
sns.set_style("whitegrid")
plt.rcParams["figure.figsize"] = (18, 12)

# ----------------------------------------------------------------------
# CONFIG
# ----------------------------------------------------------------------
INPUT_CSV = "working_sales_updated.csv"
OUT_DIR   = "forecast_output"
os.makedirs(OUT_DIR, exist_ok=True)

print("="*85)
print("BEAN & BLOOM – 12-MONTH SALES FORECAST (10 STORES + NATIONWIDE)")
print("="*85)

# ----------------------------------------------------------------------
# 1. LOAD & CLEAN DATA
# ----------------------------------------------------------------------
print("\n[1/6] Loading data...")
df = pd.read_csv(INPUT_CSV, header=None, low_memory=False)

# Column mapping (exact order from your CSV)
cols = [
    "SaleTimestamp","ReceiptID","CustomerID","CustomerFirstName","CustomerSurname",
    "EmployeeID","EmployeeFirstName","EmployeeSurname","StoreID","StoreLocation",
    "TransactionRowID","ItemID","ItemDescription","ItemQuantity","ItemPrice",
    "RowTotal","EmployeeRole","LoyaltyMember","DiscountApplied","MonthYear",
    "DiscountFlag","Category","Qty_Num","Price_Num","BaseRowTotal",
    "RowTotal_Num","MonthName","ConvertedSaleDate"
]
df.columns = cols

# Keep only needed columns
df = df[["StoreID", "StoreLocation", "ConvertedSaleDate", "RowTotal_Num"]].copy()

# Type conversion
df["ConvertedSaleDate"] = pd.to_datetime(df["ConvertedSaleDate"], errors="coerce")
df["RowTotal_Num"]      = pd.to_numeric(df["RowTotal_Num"], errors="coerce")
df.dropna(inplace=True)

print(f"   → {len(df):,} rows, {df['StoreLocation'].nunique()} stores")

# ----------------------------------------------------------------------
# 2. MONTHLY AGGREGATION
# ----------------------------------------------------------------------
print("[2/6] Aggregating monthly sales...")
monthly = (
    df.groupby([
        "StoreID",
        "StoreLocation",
        pd.Grouper(key="ConvertedSaleDate", freq="MS")
    ])["RowTotal_Num"]
    .sum()
    .reset_index()
    .rename(columns={"RowTotal_Num": "Revenue"})
)

# Time features
monthly["MonthNum"]     = (monthly["ConvertedSaleDate"].dt.year - 2022) * 12 + monthly["ConvertedSaleDate"].dt.month
monthly["Quarter"]      = monthly["ConvertedSaleDate"].dt.quarter
monthly["MonthOfYear"]  = monthly["ConvertedSaleDate"].dt.month

# National total
national = monthly.groupby("ConvertedSaleDate")["Revenue"].sum().reset_index()
national["StoreID"] = 999
national["StoreLocation"] = "NATIONWIDE"
national = national[["StoreID", "StoreLocation", "ConvertedSaleDate", "Revenue"]]
national["MonthNum"] = (national["ConvertedSaleDate"].dt.year - 2022) * 12 + national["ConvertedSaleDate"].dt.month
national["Quarter"] = national["ConvertedSaleDate"].dt.quarter
national["MonthOfYear"] = national["ConvertedSaleDate"].dt.month

monthly = pd.concat([monthly, national], ignore_index=True)

print(f"   → {len(monthly)} monthly records (incl. national)")

# ----------------------------------------------------------------------
# 3. FORECAST FUNCTION
# ----------------------------------------------------------------------
def forecast_store(store_df: pd.DataFrame, periods: int = 12):
    X = store_df[["MonthNum", "Quarter", "MonthOfYear"]].values
    y = store_df["Revenue"].values

    model = LinearRegression()
    model.fit(X, y)
    y_pred = model.predict(X)

    mae  = mean_absolute_error(y, y_pred)
    rmse = np.sqrt(mean_squared_error(y, y_pred))
    r2   = r2_score(y, y_pred)

    last_mn = X[-1, 0]
    future = []
    for i in range(1, periods + 1):
        mn = last_mn + i
        q  = ((mn - 1) % 12) // 3 + 1
        m  = ((mn - 1) % 12) + 1
        future.append([mn, q, m])
    future_X = np.array(future)

    recent_trend = np.mean(y[-3:]) - np.mean(y[-6:-3]) if len(y) >= 6 else 0
    lin_fc = model.predict(future_X)
    adj_fc = lin_fc + recent_trend * 0.3
    adj_fc = np.maximum(adj_fc, 0)

    monthly_avg = store_df.groupby("MonthOfYear")["Revenue"].mean()
    overall_avg = store_df["Revenue"].mean()
    seas_factor = (monthly_avg / overall_avg).fillna(1.0).to_dict()

    final_fc = [
        adj_fc[i] * seas_factor.get(((last_mn + i) % 12) + 1, 1.0)
        for i in range(periods)
    ]

    last_date = store_df["ConvertedSaleDate"].max()
    fc_dates = pd.date_range(start=last_date + pd.offsets.MonthBegin(1), periods=periods, freq="MS")

    fc_df = pd.DataFrame({
        "StoreID": store_df["StoreID"].iloc[0],
        "StoreLocation": store_df["StoreLocation"].iloc[0],
        "Month": fc_dates,
        "ForecastRevenue": np.round(final_fc, 2),
        "Method": "LinReg+Trend+Seasonality"
    })

    metrics = {"MAE": round(mae, 2), "RMSE": round(rmse, 2), "R2": round(r2, 3)}
    return fc_df, metrics

# ----------------------------------------------------------------------
# 4. RUN FORECAST
# ----------------------------------------------------------------------
print("\n[3/6] Forecasting all 10 stores + Nationwide...")
all_fc = []
all_met = []

for sid in sorted(monthly["StoreID"].unique()):
    if sid == 999:  # Nationwide
        continue
    sdata = monthly[monthly["StoreID"] == sid].sort_values("ConvertedSaleDate")
    name = sdata["StoreLocation"].iloc[0]

    fc_df, met = forecast_store(sdata)
    all_fc.append(fc_df)
    all_met.append({
        "StoreID": sid,
        "StoreLocation": name,
        **met,
        "Avg_Historical_Revenue": round(sdata["Revenue"].mean(), 2),
        "Avg_Forecast_Revenue": round(fc_df["ForecastRevenue"].mean(), 2)
    })
    print(f"   Store {int(sid):2d} – {name:20s}  R² = {met['R2']:.3f}")

# Forecast national
nat_data = monthly[monthly["StoreID"] == 999]
fc_nat, met_nat = forecast_store(nat_data)
all_fc.append(fc_nat)
all_met.append({
    "StoreID": 999,
    "StoreLocation": "NATIONWIDE",
    **met_nat,
    "Avg_Historical_Revenue": round(nat_data["Revenue"].mean(), 2),
    "Avg_Forecast_Revenue": round(fc_nat["ForecastRevenue"].mean(), 2)
})
print(f"   NATIONWIDE                  R² = {met_nat['R2']:.3f}")

forecast_df = pd.concat(all_fc, ignore_index=True)
metrics_df  = pd.DataFrame(all_met)

# ----------------------------------------------------------------------
# 5. SAVE CSVs
# ----------------------------------------------------------------------
fc_path = os.path.join(OUT_DIR, "sales_forecast_12months.csv")
met_path = os.path.join(OUT_DIR, "forecast_model_performance.csv")
forecast_df.to_csv(fc_path, index=False)
metrics_df.to_csv(met_path, index=False)

print(f"\n[4/6] Saved:")
print(f"   → {fc_path}")
print(f"   → {met_path}")

# ----------------------------------------------------------------------
# 6. AGGREGATE SUMMARY
# ----------------------------------------------------------------------
hist_total = monthly[monthly["StoreID"] != 999].groupby("ConvertedSaleDate")["Revenue"].sum()
fc_total   = forecast_df[forecast_df["StoreID"] != 999].groupby("Month")["ForecastRevenue"].sum()

print("\n[5/6] Nationwide Summary")
print(f"   Historical monthly avg : ${hist_total.mean():,.2f}")
print(f"   Forecast   monthly avg : ${fc_total.mean():,.2f}")
print(f"   Expected YoY change    : {((fc_total.mean()/hist_total.mean())-1)*100:+.1f}%")
print(f"   12-month total forecast: ${fc_total.sum():,.2f}")

# ----------------------------------------------------------------------
# 7. PLOTS
# ----------------------------------------------------------------------
print("\n[6/6] Generating clean, professional plots...")

# === 7.1: DETAILED – 3x4 Grid (10 stores + National + 1 blank) ===
stores = sorted(monthly["StoreID"].unique())
fig, axes = plt.subplots(3, 4, figsize=(20, 15))
axes = axes.ravel()

plot_idx = 0
for sid in stores:
    hist = monthly[monthly["StoreID"] == sid].sort_values("ConvertedSaleDate")
    fc   = forecast_df[forecast_df["StoreID"] == sid]
    name = hist["StoreLocation"].iloc[0]

    ax = axes[plot_idx]
    ax.plot(hist["ConvertedSaleDate"], hist["Revenue"],
            label="Historical", marker="o", linewidth=2.2, color="#2E86AB")
    ax.plot(fc["Month"], fc["ForecastRevenue"],
            label="Forecast", marker="s", linestyle="--", linewidth=2.2, color="#A23B72")

    ax.set_title(f"{'NATIONWIDE' if sid == 999 else f'Store {int(sid):2d}: {name}'}",
                 fontsize=12, fontweight="bold", pad=10)
    ax.set_ylabel("Revenue ($)")
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'${x/1000:.0f}K' if x >= 1000 else f'${x:,.0f}'))
    ax.tick_params(axis='x', rotation=45, labelsize=8)

    plot_idx += 1

# Hide unused subplot
if plot_idx < len(axes):
    axes[plot_idx].set_visible(False)

plt.suptitle("Bean & Bloom – 12-Month Revenue Forecast (All 10 Stores + Nationwide)", 
             fontsize=16, fontweight="bold", y=0.98)
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.subplots_adjust(hspace=0.6, wspace=0.4)
plt.savefig(os.path.join(OUT_DIR, "forecast_all_stores_grid.png"), dpi=300, bbox_inches="tight")
plt.close()
print("   → forecast_all_stores_grid.png (clean 3x4 grid)")

# === 7.2: Model Performance ===
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# R²
colors_r2 = ["#06A77D" if r >= 0.7 else "#F18F01" for r in metrics_df["R2"]]
bars = axes[0].barh(metrics_df["StoreLocation"], metrics_df["R2"], color=colors_r2)
axes[0].set_xlabel("R² Score")
axes[0].set_title("Model Fit per Store", fontweight="bold")
axes[0].axvline(0.7, color="red", linestyle="--", label="Good Fit")
axes[0].legend()
axes[0].grid(axis="x", alpha=0.3)

# Avg Revenue
xpos = np.arange(len(metrics_df))
w = 0.35
axes[1].bar(xpos - w/2, metrics_df["Avg_Historical_Revenue"], w, label="Historical Avg", color="#2E86AB")
axes[1].bar(xpos + w/2, metrics_df["Avg_Forecast_Revenue"], w, label="Forecast Avg", color="#A23B72")
axes[1].set_xticks(xpos)
axes[1].set_xticklabels(metrics_df["StoreLocation"], rotation=45, ha='right')
axes[1].set_ylabel("Avg Monthly Revenue ($)")
axes[1].set_title("Historical vs Forecast Avg", fontweight="bold")
axes[1].legend()
axes[1].yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'${x/1000:.0f}K'))
axes[1].grid(axis="y", alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "model_performance.png"), dpi=300, bbox_inches="tight")
plt.close()
print("   → model_performance.png")

# ----------------------------------------------------------------------
# 8. FINAL REPORT
# ----------------------------------------------------------------------
print("\n" + "="*85)
print("FORECASTING COMPLETE")
print("="*85)
print("\nOUTPUTS GENERATED:")
print(f"  1. {fc_path}")
print(f"  2. {met_path}")
print(f"  3. {os.path.join(OUT_DIR, 'forecast_all_stores_grid.png')} (3x4 clean grid)")
print(f"  4. {os.path.join(OUT_DIR, 'model_performance.png')}")
print("\nKEY FINDINGS:")
print(f"  • Average R²: {metrics_df['R2'].mean():.3f}")
print(f"  • Best Store: {metrics_df.loc[metrics_df['R2'].idxmax(), 'StoreLocation']} (R²={metrics_df['R2'].max():.3f})")
print(f"  • YoY Growth: {((fc_total.mean()/hist_total.mean())-1)*100:+.1f}%")
print(f"  • 12-Mo Total: ${fc_total.sum():,.2f}")
print("\n" + "="*85)
