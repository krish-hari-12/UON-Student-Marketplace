/****************************************************************************************
  BEAN & BLOOM � SQL ANALYSIS SCRIPTS FOR STRATEGIC DECISION MAKING
  Deliverable 3: SQL Scripts and Analysis Outputs (10%)
  
  Purpose: Answer Mira Thornton's key business questions
  - Store performance comparison
  - Product performance (top 3 and bottom 3 per store)
  - Underperforming items nationwide
  - Loyalty program effectiveness
  - Revenue trends for forecasting
  
  Author: InsightWorks Analytics Team
  Date: December 2024
****************************************************************************************/

USE BeanBloomDataMart;
GO

/****************************************************************************************
  QUERY 1: STORE PERFORMANCE COMPARISON
  Purpose: Compare all 10 stores across key metrics
  Business Value: Identify high/low performers for investment decisions
****************************************************************************************/
SET NOCOUNT OFF;

SELECT 
    s.StoreLocation,
    s.StoreID,
    COUNT(DISTINCT f.ReceiptID) AS TotalTransactions,
    SUM(f.Quantity) AS TotalItemsSold,
    SUM(f.RowTotal) AS TotalRevenue,
    AVG(f.RowTotal) AS AvgLineItemValue,
    COUNT(DISTINCT f.CustomerKey) AS UniqueCustomers,
    COUNT(DISTINCT f.EmployeeKey) AS TotalEmployees,
    SUM(CASE WHEN f.DiscountFlag = 1 THEN 1 ELSE 0 END) AS DiscountedLineItems,
    SUM(CASE WHEN f.DiscountFlag = 1 THEN f.BaseRowTotal - f.RowTotal ELSE 0 END) AS TotalDiscountAmount,
    SUM(f.PointsEarned) AS TotalPointsGenerated,
    -- Calculate average transaction size (need to aggregate at receipt level)
    SUM(f.RowTotal) / COUNT(DISTINCT f.ReceiptID) AS AvgTransactionValue
FROM Fact_Sales f
JOIN Dim_Store s ON f.StoreKey = s.StoreKey
JOIN Dim_Date d ON f.DateKey = d.DateKey
GROUP BY s.StoreLocation, s.StoreID
ORDER BY TotalRevenue DESC;

-- Expected Output: 10 rows (one per store) showing comparative metrics
-- Key Insight: Identifies which stores generate most revenue, have highest customer traffic

/****************************************************************************************
  QUERY 2: TOP 3 PRODUCTS PER STORE
  Purpose: Identify best-selling products at each location
  Business Value: Understand local preferences, optimize inventory
****************************************************************************************/
USE BeanBloomDataMart;
GO



WITH ProductSales AS (
    SELECT 
        s.StoreID,
        s.StoreLocation,
        i.ItemDescription,
        i.Category,
        SUM(f.Quantity) AS TotalQuantitySold,
        SUM(f.RowTotal) AS TotalRevenue,
        COUNT(DISTINCT f.ReceiptID) AS TimesOrdered,
        ROW_NUMBER() OVER (PARTITION BY s.StoreID ORDER BY SUM(f.RowTotal) DESC) AS RevenueRank
    FROM Fact_Sales f
    JOIN Dim_Store s ON f.StoreKey = s.StoreKey
    JOIN Dim_Item i ON f.ItemKey = i.ItemKey
    GROUP BY s.StoreID, s.StoreLocation, i.ItemDescription, i.Category
)
SELECT 
    StoreLocation,
    ItemDescription,
    Category,
    TotalQuantitySold,
    TotalRevenue,
    TimesOrdered,
    RevenueRank
FROM ProductSales
WHERE RevenueRank <= 3
ORDER BY StoreID, RevenueRank;

-- Expected Output: 30 rows (3 products � 10 stores)
-- Key Insight: Shows product mix differences across locations

/****************************************************************************************
  QUERY 3: BOTTOM 3 PRODUCTS PER STORE
  Purpose: Identify poorest-performing products at each location
  Business Value: Candidates for removal or promotional focus
****************************************************************************************/

WITH ProductSales AS (
    SELECT 
        s.StoreID,
        s.StoreLocation,
        i.ItemDescription,
        i.Category,
        SUM(f.Quantity) AS TotalQuantitySold,
        SUM(f.RowTotal) AS TotalRevenue,
        COUNT(DISTINCT f.ReceiptID) AS TimesOrdered,
        ROW_NUMBER() OVER (PARTITION BY s.StoreID ORDER BY SUM(f.RowTotal) ASC) AS RevenueRank
    FROM Fact_Sales f
    JOIN Dim_Store s ON f.StoreKey = s.StoreKey
    JOIN Dim_Item i ON f.ItemKey = i.ItemKey
    GROUP BY s.StoreID, s.StoreLocation, i.ItemDescription, i.Category
)
SELECT 
    StoreLocation,
    ItemDescription,
    Category,
    TotalQuantitySold,
    TotalRevenue,
    TimesOrdered,
    RevenueRank
FROM ProductSales
WHERE RevenueRank <= 3
ORDER BY StoreID, RevenueRank;

-- Expected Output: 30 rows (3 products � 10 stores)
-- Key Insight: Products consistently at bottom may need replacement

/****************************************************************************************
  QUERY 4: NATIONWIDE UNDERPERFORMING PRODUCTS
  Purpose: Identify products that underperform across ALL stores
  Business Value: Strong candidates for removal from menu
****************************************************************************************/

WITH NationalProductPerformance AS (
    SELECT 
        i.ItemDescription,
        i.Category,
        SUM(f.Quantity) AS TotalQuantitySold,
        SUM(f.RowTotal) AS TotalRevenue,
        COUNT(DISTINCT f.ReceiptID) AS TimesOrdered,
        COUNT(DISTINCT s.StoreID) AS StoresCarrying,
        AVG(f.Price) AS AvgPrice,
        SUM(f.RowTotal) / NULLIF(SUM(f.Quantity), 0) AS RevenuePerUnit
    FROM Fact_Sales f
    JOIN Dim_Item i ON f.ItemKey = i.ItemKey
    JOIN Dim_Store s ON f.StoreKey = s.StoreKey
    GROUP BY i.ItemDescription, i.Category
),
PerformanceRanking AS (
    SELECT 
        *,
        NTILE(4) OVER (ORDER BY TotalRevenue) AS PerformanceQuartile,
        NTILE(4) OVER (ORDER BY TotalQuantitySold) AS VolumeQuartile
    FROM NationalProductPerformance
)
SELECT 
    ItemDescription,
    Category,
    TotalQuantitySold,
    TotalRevenue,
    TimesOrdered,
    AvgPrice,
    RevenuePerUnit,
    PerformanceQuartile,
    VolumeQuartile
FROM PerformanceRanking
WHERE PerformanceQuartile = 1 OR VolumeQuartile = 1  -- Bottom quartile
ORDER BY TotalRevenue ASC;




-- Expected Output: ~4-5 products in bottom quartile
-- Key Insight: Products for removal or heavy discounting

/****************************************************************************************
  QUERY 5: LOYALTY PROGRAM EFFECTIVENESS
  Purpose: Analyze if loyalty members spend more and shop differently
  Business Value: Validate loyalty program ROI
****************************************************************************************/

WITH CustomerSegmentation AS (
    SELECT 
        f.CustomerKey,
        c.CustomerID,
        f.LoyaltyMember,
        COUNT(DISTINCT f.ReceiptID) AS TotalVisits,
        SUM(f.RowTotal) AS TotalSpend,
        SUM(f.Quantity) AS TotalItems,
        SUM(f.PointsEarned) AS TotalPoints,
        SUM(CASE WHEN f.DiscountFlag = 1 THEN f.BaseRowTotal - f.RowTotal ELSE 0 END) AS TotalDiscountReceived,
        AVG(f.RowTotal) AS AvgLineItemValue,
        MIN(d.FullDate) AS FirstPurchase,
        MAX(d.FullDate) AS LastPurchase,
        DATEDIFF(DAY, MIN(d.FullDate), MAX(d.FullDate)) AS CustomerLifespanDays
    FROM Fact_Sales f
    LEFT JOIN Dim_Customer c ON f.CustomerKey = c.CustomerKey
    JOIN Dim_Date d ON f.DateKey = d.DateKey
    WHERE f.CustomerKey IS NOT NULL
    GROUP BY f.CustomerKey, c.CustomerID, f.LoyaltyMember
)
SELECT 
    LoyaltyMember,
    COUNT(DISTINCT CustomerKey) AS TotalCustomers,
    AVG(TotalVisits) AS AvgVisitsPerCustomer,
    AVG(TotalSpend) AS AvgSpendPerCustomer,
    AVG(TotalItems) AS AvgItemsPerCustomer,
    SUM(TotalDiscountReceived) AS TotalDiscountsGiven,
    AVG(TotalDiscountReceived) AS AvgDiscountPerCustomer,
    AVG(CustomerLifespanDays) AS AvgCustomerLifespanDays,
    -- Calculate ROI: Revenue vs Discount
    SUM(TotalSpend) / NULLIF(SUM(TotalDiscountReceived), 0) AS RevenuePerDiscountDollar
FROM CustomerSegmentation
GROUP BY LoyaltyMember
ORDER BY LoyaltyMember DESC;

-- Expected Output: 2 rows (Yes/No loyalty members)
-- Key Insight: Are loyalty members actually more valuable?

/****************************************************************************************
  QUERY 6: MONTHLY REVENUE TRENDS (FOR FORECASTING)
  Purpose: Provide time series data for 12-month forecast
  Business Value: Support predictive modeling
****************************************************************************************/


SELECT 
    s.StoreID,
    s.StoreLocation,
    d.Year,
    d.MonthNumber,
    FORMAT(d.FullDate, 'MMM-yy') AS MonthName,
    COUNT(DISTINCT f.ReceiptID) AS MonthlyTransactions,
    SUM(f.RowTotal) AS MonthlyRevenue,
    SUM(f.Quantity) AS MonthlyItemsSold,
    AVG(f.RowTotal) AS AvgLineItemValue,
    COUNT(DISTINCT f.CustomerKey) AS UniqueCustomers
FROM Fact_Sales f
JOIN Dim_Store s ON f.StoreKey = s.StoreKey
JOIN Dim_Date d ON f.DateKey = d.DateKey
GROUP BY s.StoreID, s.StoreLocation, d.Year, d.MonthNumber, FORMAT(d.FullDate, 'MMM-yy')
ORDER BY s.StoreID, d.Year, d.MonthNumber;

-- Expected Output: ~120 rows (12 months � 10 stores)
-- Key Insight: Monthly trends for forecasting next 12 months

/****************************************************************************************
  QUERY 7: EMPLOYEE PERFORMANCE
  Purpose: Identify top-performing employees for recognition/upselling training
  Business Value: Reward high performers, train others
****************************************************************************************/

SELECT 
    e.EmployeeID,
    e.EmployeeFirstName + ' ' + e.EmployeeSurname AS EmployeeName,
    e.EmployeeRole,
    s.StoreLocation,
    COUNT(DISTINCT f.ReceiptID) AS TransactionsProcessed,
    SUM(f.RowTotal) AS TotalRevenueGenerated,
    SUM(f.RowTotal) / NULLIF(COUNT(DISTINCT f.ReceiptID), 0) AS AvgTransactionValue,
    SUM(CASE WHEN f.DiscountFlag = 1 THEN 1 ELSE 0 END) AS DiscountTransactions,
    COUNT(DISTINCT f.CustomerKey) AS UniqueCustomersServed
FROM Fact_Sales f
JOIN Dim_Employee e ON f.EmployeeKey = e.EmployeeKey
JOIN Dim_Store s ON f.StoreKey = s.StoreKey
GROUP BY e.EmployeeID, e.EmployeeFirstName, e.EmployeeSurname, e.EmployeeRole, s.StoreLocation
HAVING COUNT(DISTINCT f.ReceiptID) > 10  -- Filter for active employees
ORDER BY TotalRevenueGenerated DESC;

-- Expected Output: ~200 employees ranked by revenue
-- Key Insight: Who are the star employees?

/****************************************************************************************
  QUERY 8: DISCOUNT IMPACT ANALYSIS
  Purpose: Calculate actual ROI of 12.5% discount program
  Business Value: Determine if discount drives incremental sales
****************************************************************************************/

WITH DiscountAnalysis AS (
    SELECT 
        f.ReceiptID,
        MAX(CASE WHEN f.DiscountFlag = 1 THEN 1 ELSE 0 END) AS HasDiscount,
        SUM(f.BaseRowTotal) AS BaseTotal,
        SUM(f.RowTotal) AS FinalTotal,
        SUM(f.BaseRowTotal - f.RowTotal) AS DiscountAmount,
        COUNT(DISTINCT f.ItemKey) AS UniqueItems,
        SUM(f.Quantity) AS TotalQuantity
    FROM Fact_Sales f
    GROUP BY f.ReceiptID
)
SELECT 
    CASE WHEN HasDiscount = 1 THEN 'Discounted' ELSE 'Full Price' END AS TransactionType,
    COUNT(*) AS TotalTransactions,
    AVG(UniqueItems) AS AvgItemsPerTransaction,
    AVG(TotalQuantity) AS AvgQuantityPerTransaction,
    AVG(FinalTotal) AS AvgTransactionValue,
    SUM(DiscountAmount) AS TotalDiscountGiven,
    SUM(FinalTotal) AS TotalRevenue,
    SUM(FinalTotal) / NULLIF(SUM(DiscountAmount), 0) AS RevenuePerDiscountDollar
FROM DiscountAnalysis
GROUP BY CASE WHEN HasDiscount = 1 THEN 'Discounted' ELSE 'Full Price' END;

-- Expected Output: 2 rows comparing discounted vs non-discounted transactions
-- Key Insight: Is 12.5% discount worth it?

/****************************************************************************************
  QUERY 9: PRODUCT CATEGORY PERFORMANCE
  Purpose: Analyze revenue contribution by category
  Business Value: Understand product mix strategy
****************************************************************************************/

SELECT 
    i.Category,
    COUNT(DISTINCT i.ItemID) AS ProductCount,
    SUM(f.Quantity) AS TotalQuantitySold,
    SUM(f.RowTotal) AS TotalRevenue,
    AVG(f.Price) AS AvgPrice,
    SUM(f.RowTotal) / SUM(SUM(f.RowTotal)) OVER () * 100 AS RevenuePercentage,
    COUNT(DISTINCT f.CustomerKey) AS UniqueCustomers
FROM Fact_Sales f
JOIN Dim_Item i ON f.ItemKey = i.ItemKey
GROUP BY i.Category
ORDER BY TotalRevenue DESC;

-- Expected Output: 3-4 categories (Coffee, Merchandise, Other)
-- Key Insight: Which categories drive business

/****************************************************************************************
  QUERY 10: CUSTOMER RETENTION METRICS
  Purpose: Analyze customer return behavior
  Business Value: Understand customer lifetime value potential
****************************************************************************************/

WITH CustomerVisits AS (
    SELECT 
        f.CustomerKey,
        c.CustomerID,
        COUNT(DISTINCT f.ReceiptID) AS TotalVisits,
        MIN(d.FullDate) AS FirstVisit,
        MAX(d.FullDate) AS LastVisit,
        DATEDIFF(DAY, MIN(d.FullDate), MAX(d.FullDate)) AS DaysBetweenFirstLast,
        SUM(f.RowTotal) AS TotalSpent
    FROM Fact_Sales f
    LEFT JOIN Dim_Customer c ON f.CustomerKey = c.CustomerKey
    JOIN Dim_Date d ON f.DateKey = d.DateKey
    WHERE f.CustomerKey IS NOT NULL
    GROUP BY f.CustomerKey, c.CustomerID
)
SELECT 
    CASE 
        WHEN TotalVisits = 1 THEN '1 visit (One-time)'
        WHEN TotalVisits BETWEEN 2 AND 5 THEN '2-5 visits (Occasional)'
        WHEN TotalVisits BETWEEN 6 AND 15 THEN '6-15 visits (Regular)'
        WHEN TotalVisits > 15 THEN '15+ visits (Loyal)'
    END AS CustomerSegment,
    COUNT(*) AS CustomerCount,
    AVG(TotalVisits) AS AvgVisits,
    AVG(TotalSpent) AS AvgLifetimeValue,
    AVG(CASE WHEN TotalVisits > 1 THEN DaysBetweenFirstLast / (TotalVisits - 1.0) ELSE NULL END) AS AvgDaysBetweenVisits
FROM CustomerVisits
GROUP BY 
    CASE 
        WHEN TotalVisits = 1 THEN '1 visit (One-time)'
        WHEN TotalVisits BETWEEN 2 AND 5 THEN '2-5 visits (Occasional)'
        WHEN TotalVisits BETWEEN 6 AND 15 THEN '6-15 visits (Regular)'
        WHEN TotalVisits > 15 THEN '15+ visits (Loyal)'
    END
ORDER BY MIN(TotalVisits);

-- Expected Output: 4 segments showing customer loyalty distribution
-- Key Insight: Customer retention patterns

/****************************************************************************************
  END OF SQL ANALYSIS SCRIPTS
  
  ASSUMPTIONS MADE:
  1. All dates in Fact_Sales represent transaction dates (not future bookings)
  2. ReceiptID uniquely identifies a transaction across all stores
  3. Loyalty member status is consistent per receipt (as enforced in ETL)
  4. Discount of 12.5% only applies when 5+ distinct items AND loyalty member
  5. Points earned = FLOOR(RowTotal) regardless of discount status
  6. Historical pricing: Price in Fact_Sales is the price AT TIME of sale
  7. CustomerKey NULL represents guest (non-registered) purchases
  8. Store performance evaluated on revenue as primary metric
  
  USAGE:
  - Run each query individually in SQL Server Management Studio
  - Export results to Excel/CSV for reporting
  - Use Query 6 output for forecasting model input
  - Include query outputs as screenshots in final report
****************************************************************************************/
