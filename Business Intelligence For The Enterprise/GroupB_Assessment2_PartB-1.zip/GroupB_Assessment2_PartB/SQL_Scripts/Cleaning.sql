﻿
USE BeanBloomDataMart;
GO

-- Fresh copy
DROP TABLE IF EXISTS Working_Sales;
SELECT * INTO Working_Sales FROM Staging_Sales;

--  Add numeric columns
ALTER TABLE Working_Sales ADD
    Qty_Num INT NULL,
    Price_Num DECIMAL(10,2) NULL,
    RowTotal_Num DECIMAL(10,2) NULL,
    BaseRowTotal DECIMAL(10,2) NULL;

UPDATE Working_Sales
SET 
    ReceiptID = 119754,
    CustomerID = 'C177',
    CustomerFirstName = 'Samuel',
    CustomerSurName = 'Turner',
    EmployeeID = 'S195',
    EmployeeFirstName = 'Noah',
    EmployeeSurName = 'Bailey',
    StoreID = 10,
    StoreLocation = 'Broken Hill',
    TransactionRowID = 3,
    ItemID = 6,
    ItemQuantity = 1,
    ItemPrice = 18.95
WHERE ReceiptID IS NULL;

/* --------------------------------------------------------------
   FIX: Change 'Coffee Subscription' → 'Iced Latte' in ItemDescription
   -------------------------------------------------------------- */
UPDATE Working_Sales
SET ItemDescription = 'Iced Latte'
WHERE ItemDescription = 'Coffee Subscription';
GO

UPDATE Working_Sales
SET ItemDescription = '1kg House Blend Beans'
WHERE ItemDescription = 'Macchiato';
GO

/* --------------------------------------------------------------
   FIX: Correct ItemPrice > 30 → divide by 10 (string column)
   -------------------------------------------------------------- */
UPDATE Working_Sales
SET ItemPrice = 
    CASE 
        WHEN ISNUMERIC(ItemPrice) = 1 
         AND TRY_CAST(ItemPrice AS DECIMAL(10,2)) > 30
        THEN FORMAT(TRY_CAST(ItemPrice AS DECIMAL(10,2)) / 10.0, '0.##')
        ELSE ItemPrice 
    END
WHERE ItemPrice IS NOT NULL 
  AND LTRIM(RTRIM(ItemPrice)) <> '';
GO

PRINT 'ItemPrice > 30 corrected (divided by 10) in original column.';




UPDATE Working_Sales
SET
    Qty_Num = TRY_CAST(ItemQuantity AS INT),
    Price_Num = TRY_CAST(ItemPrice AS DECIMAL(10,2));

--  Clean & default values
UPDATE Working_Sales
SET
    Qty_Num = CASE WHEN Qty_Num IS NULL OR Qty_Num <= 0 THEN 1 ELSE Qty_Num END,
    Price_Num = COALESCE(Price_Num, 0),
    LoyaltyMember = COALESCE(LoyaltyMember, 'No'),
    DiscountApplied = COALESCE(DiscountApplied, 'No');



/* --------------------------------------------------------------
    Convert Excel serial → real DATE + MonthName 'MMM-yy'
   -------------------------------------------------------------- */

/* ---- Drop the old MonthName column (it is a DATE in Excel) ---- */
IF EXISTS (SELECT 1 FROM sys.columns 
           WHERE object_id = OBJECT_ID('Working_Sales') AND name = 'MonthName')
BEGIN
    ALTER TABLE Working_Sales DROP COLUMN MonthName;
    PRINT 'Old MonthName (DATE) dropped.';
END
GO

/* ----  Re-add MonthName as VARCHAR(7) for 'Jan-22' format ---- */
ALTER TABLE Working_Sales ADD MonthName VARCHAR(7) NULL;
PRINT 'MonthName added as VARCHAR(7).';
GO

/* ----  Add the real DATE column ---- */
ALTER TABLE Working_Sales ADD ConvertedSaleDate DATE NULL;
GO

/* ---- Convert the Excel serial number (44562) → real DATE ---- */
UPDATE Working_Sales
SET ConvertedSaleDate = 
    CASE 
        WHEN ISNUMERIC(SaleDate) = 1 
             AND TRY_CAST(SaleDate AS INT) > 0
        THEN DATEADD(DAY, CAST(SaleDate AS INT) - 2, '1900-01-01')   -- Excel leap-day bug
        ELSE TRY_CAST(SaleDate AS DATE)                              -- already a date string
    END
WHERE SaleDate IS NOT NULL;
GO

/* ----  Fill MonthName with 'Jan-22', 'Feb-22', … ---- */
UPDATE Working_Sales
SET MonthName = FORMAT(ConvertedSaleDate, 'MMM-yy')
WHERE ConvertedSaleDate IS NOT NULL;
GO



-- Remove duplicates
;WITH Dupes AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY ReceiptID, TransactionRowID ORDER BY SaleDate) AS rn
    FROM Working_Sales
)
DELETE FROM Dupes WHERE rn > 1;



-- =============================================================================
-- ONE EmployeeRole per EmployeeID (most frequent)
-- =============================================================================
DROP TABLE IF EXISTS #EmpRoleMaster;
SELECT
    EmployeeID,
    EmployeeRole,
    COUNT(*) AS RoleCount
INTO #EmpRoleMaster
FROM Working_Sales
WHERE EmployeeID != 'UNKNOWN' AND EmployeeRole IS NOT NULL
GROUP BY EmployeeID, EmployeeRole;

DROP TABLE IF EXISTS #FinalEmpRole;
SELECT
    EmployeeID,
    EmployeeRole
INTO #FinalEmpRole
FROM (
    SELECT EmployeeID, EmployeeRole,
           ROW_NUMBER() OVER (PARTITION BY EmployeeID ORDER BY RoleCount DESC) AS rn
    FROM #EmpRoleMaster
) ranked
WHERE rn = 1;

UPDATE w
SET w.EmployeeRole = f.EmployeeRole
FROM Working_Sales w
JOIN #FinalEmpRole f ON w.EmployeeID = f.EmployeeID;

DROP TABLE #EmpRoleMaster, #FinalEmpRole;

-- Fill missing EmployeeSurname
UPDATE w
SET w.EmployeeSurname = COALESCE(e.EmployeeSurname, 'Unknown')
FROM Working_Sales w
LEFT JOIN (
    SELECT EmployeeID, MAX(EmployeeSurname) AS EmployeeSurname
    FROM Working_Sales
    WHERE EmployeeSurname IS NOT NULL AND LTRIM(RTRIM(EmployeeSurname)) <> ''
    GROUP BY EmployeeID
) e ON w.EmployeeID = e.EmployeeID
WHERE w.EmployeeSurname IS NULL OR LTRIM(RTRIM(w.EmployeeSurname)) = '';

--  Consolidate ItemID
/* --------------------------------------------------------------
    REBUILD ItemID: ONE UNIQUE ID PER ItemDescription
   -------------------------------------------------------------- */
-- Step 1: Drop old temp tables if exist
DROP TABLE IF EXISTS #ItemMap;
GO

-- Step 2: Create mapping: 1 unique ItemID per ItemDescription
SELECT 
    ItemDescription,
    ROW_NUMBER() OVER (ORDER BY MIN(ItemID)) AS NewItemID  -- smallest original ID defines order
INTO #ItemMap
FROM Working_Sales
WHERE ItemDescription IS NOT NULL
GROUP BY ItemDescription;
GO

-- Step 3: Update Working_Sales with clean, unique ItemID
UPDATE w
SET w.ItemID = m.NewItemID
FROM Working_Sales w
JOIN #ItemMap m ON w.ItemDescription = m.ItemDescription;
GO

-- Step 4: Clean up
DROP TABLE #ItemMap;
GO

PRINT 'ItemID rebuilt: 15 unique IDs (1 to 15), one per ItemDescription';

/* --------------------------------------------------------------
   FIX: Make price consistent per item per date – use MOST FREQUENT price
   -------------------------------------------------------------- */
DROP TABLE IF EXISTS #ModePrice;
GO

-- Find the price that occurs most often for each item-date
WITH PriceCounts AS (
    SELECT
        ConvertedSaleDate,
        ItemID,
        Price_Num,
        COUNT(*) AS Freq,
        ROW_NUMBER() OVER (PARTITION BY ConvertedSaleDate, ItemID 
                           ORDER BY COUNT(*) DESC, Price_Num ASC) AS rn
    FROM Working_Sales
    WHERE Price_Num IS NOT NULL AND Price_Num > 0
    GROUP BY ConvertedSaleDate, ItemID, Price_Num
)
SELECT
    ConvertedSaleDate,
    ItemID,
    Price_Num AS ModePrice
INTO #ModePrice
FROM PriceCounts
WHERE rn = 1;      -- keep only the top-frequency price (tie → lowest price)
GO

-- Update Price_Num to the most frequent price
UPDATE w
SET w.Price_Num = m.ModePrice
FROM Working_Sales w
JOIN #ModePrice m
  ON w.ConvertedSaleDate = m.ConvertedSaleDate
 AND w.ItemID = m.ItemID;
GO

--  Sync the original string column ItemPrice
UPDATE w
SET w.ItemPrice = FORMAT(m.ModePrice, '0.##')
FROM Working_Sales w
JOIN #ModePrice m
  ON w.ConvertedSaleDate = m.ConvertedSaleDate
 AND w.ItemID = m.ItemID;
GO

DROP TABLE #ModePrice;
GO

PRINT 'Prices now consistent: most frequent price per item per date applied.';

--  BaseRowTotal = Qty * Price
UPDATE Working_Sales
SET
    BaseRowTotal = Qty_Num * Price_Num,
    RowTotal_Num = Qty_Num * Price_Num;

-- 11. UNIFY LoyaltyMember per ReceiptID
DROP TABLE IF EXISTS #LoyaltyFix;
SELECT
    ReceiptID,
    MAX(CASE WHEN LoyaltyMember = 'Yes' THEN 1 ELSE 0 END) AS IsLoyal
INTO #LoyaltyFix
FROM Working_Sales
GROUP BY ReceiptID;

UPDATE w
SET LoyaltyMember = CASE WHEN l.IsLoyal = 1 THEN 'Yes' ELSE 'No' END
FROM Working_Sales w
JOIN #LoyaltyFix l ON w.ReceiptID = l.ReceiptID;

DROP TABLE #LoyaltyFix;

-- 12. APPLY 12.5% DISCOUNT
DROP TABLE IF EXISTS #Trans;
SELECT
    ReceiptID,
    MAX(CASE WHEN LoyaltyMember = 'Yes' THEN 1 ELSE 0 END) AS IsLoyalty,
    COUNT(DISTINCT ItemID) AS DistinctItems
INTO #Trans
FROM Working_Sales
GROUP BY ReceiptID;

UPDATE w
SET
    DiscountApplied = CASE WHEN t.IsLoyalty = 1 AND t.DistinctItems >= 5 THEN 'Yes' ELSE 'No' END,
    DiscountFlag = CASE WHEN t.IsLoyalty = 1 AND t.DistinctItems >= 5 THEN 1 ELSE 0 END,
    RowTotal_Num = CASE
                        WHEN t.IsLoyalty = 1 AND t.DistinctItems >= 5
                        THEN ROUND(w.BaseRowTotal * 0.875, 2)
                        ELSE w.BaseRowTotal
                      END
FROM Working_Sales w
JOIN #Trans t ON w.ReceiptID = t.ReceiptID;

DROP TABLE #Trans;

-- 13. FINAL RowTotal sync
UPDATE Working_Sales
SET RowTotal = RowTotal_Num
WHERE RowTotal IS NULL OR ABS(RowTotal - RowTotal_Num) > 0.01;
--comment
UPDATE Working_Sales
SET EmployeeFirstName = 'Melissa'
WHERE EmployeeID = 'S9';

-- 14. PRICE VALIDATION
DROP TABLE IF EXISTS PriceValidation;
SELECT
    ItemID,
    MAX(ItemDescription) AS ItemDescription,
    COUNT(DISTINCT Price_Num) AS PriceVariations
INTO PriceValidation
FROM Working_Sales
WHERE ItemID > 0 AND Price_Num IS NOT NULL
GROUP BY ItemID;





