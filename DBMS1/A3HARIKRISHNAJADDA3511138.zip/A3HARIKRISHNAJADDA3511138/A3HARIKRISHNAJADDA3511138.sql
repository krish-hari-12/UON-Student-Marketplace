-- SQL Script for UNIE Library Database
-- Assignment 3 - Physical Database Design
-- Use hari;

-- First, drop all tables if they exist to ensure clean execution
DROP TABLE IF EXISTS Loan;
DROP TABLE IF EXISTS HoldRequest;
DROP TABLE IF EXISTS PhysicalCopyCollection;
DROP TABLE IF EXISTS PrivilegeCollection;
DROP TABLE IF EXISTS AcquisitionAuthor;
DROP TABLE IF EXISTS ItemAuthor;
DROP TABLE IF EXISTS Acquisition;
DROP TABLE IF EXISTS PhysicalCopyofItem;
DROP TABLE IF EXISTS DigitalCopyofItem;
DROP TABLE IF EXISTS MobileNo;
DROP TABLE IF EXISTS Member;
DROP TABLE IF EXISTS MemberType;
DROP TABLE IF EXISTS BookItem;
DROP TABLE IF EXISTS JournalItem;
DROP TABLE IF EXISTS OnlineDatabaseItem;
DROP TABLE IF EXISTS Collection;
DROP TABLE IF EXISTS Privilege;

-- Create tables with proper constraints

-- 1.Collection table
CREATE TABLE Collection (
    collectionId INT PRIMARY KEY,
    physicalLocation VARCHAR(100),
    campus VARCHAR(50),
    building VARCHAR(50),
    room VARCHAR(20),
    shelf VARCHAR(20)
);

-- 2. MemberType table
CREATE TABLE MemberType (
    typeId INT PRIMARY KEY,
    typeName VARCHAR(50) NOT NULL,
    maxLoanItems INT NOT NULL,
    loanPeriodDays INT NOT NULL
);

-- 3. Member table
CREATE TABLE Member (
    memberId INT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    joinDate DATE NOT NULL DEFAULT GETDATE(),
    memberTypeId INT NOT NULL,
    FOREIGN KEY (memberTypeId) REFERENCES MemberType(typeId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- 4. MobileNo table
CREATE TABLE MobileNo (
    mobileId INT PRIMARY KEY,
    memberId INT NOT NULL,
    mobileNumber VARCHAR(20) NOT NULL,
    isPrimary BIT DEFAULT 1,
    FOREIGN KEY (memberId) REFERENCES Member(memberId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

--5. BookItem table
CREATE TABLE BookItem (
    itemId INT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    publicationYear INT,
    publisher VARCHAR(100),
    isbn VARCHAR(20) UNIQUE,
    edition INT,
    itemType VARCHAR(20) DEFAULT 'Book'
);

--6. JournalItem table
CREATE TABLE JournalItem (
    itemId INT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    publicationYear INT,
    publisher VARCHAR(100),
    issn VARCHAR(20) UNIQUE,
    volume INT,
    issue INT,
    itemType VARCHAR(20) DEFAULT 'Journal'
);

-- OnlineDatabaseItem table
CREATE TABLE OnlineDatabaseItem (
    itemId INT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    publicationYear INT,
    publisher VARCHAR(100),
    url VARCHAR(255),
    accessKey VARCHAR(50),
    itemType VARCHAR(20) DEFAULT 'OnlineDatabase'
);

-- PhysicalCopyofItem table
CREATE TABLE PhysicalCopyofItem (
    barcode VARCHAR(50) PRIMARY KEY,
    itemId INT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Available',
    acquisitionDate DATE NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (itemId) REFERENCES BookItem(itemId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- DigitalCopyofItem table
CREATE TABLE DigitalCopyofItem (
    digitalId INT PRIMARY KEY,
    itemId INT NOT NULL,
    fileFormat VARCHAR(20) NOT NULL,
    fileSizeMB INT,
    accessLink VARCHAR(255),
    FOREIGN KEY (itemId) REFERENCES OnlineDatabaseItem(itemId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- Acquisition table (for new item requests)
CREATE TABLE Acquisition (
    acquisitionId INT PRIMARY KEY,
    memberId INT NOT NULL,
    itemTitle VARCHAR(100) NOT NULL,
    itemType VARCHAR(20) NOT NULL,
    requestDate DATE NOT NULL DEFAULT GETDATE(),
    status VARCHAR(20) DEFAULT 'Pending',
    reason VARCHAR(255),
    FOREIGN KEY (memberId) REFERENCES Member(memberId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- ItemAuthor table
CREATE TABLE ItemAuthor (
    authorId INT PRIMARY KEY,
    itemId INT NOT NULL,
    authorName VARCHAR(100) NOT NULL,
    authorRole VARCHAR(50),
    FOREIGN KEY (itemId) REFERENCES BookItem(itemId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- AcquisitionAuthor table (for new item request authors)
CREATE TABLE AcquisitionAuthor (
    authorId INT PRIMARY KEY,
    acquisitionId INT NOT NULL,
    authorName VARCHAR(100) NOT NULL,
    authorRole VARCHAR(50),
    FOREIGN KEY (acquisitionId) REFERENCES Acquisition(acquisitionId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- Privilege table
CREATE TABLE Privilege (
    privilegeId INT PRIMARY KEY,
    privilegeName VARCHAR(50) NOT NULL,
    description VARCHAR(255)
);

-- PrivilegeCollection table (junction table)
CREATE TABLE PrivilegeCollection (
    privilegeId INT NOT NULL,
    collectionId INT NOT NULL,
    PRIMARY KEY (privilegeId, collectionId),
    FOREIGN KEY (privilegeId) REFERENCES Privilege(privilegeId)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (collectionId) REFERENCES Collection(collectionId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- PhysicalCopyCollection table (junction table)
CREATE TABLE PhysicalCopyCollection (
    barcode VARCHAR(50) NOT NULL,
    collectionId INT NOT NULL,
    PRIMARY KEY (barcode, collectionId),
    FOREIGN KEY (barcode) REFERENCES PhysicalCopyofItem(barcode)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (collectionId) REFERENCES Collection(collectionId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- Loan table
CREATE TABLE Loan (
    loanId INT PRIMARY KEY,
    barcode VARCHAR(50) NOT NULL,
    memberId INT NOT NULL,
    loanDate DATE NOT NULL DEFAULT GETDATE(),
    dueDate DATE NOT NULL,
    returnDate DATE,
    FOREIGN KEY (barcode) REFERENCES PhysicalCopyofItem(barcode)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (memberId) REFERENCES Member(memberId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- HoldRequest table
CREATE TABLE HoldRequest (
    requestId INT PRIMARY KEY,
    memberId INT NOT NULL,
    itemId INT NOT NULL,
    requestDate DATE NOT NULL DEFAULT GETDATE(),
    status VARCHAR(20) DEFAULT 'Pending',
    fulfillmentDate DATE,
    FOREIGN KEY (memberId) REFERENCES Member(memberId)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (itemId) REFERENCES BookItem(itemId)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- Insert sample data into all tables

-- Insert MemberTypes
INSERT INTO MemberType (typeId, typeName, maxLoanItems, loanPeriodDays)
VALUES 
(1, 'Undergraduate', 5, 14),
(2, 'Postgraduate', 10, 28),
(3, 'Faculty', 15, 56),
(4, 'Researcher', 20, 84),
(5, 'Staff', 10, 28);

-- Insert Members
INSERT INTO Member (memberId, firstName, lastName, email, joinDate, memberTypeId)
VALUES
(101, 'John', 'Smith', 'john.smith@unie.edu', '2023-01-15', 1),
(102, 'Sarah', 'Johnson', 'sarah.j@unie.edu', '2022-09-10', 2),
(103, 'Michael', 'Brown', 'michael.b@unie.edu', '2024-02-20', 3),
(104, 'Emily', 'Davis', 'emily.d@unie.edu', '2023-11-05', 4),
(105, 'David', 'Wilson', 'david.w@unie.edu', '2024-01-30', 5),
(106, 'Jessica', 'Lee', 'jessica.lee@unie.edu', '2023-07-22', 1),
(107, 'Robert', 'Taylor', 'robert.t@unie.edu', '2022-12-18', 2),
(108, 'Jennifer', 'Anderson', 'jennifer.a@unie.edu', '2024-03-01', 3),
(109, 'Thomas', 'Martinez', 'thomas.m@unie.edu', '2023-05-14', 4),
(110, 'Lisa', 'Garcia', 'lisa.g@unie.edu', '2022-11-30', 5);

-- Insert Mobile Numbers
INSERT INTO MobileNo (mobileId, memberId, mobileNumber, isPrimary)
VALUES
(1, 101, '0412345678', 1),
(2, 101, '0423456789', 0),
(3, 102, '0434567890', 1),
(4, 103, '0445678901', 1),
(5, 104, '0456789012', 1),
(6, 105, '0467890123', 1),
(7, 106, '0478901234', 1),
(8, 107, '0489012345', 1),
(9, 108, '0490123456', 1),
(10, 109, '0401234567', 1),
(11, 110, '0411122233', 1);

-- Insert Collections
INSERT INTO Collection (collectionId, physicalLocation, campus, building, room, shelf)
VALUES
(1, 'Main Library', 'City', 'Library Building', 'L101', 'A1'),
(2, 'Science Collection', 'City', 'Science Building', 'S205', 'B3'),
(3, 'Engineering Section', 'North', 'Engineering Building', 'E102', 'C2'),
(4, 'Medical Library', 'South', 'Medical Center', 'M301', 'D4'),
(5, 'Archives', 'City', 'Library Building', 'L201', 'E5');

-- Insert Privileges
INSERT INTO Privilege (privilegeId, privilegeName, description)
VALUES
(1, 'Extended Loan', 'Allows longer loan periods for certain collections'),
(2, 'Priority Access', 'Gives priority access to high-demand items'),
(3, 'Extended Hours', 'Access to library outside normal operating hours'),
(4, 'Remote Access', 'Access to digital resources off-campus'),
(5, 'Interlibrary Loan', 'Ability to request items from other libraries');

-- Insert BookItems
INSERT INTO BookItem (itemId, title, publicationYear, publisher, isbn, edition, itemType)
VALUES
(1001, 'Database Design', 2023, 'Tech Publishers', '978-1234567890', 3, 'Book'),
(1002, 'Advanced SQL', 2022, 'Database Press', '978-0987654321', 2, 'Book'),
(1003, 'Data Structures', 2021, 'Algo Books', '978-1122334455', 1, 'Book'),
(1004, 'Machine Learning', 2023, 'AI Publications', '978-5566778899', 1, 'Book'),
(1005, 'Computer Networks', 2020, 'Networking Inc', '978-9988776655', 4, 'Book');

-- Insert JournalItems
INSERT INTO JournalItem (itemId, title, publicationYear, publisher, issn, volume, issue, itemType)
VALUES
(2001, 'Journal of Database Systems', 2024, 'Academic Press', '1234-5678', 15, 2, 'Journal'),
(2002, 'Computing Research', 2023, 'Science Publishers', '2345-6789', 12, 4, 'Journal'),
(2003, 'Information Technology', 2024, 'Tech Media', '3456-7890', 8, 1, 'Journal'),
(2004, 'Data Science Review', 2023, 'Data World', '4567-8901', 5, 3, 'Journal'),
(2005, 'Network Security', 2024, 'Security Press', '5678-9012', 10, 2, 'Journal');

-- Insert OnlineDatabaseItems
INSERT INTO OnlineDatabaseItem (itemId, title, publicationYear, publisher, url, accessKey, itemType)
VALUES
(3001, 'IEEE Digital Library', 2024, 'IEEE', 'https://ieeexplore.ieee.org', 'UNIE123', 'OnlineDatabase'),
(3002, 'ACM Digital Library', 2023, 'ACM', 'https://dl.acm.org', 'UNIE456', 'OnlineDatabase'),
(3003, 'ScienceDirect', 2024, 'Elsevier', 'https://www.sciencedirect.com', 'UNIE789', 'OnlineDatabase'),
(3004, 'JSTOR', 2023, 'ITHAKA', 'https://www.jstor.org', 'UNIE012', 'OnlineDatabase'),
(3005, 'SpringerLink', 2024, 'Springer', 'https://link.springer.com', 'UNIE345', 'OnlineDatabase');

-- Insert PhysicalCopies (only for existing BookItems)
INSERT INTO PhysicalCopyofItem (barcode, itemId, status, acquisitionDate)
VALUES
('BK1001A', 1001, 'Available', '2023-01-10'),
('BK1001B', 1001, 'On Loan', '2023-01-10'),
('BK1002A', 1002, 'Available', '2022-11-15'),
('BK1003A', 1003, 'Available', '2021-09-20'),
('BK1004A', 1004, 'Available', '2023-03-05'),
('BK1004B', 1004, 'Available', '2023-03-05'),
('BK1005A', 1005, 'Available', '2020-12-01');

-- Insert DigitalCopies (only for existing OnlineDatabaseItems)
INSERT INTO DigitalCopyofItem (digitalId, itemId, fileFormat, fileSizeMB, accessLink)
VALUES
(1, 3001, 'Online', NULL, 'https://ieeexplore.ieee.org'),
(2, 3002, 'Online', NULL, 'https://dl.acm.org'),
(3, 3003, 'Online', NULL, 'https://www.sciencedirect.com'),
(4, 3004, 'Online', NULL, 'https://www.jstor.org'),
(5, 3005, 'Online', NULL, 'https://link.springer.com');

-- Insert PrivilegeCollection (junction table)
INSERT INTO PrivilegeCollection (privilegeId, collectionId)
VALUES
(1, 1),
(1, 2),
(2, 3),
(3, 4),
(4, 5),
(5, 1);

-- Insert PhysicalCopyCollection (only for existing barcodes and collections)
INSERT INTO PhysicalCopyCollection (barcode, collectionId)
VALUES
('BK1001A', 1),
('BK1001B', 1),
('BK1002A', 2),
('BK1003A', 3),
('BK1004A', 4),
('BK1004B', 4),
('BK1005A', 5);

-- Insert Loans (only for existing barcodes and members)
INSERT INTO Loan (loanId, barcode, memberId, loanDate, dueDate, returnDate)
VALUES
(1, 'BK1001B', 101, '2024-03-01', '2024-03-15', NULL),
(2, 'BK1001A', 103, '2025-03-10', '2024-05-05', NULL),
(3, 'BK1001A', 102, '2025-02-15', '2024-03-14', '2024-03-10'),
(4, 'BK1002A', 104, '2024-01-20', '2024-04-14', NULL),
(5, 'BK1003A', 105, '2024-03-05', '2024-03-19', NULL),
(6, 'BK1004A', 101, '2024-02-28', '2024-03-13', '2024-03-12'),
(7, 'BK1005A', 103, '2024-01-10', '2024-03-06', '2024-03-05'),
(8, 'BK1002A', 102, '2024-03-12', '2024-04-09', NULL),
(9, 'BK1003A', 104, '2024-02-25', '2024-05-19', NULL),
(10, 'BK1004B', 105, '2024-03-15', '2024-04-12', NULL);

-- Insert HoldRequests (only for existing BookItems and members)
INSERT INTO HoldRequest (requestId, memberId, itemId, requestDate, status, fulfillmentDate)
VALUES
(1, 101, 1001, '2024-03-01', 'Fulfilled', '2024-03-10'),
(2, 102, 1002, '2024-02-15', 'Pending', NULL),
(3, 103, 1003, '2024-03-05', 'Pending', NULL),
(4, 104, 1004, '2024-01-20', 'Fulfilled', '2024-02-01'),
(5, 105, 1005, '2024-03-10', 'Pending', NULL),
(6, 101, 1001, '2024-02-28', 'Cancelled', NULL),
(7, 102, 1002, '2024-03-12', 'Pending', NULL),
(8, 103, 1003, '2024-02-25', 'Fulfilled', '2024-03-01'),
(9, 104, 1004, '2024-01-10', 'Fulfilled', '2024-01-15'),
(10, 105, 1005, '2024-03-15', 'Pending', NULL);

-- Insert Acquisitions (New Item Requests)
INSERT INTO Acquisition (acquisitionId, memberId, itemTitle, itemType, requestDate, status, reason)
VALUES
(1, 101, 'Advanced Database Systems', 'Book', '2024-01-05', 'Approved', 'Research needs'),
(2, 102, 'Quantum Computing Journal', 'Journal', '2024-02-10', 'Pending', 'Course reference'),
(3, 103, 'Cloud Computing Handbook', 'Book', '2024-03-01', 'Approved', 'Faculty research'),
(4, 104, 'AI Ethics Review', 'Journal', '2024-01-20', 'Rejected', 'Duplicate in collection'),
(5, 105, 'Network Security Database', 'OnlineDatabase', '2024-02-15', 'Approved', 'IT department request'),
(6, 101, 'Data Visualization Techniques', 'Book', '2025-01-10', 'Pending', 'Student project'),
(7, 102, 'Cybersecurity Trends', 'Journal', '2025-02-15', 'Pending', 'Thesis research'),
(8, 103, 'Blockchain Applications', 'Book', '2025-03-01', 'Pending', 'New course material'),
(9, 104, 'Bioinformatics Database', 'OnlineDatabase', '2025-01-20', 'Pending', 'Research group needs'),
(10, 105, 'Human-Computer Interaction', 'Book', '2025-02-05', 'Pending', 'Department request');

-- Insert ItemAuthors (only for existing BookItems)
INSERT INTO ItemAuthor (authorId, itemId, authorName, authorRole)
VALUES
(1, 1001, 'Alan Smith', 'Primary Author'),
(2, 1001, 'Beth Johnson', 'Co-Author'),
(3, 1002, 'Carlos Mendez', 'Primary Author'),
(4, 1003, 'Diana Chen', 'Primary Author'),
(5, 1004, 'Edward Wilson', 'Primary Author'),
(6, 1004, 'Fiona Brown', 'Co-Author'),
(7, 1005, 'George Davis', 'Primary Author'),
(8, 1005, 'Helen Taylor', 'Co-Author'),
(9, 1005, 'Ian Martinez', 'Co-Author'),
(10, 1001, 'Journal Editorial Board', 'Editor');

-- Insert AcquisitionAuthors (only for existing Acquisitions)
INSERT INTO AcquisitionAuthor (authorId, acquisitionId, authorName, authorRole)
VALUES
(1, 1, 'Robert Johnson', 'Primary Author'),
(2, 1, 'Sarah Williams', 'Co-Author'),
(3, 2, 'Journal Editorial Board', 'Editor'),
(4, 3, 'Michael Brown', 'Primary Author'),
(5, 3, 'Emily Davis', 'Co-Author'),
(6, 4, 'Research Team', 'Various'),
(7, 5, 'Security Experts', 'Various'),
(8, 6, 'David Wilson', 'Primary Author'),
(9, 7, 'Cybersecurity Team', 'Various'),
(10, 8, 'Blockchain Consortium', 'Various');

-- Implement the required queries

-- Q1:** Print the details about the NewItemRequest that were requested by the member named xxx in 2025, including the member's name,
--       mobile phone number, and the title(s) of the requested items.
SELECT 
    m.firstName + ' ' + m.lastName AS memberName,
    mn.mobileNumber,
    a.itemTitle AS requestedItemTitle,
    a.requestDate,
    a.status
FROM 
    Acquisition a
JOIN 
    Member m ON a.memberId = m.memberId
JOIN 
    MobileNo mn ON m.memberId = mn.memberId AND mn.isPrimary = 1
WHERE 
    m.firstName = 'John' 
    AND YEAR(a.requestDate) = 2025;

-- Q2: **Maximum borrowable items for member 'Sarah' with collectionId 1
SELECT 
    m.firstName + ' ' + m.lastName AS [Member Name],
    mt.typeName AS [Member Type],
    mt.maxLoanItems AS [Max Borrowable Items],
    c.collectionId AS [Collection ID],
    c.physicalLocation AS [Collection Location]
FROM 
    Member m
INNER JOIN 
    MemberType mt ON m.memberTypeId = mt.typeId
CROSS JOIN 
    Collection c
WHERE 
    m.firstName = 'Sarah'
    AND c.collectionId = 1;

-- Q3:** Hold Requests for memberId 101 in 2025
SELECT 
    m.memberId AS [Member ID],
    m.firstName + ' ' + m.lastName AS [Member Name],
    mn.mobileNumber AS [Mobile Number],
    COUNT(hr.requestId) AS [Total Hold Requests 2025]
FROM 
    Member m
INNER JOIN 
    MobileNo mn ON m.memberId = mn.memberId AND mn.isPrimary = 1
LEFT JOIN 
    HoldRequest hr ON m.memberId = hr.memberId AND YEAR(hr.requestDate) = 2024
WHERE 
    m.memberId = 101
GROUP BY 
    m.memberId, m.firstName, m.lastName, mn.mobileNumber;

-- Q4:** Members who borrowed "Database Design" this year with barcodes
SELECT 
    m.memberId AS [Member ID],
    m.firstName + ' ' + m.lastName AS [Member Name],
    l.barcode AS [Barcode],
    bi.title AS [Book Title],
    FORMAT(l.loanDate, 'yyyy-MM-dd') AS [Loan Date],
    FORMAT(l.dueDate, 'yyyy-MM-dd') AS [Due Date],
    CASE 
        WHEN l.returnDate IS NULL THEN 'Currently Borrowed'
        ELSE FORMAT(l.returnDate, 'yyyy-MM-dd') 
    END AS [Return Status]
FROM 
    Loan l
INNER JOIN 
    PhysicalCopyofItem pc ON l.barcode = pc.barcode
INNER JOIN 
    BookItem bi ON pc.itemId = bi.itemId
INNER JOIN 
    Member m ON l.memberId = m.memberId
WHERE 
    bi.title = 'Database Design'
    AND YEAR(l.loanDate) = YEAR(GETDATE())
ORDER BY 
    l.loanDate DESC;