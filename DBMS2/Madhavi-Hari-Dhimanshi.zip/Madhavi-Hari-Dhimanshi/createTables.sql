CREATE DATABASE Madhavi_Hari_Dhimanshi;
GO

USE Madhavi_Hari_Dhimanshi;
GO

-- Drop all existing tables if present in reverse dependency order
DROP TABLE IF EXISTS Customer_LoyaltyDiscount;
DROP TABLE IF EXISTS PackageService_VehicleCategory;
DROP TABLE IF EXISTS RegularService_VehicleCategory;
DROP TABLE IF EXISTS Booking_ExtraService;
DROP TABLE IF EXISTS Booking_Driver;
DROP TABLE IF EXISTS Booking_Vehicle;
DROP TABLE IF EXISTS Booking_PricedService;
DROP TABLE IF EXISTS Invoice;
DROP TABLE IF EXISTS VehicleTransaction;
DROP TABLE IF EXISTS PricedService;
DROP TABLE IF EXISTS Booking;
DROP TABLE IF EXISTS Driver;
DROP TABLE IF EXISTS ExtraService;
DROP TABLE IF EXISTS PackageServiceDetails;
DROP TABLE IF EXISTS RegularServiceDetails;
DROP TABLE IF EXISTS Service;
DROP TABLE IF EXISTS Vehicle;
DROP TABLE IF EXISTS AssociateDetails;
DROP TABLE IF EXISTS ManagerDetails;
DROP TABLE IF EXISTS Employee;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS LoyaltyDiscount;
DROP TABLE IF EXISTS VehicleCategory;
DROP TABLE IF EXISTS Branch;
GO

-- Branch table
CREATE TABLE Branch (
    branchId VARCHAR(10) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    address VARCHAR(100) NOT NULL,
    country VARCHAR(50) NOT NULL,
    phoneNumber VARCHAR(15) NOT NULL UNIQUE,
    currency VARCHAR(3) NOT NULL,
    operationalStatus VARCHAR(20) NOT NULL CHECK (operationalStatus IN ('Active', 'Inactive', 'Closed'))
);

-- VehicleCategory table
CREATE TABLE VehicleCategory (
    categoryId VARCHAR(10) PRIMARY KEY,
    name VARCHAR(20) NOT NULL UNIQUE,
    description VARCHAR(100),
    dailyRateMultiplier DECIMAL(3,2) NOT NULL DEFAULT 1.00,
    insuranceRate DECIMAL(5,2) NOT NULL
);

-- Employee table (superclass)
CREATE TABLE Employee (
    employeeId VARCHAR(10) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    position VARCHAR(20) NOT NULL CHECK (position IN ('Manager', 'Associate')),
    branchId VARCHAR(10) NOT NULL,
    FOREIGN KEY (branchId) REFERENCES Branch(branchId) ON UPDATE CASCADE ON DELETE CASCADE
);

-- ManagerDetails table (subclass)
CREATE TABLE ManagerDetails (
    employeeId VARCHAR(10) PRIMARY KEY,
    managerLevel VARCHAR(20) NOT NULL,
    approvalAuthority VARCHAR(20) NOT NULL,
    FOREIGN KEY (employeeId) REFERENCES Employee(employeeId) ON UPDATE CASCADE ON DELETE CASCADE
);

-- AssociateDetails table (subclass)
CREATE TABLE AssociateDetails (
    employeeId VARCHAR(10) PRIMARY KEY,
    specialization VARCHAR(50),
    FOREIGN KEY (employeeId) REFERENCES Employee(employeeId) ON UPDATE CASCADE ON DELETE CASCADE
);

-- LoyaltyDiscount table
CREATE TABLE LoyaltyDiscount (
    tierName VARCHAR(20) PRIMARY KEY,
    discountPercentage DECIMAL(3,2) NOT NULL,
    minimumRentals INT NOT NULL DEFAULT 0,
    benefits TEXT
);

-- Customer table
CREATE TABLE Customer (
    customerId VARCHAR(10) PRIMARY KEY,
    fullName VARCHAR(50) NOT NULL,
    contactDetails VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    licenseInformation VARCHAR(50) NOT NULL UNIQUE,
    loyaltyTier VARCHAR(20) NOT NULL CHECK (loyaltyTier IN ('Silver', 'Gold', 'Platinum')),
    tierDiscountPercentage DECIMAL(3,2) NOT NULL,
    FOREIGN KEY (loyaltyTier) REFERENCES LoyaltyDiscount(tierName)
);

-- Service table (superclass)
CREATE TABLE Service (
    serviceId VARCHAR(10) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description VARCHAR(100),
    basePrice DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('Available', 'Unavailable')),
    serviceType VARCHAR(20) NOT NULL CHECK (serviceType IN ('Regular', 'Package'))
);

-- RegularServiceDetails table (subclass)
CREATE TABLE RegularServiceDetails (
    serviceId VARCHAR(10) PRIMARY KEY,
    restrictions VARCHAR(100),
    FOREIGN KEY (serviceId) REFERENCES Service(serviceId) ON UPDATE CASCADE ON DELETE CASCADE
);

-- PackageServiceDetails table (subclass)
CREATE TABLE PackageServiceDetails (
    serviceId VARCHAR(10) PRIMARY KEY,
    validPeriodStart DATE NOT NULL,
    validPeriodEnd DATE NOT NULL,
    inclusions TEXT,
    exclusions TEXT,
    gracePeriod INT NOT NULL DEFAULT 1,
    FOREIGN KEY (serviceId) REFERENCES Service(serviceId) ON UPDATE CASCADE ON DELETE CASCADE,
    CHECK (validPeriodEnd >= validPeriodStart)
);

-- Vehicle table
CREATE TABLE Vehicle (
    vehicleId VARCHAR(10) PRIMARY KEY,
    make VARCHAR(20) NOT NULL,
    model VARCHAR(20) NOT NULL,
    year INT NOT NULL,
    registrationNumber VARCHAR(15) NOT NULL UNIQUE,
    status VARCHAR(20) NOT NULL CHECK (status IN ('Active', 'Inactive', 'Decommissioned')),
    mileage INT NOT NULL DEFAULT 0,
    seatingCapacity INT NOT NULL,
    fuelType VARCHAR(20) NOT NULL CHECK (fuelType IN ('Diesel', 'Petrol', 'Electric')),
    transmissionType VARCHAR(20) NOT NULL CHECK (transmissionType IN ('Manual', 'Automatic')),
    baseRentalRate DECIMAL(10,2) NOT NULL,
    branchId VARCHAR(10) NOT NULL,
    categoryId VARCHAR(10) NOT NULL,
    FOREIGN KEY (branchId) REFERENCES Branch(branchId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (categoryId) REFERENCES VehicleCategory(categoryId) ON UPDATE CASCADE ON DELETE CASCADE
);

-- PricedService table
CREATE TABLE PricedService (
    pricedServiceId VARCHAR(10) PRIMARY KEY,
    price DECIMAL(10,2) NOT NULL,
    pricingStartDate DATE NOT NULL,
    pricingEndDate DATE NOT NULL,
    approverManagerId VARCHAR(10) NOT NULL,
    serviceId VARCHAR(10) NOT NULL,
    branchId VARCHAR(10) NOT NULL,
    FOREIGN KEY (approverManagerId) REFERENCES Employee(employeeId),
    FOREIGN KEY (serviceId) REFERENCES Service(serviceId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (branchId) REFERENCES Branch(branchId) ON UPDATE CASCADE ON DELETE CASCADE,
    CHECK (pricingEndDate >= pricingStartDate)
);

-- ExtraService table
CREATE TABLE ExtraService (
    extraServiceId VARCHAR(10) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description VARCHAR(100),
    advertisedRate DECIMAL(10,2) NOT NULL
);

-- Booking table
CREATE TABLE Booking (
    bookingId VARCHAR(10) PRIMARY KEY,
    modeOfBooking VARCHAR(20) NOT NULL CHECK (modeOfBooking IN ('Website', 'App', 'Phone', 'In-person')),
    bookingDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    customerInformation VARCHAR(10) NOT NULL,
    numberOfPricedServices INT NOT NULL DEFAULT 1,
    numberOfVehicles INT NOT NULL DEFAULT 1,
    serviceStartDate DATE NOT NULL,
    serviceEndDate DATE NOT NULL,
    paymentMethod VARCHAR(20) NOT NULL,
    bookingDeposit DECIMAL(10,2) DEFAULT 0,
    bookingStatus VARCHAR(20) NOT NULL CHECK (bookingStatus IN ('Confirmed', 'Cancelled', 'Serviced')),
    customerId VARCHAR(10) NOT NULL,
    FOREIGN KEY (customerId) REFERENCES Customer(customerId) ON UPDATE CASCADE ON DELETE CASCADE,
    CHECK (serviceEndDate >= serviceStartDate)
);

-- Driver table
CREATE TABLE Driver (
    driverId VARCHAR(10) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    licenseInformation VARCHAR(50) NOT NULL,
    contactNumbers VARCHAR(50)
);

-- VehicleTransaction table
CREATE TABLE VehicleTransaction (
    transactionId VARCHAR(12) PRIMARY KEY,
    transactionType VARCHAR(20) NOT NULL CHECK (transactionType IN ('Pickup', 'Return')),
    actualDateTime DATETIME NOT NULL,
    vehicleCondition TEXT,
    mileageReading INT NOT NULL DEFAULT 0,
    fuelLevel TINYINT NOT NULL DEFAULT 100 CHECK (fuelLevel BETWEEN 0 AND 100),
    additionalCharges DECIMAL(8,2) DEFAULT 0.00,
    pickupDateTime DATETIME NOT NULL,
    returnDateTime DATETIME,
    pickupEmployeeId VARCHAR(10) NOT NULL,
    returnEmployeeId VARCHAR(10),
    bookingId VARCHAR(10) NOT NULL,
    vehicleId VARCHAR(10) NOT NULL,
    employeeId VARCHAR(10) NOT NULL,
    FOREIGN KEY (pickupEmployeeId) REFERENCES Employee(employeeId),
    FOREIGN KEY (returnEmployeeId) REFERENCES Employee(employeeId),
    FOREIGN KEY (bookingId) REFERENCES Booking(bookingId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (vehicleId) REFERENCES Vehicle(vehicleId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (employeeId) REFERENCES Employee(employeeId)
);

-- Invoice table
CREATE TABLE Invoice (
    invoiceId VARCHAR(10) PRIMARY KEY,
    baseRentalCharges DECIMAL(10,2) NOT NULL,
    extraServiceCharges DECIMAL(10,2) DEFAULT 0,
    totalLatePenalty DECIMAL(10,2) DEFAULT 0,
    totalDamagePenalty DECIMAL(10,2) DEFAULT 0,
    totalDiscount DECIMAL(10,2) DEFAULT 0,
    finalAmount DECIMAL(10,2) NOT NULL,
    paymentMethod VARCHAR(20) NOT NULL,
    discountApprovedBy VARCHAR(10),
    loyaltyDiscountApplied BIT NOT NULL DEFAULT 0,
    bookingId VARCHAR(10) NOT NULL UNIQUE,
    employeeId VARCHAR(10) NOT NULL,
    FOREIGN KEY (discountApprovedBy) REFERENCES Employee(employeeId),
    FOREIGN KEY (bookingId) REFERENCES Booking(bookingId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (employeeId) REFERENCES Employee(employeeId)
);

-- Junction tables
CREATE TABLE Booking_PricedService (
    bookingId VARCHAR(10),
    pricedServiceId VARCHAR(10),
    PRIMARY KEY (bookingId, pricedServiceId),
    FOREIGN KEY (bookingId) REFERENCES Booking(bookingId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (pricedServiceId) REFERENCES PricedService(pricedServiceId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Booking_Vehicle (
    bookingId VARCHAR(10),
    vehicleId VARCHAR(10),
    PRIMARY KEY (bookingId, vehicleId),
    FOREIGN KEY (bookingId) REFERENCES Booking(bookingId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (vehicleId) REFERENCES Vehicle(vehicleId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Booking_Driver (
    bookingId VARCHAR(10),
    driverId VARCHAR(10),
    PRIMARY KEY (bookingId, driverId),
    FOREIGN KEY (bookingId) REFERENCES Booking(bookingId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (driverId) REFERENCES Driver(driverId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Booking_ExtraService (
    bookingId VARCHAR(10),
    extraServiceId VARCHAR(10),
    quantity INT NOT NULL DEFAULT 1,
    PRIMARY KEY (bookingId, extraServiceId),
    FOREIGN KEY (bookingId) REFERENCES Booking(bookingId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (extraServiceId) REFERENCES ExtraService(extraServiceId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE RegularService_VehicleCategory (
    serviceId VARCHAR(10),
    categoryId VARCHAR(10),
    PRIMARY KEY (serviceId, categoryId),
    FOREIGN KEY (serviceId) REFERENCES RegularServiceDetails(serviceId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (categoryId) REFERENCES VehicleCategory(categoryId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE PackageService_VehicleCategory (
    serviceId VARCHAR(10),
    categoryId VARCHAR(10),
    PRIMARY KEY (serviceId, categoryId),
    FOREIGN KEY (serviceId) REFERENCES PackageServiceDetails(serviceId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (categoryId) REFERENCES VehicleCategory(categoryId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Customer_LoyaltyDiscount (
    customerId VARCHAR(10),
    tierName VARCHAR(20),
    PRIMARY KEY (customerId, tierName),
    FOREIGN KEY (customerId) REFERENCES Customer(customerId) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (tierName) REFERENCES LoyaltyDiscount(tierName) ON UPDATE CASCADE ON DELETE CASCADE
);
GO