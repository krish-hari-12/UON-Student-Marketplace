USE Madhavi_Hari_Dhimanshi;


-- Insert sample data
INSERT INTO Branch (branchId, name, address, country, phoneNumber, currency, operationalStatus)
VALUES 
('B001', 'Sydney CBD', '100 George St, Sydney', 'Australia', '+61291234567', 'AUD', 'Active'),
('B002', 'Melbourne Central', '200 Collins St, Melbourne', 'Australia', '+61391234568', 'AUD', 'Active'),
('B003', 'Brisbane Airport', 'Airport Dr, Brisbane', 'Australia', '+61791234569', 'AUD', 'Active'),
('B004', 'Perth City', '500 Hay St, Perth', 'Australia', '+61891234570', 'AUD', 'Active'),
('B005', 'Adelaide North', '100 North Terrace, Adelaide', 'Australia', '+61891234571', 'AUD', 'Active'),
('B006', 'Auckland Central', '50 Queen St, Auckland', 'New Zealand', '+6491234567', 'NZD', 'Active'),
('B007', 'Singapore Changi', '60 Airport Blvd, Singapore', 'Singapore', '+6561234567', 'SGD', 'Active'),
('B008', 'Bangkok Downtown', '100 Sukhumvit Rd, Bangkok', 'Thailand', '+6621234567', 'THB', 'Active'),
('B009', 'Jakarta Central', 'Jl. Thamrin No.1, Jakarta', 'Indonesia', '+62211234567', 'IDR', 'Active'),
('B010', 'Kuala Lumpur City', '50 Jalan Sultan, KL', 'Malaysia', '+6031234567', 'MYR', 'Active');

INSERT INTO VehicleCategory (categoryId, name, description, dailyRateMultiplier, insuranceRate)
VALUES 
('VC001', 'Economy', 'Compact cars with good fuel efficiency', 1.00, 15.00),
('VC002', 'Standard', 'Mid-size cars with more space', 1.25, 20.00),
('VC003', 'Luxury', 'Premium vehicles with high-end features', 2.00, 35.00),
('VC004', 'Commercial', 'Vans and trucks for business use', 1.75, 40.00),
('VC005', 'SUV', 'Sport utility vehicles for families', 1.50, 25.00);

INSERT INTO LoyaltyDiscount (tierName, discountPercentage, minimumRentals, benefits)
VALUES 
('Silver', 0.05, 5, '5% discount on rentals priority customer service'),
('Gold', 0.10, 15, '10% discount, free upgrades when available'),
('Platinum', 0.15, 30, '15% discount, free additional driver, guaranteed upgrades');

INSERT INTO Employee (employeeId, name, position, branchId)
VALUES 
-- Managers
('M001', 'John Smith', 'Manager', 'B001'),
('M002', 'Sarah Johnson', 'Manager', 'B002'),
('M003', 'Michael Brown', 'Manager', 'B003'),
('M004', 'Emily Davis', 'Manager', 'B004'),
('M005', 'David Wilson', 'Manager', 'B005'),
-- Associates
('A001', 'Robert Taylor', 'Associate', 'B001'),
('A002', 'Jennifer Anderson', 'Associate', 'B001'),
('A003', 'Thomas Martinez', 'Associate', 'B002'),
('A004', 'Lisa Robinson', 'Associate', 'B003'),
('A005', 'William Clark', 'Associate', 'B004'),
('A006', 'Jessica Rodriguez', 'Associate', 'B005'),
('A007', 'James Lee', 'Associate', 'B006'),
('A008', 'Karen Walker', 'Associate', 'B007'),
('A009', 'Richard Hall', 'Associate', 'B008'),
('A010', 'Nancy Young', 'Associate', 'B009');

INSERT INTO ManagerDetails (employeeId, managerLevel, approvalAuthority)
VALUES 
('M001', 'Senior', 'High'),
('M002', 'Mid', 'Medium'),
('M003', 'Junior', 'Low'),
('M004', 'Mid', 'Medium'),
('M005', 'Senior', 'High');

INSERT INTO AssociateDetails (employeeId, specialization)
VALUES 
('A001', 'Customer Service'),
('A002', 'Fleet Management'),
('A003', 'Sales'),
('A004', 'Customer Service'),
('A005', 'Fleet Management'),
('A006', 'Sales'),
('A007', 'International Rentals'),
('A008', 'Corporate Accounts'),
('A009', 'Luxury Vehicles'),
('A010', 'Commercial Fleet');

INSERT INTO Customer (customerId, fullName, contactDetails, email, licenseInformation, loyaltyTier, tierDiscountPercentage)
VALUES 
('C001', 'James Wilson', '+61400123456', 'james.wilson@email.com', 'NSW12345678', 'Silver', 0.05),
('C002', 'Mary Thompson', '+61411234567', 'mary.thompson@email.com', 'VIC23456789', 'Gold', 0.10),
('C003', 'Richard Garcia', '+61422345678', 'richard.garcia@email.com', 'QLD34567890', 'Platinum', 0.15),
('C004', 'Patricia Martinez', '+61433456789', 'patricia.martinez@email.com', 'WA45678901', 'Silver', 0.05),
('C005', 'Charles Robinson', '+61444567890', 'charles.robinson@email.com', 'SA56789012', 'Gold', 0.10),
('C006', 'Linda Clark', '+61455678901', 'linda.clark@email.com', 'NZ12345678', 'Silver', 0.05),
('C007', 'Daniel Rodriguez', '+6561234567', 'daniel.rodriguez@email.com', 'SG12345678', 'Silver', 0.05),
('C008', 'Elizabeth Lewis', '+6621234567', 'elizabeth.lewis@email.com', 'TH12345678', 'Gold', 0.10),
('C009', 'Matthew Lee', '+62211234567', 'matthew.lee@email.com', 'ID12345678', 'Platinum', 0.15),
('C010', 'Susan Walker', '+6031234567', 'susan.walker@email.com', 'MY12345678', 'Silver', 0.05);

INSERT INTO Customer_LoyaltyDiscount (customerId, tierName)
VALUES 
('C001', 'Silver'),
('C002', 'Gold'),
('C003', 'Platinum'),
('C004', 'Silver'),
('C005', 'Gold'),
('C006', 'Silver'),
('C007', 'Silver'),
('C008', 'Gold'),
('C009', 'Platinum'),
('C010', 'Silver');

INSERT INTO Service (serviceId, name, description, basePrice, currency, status, serviceType)
VALUES 
-- Regular services
('S001', 'Self-Drive', 'Standard self-drive rental', 50.00, 'AUD', 'Available', 'Regular'),
('S002', 'Chauffeur-Driven', 'Professional driver service', 100.00, 'AUD', 'Available', 'Regular'),
('S003', 'Airport-Shuttle', 'Airport transfer service', 75.00, 'AUD', 'Available', 'Regular'),
('S004', 'Fleet-Leasing', 'Commercial fleet leasing', 200.00, 'AUD', 'Available', 'Regular'),
-- Package services
('S005', 'Weekend Getaway', 'Weekend rental package', 150.00, 'AUD', 'Available', 'Package'),
('S006', 'Corporate Package', 'Business travel package', 300.00, 'AUD', 'Available', 'Package'),
('S007', 'Holiday Special', 'Extended holiday package', 500.00, 'AUD', 'Available', 'Package'),
('S008', 'Long-Term Lease', 'Monthly rental package', 1000.00, 'AUD', 'Available', 'Package'),
('S009', 'Luxury Experience', 'Premium vehicle package', 800.00, 'AUD', 'Available', 'Package'),
('S010', 'Family Vacation', 'SUV rental package', 400.00, 'AUD', 'Available', 'Package');

INSERT INTO RegularServiceDetails (serviceId, restrictions)
VALUES 
('S001', 'Minimum age 21, credit card required'),
('S002', 'Available only with Luxury vehicles'),
('S003', 'Airport pickup/dropoff only'),
('S004', 'Business registration required');

INSERT INTO PackageServiceDetails (serviceId, validPeriodStart, validPeriodEnd, inclusions, exclusions, gracePeriod)
VALUES 
('S005', '2023-01-01', '2023-12-31', 'Unlimited mileage, free navigator', 'Insurance not included', 2),
('S006', '2023-01-01', '2023-12-31', '3 vehicles, insurance included', 'Weekend use not included', 3),
('S007', '2023-06-01', '2023-08-31', '7-day rental, free child seats', 'Mileage limited to 1000km', 5),
('S008', '2023-01-01', '2023-12-31', 'Monthly rate, maintenance included', 'Damage waiver not included', 7),
('S009', '2023-01-01', '2023-12-31', 'Luxury vehicle, chauffeur service', 'Fuel not included', 2),
('S010', '2023-12-01', '2024-01-31', 'SUV, roof rack, child seats', 'Additional driver fee applies', 3);

INSERT INTO Vehicle (vehicleId, make, model, year, registrationNumber, status, mileage, seatingCapacity, fuelType, transmissionType, baseRentalRate, branchId, categoryId)
VALUES 
-- Sydney branch vehicles
('V001', 'Toyota', 'Corolla', 2022, 'NSW12345', 'Active', 15000, 5, 'Petrol', 'Automatic', 50.00, 'B001', 'VC001'),
('V002', 'Honda', 'Accord', 2021, 'NSW23456', 'Active', 20000, 5, 'Petrol', 'Automatic', 65.00, 'B001', 'VC002'),
('V003', 'BMW', '530i', 2023, 'NSW34567', 'Active', 5000, 5, 'Petrol', 'Automatic', 120.00, 'B001', 'VC003'),
('V004', 'Mercedes', 'Sprinter', 2022, 'NSW45678', 'Active', 25000, 12, 'Diesel', 'Automatic', 150.00, 'B001', 'VC004'),
-- Melbourne branch vehicles
('V005', 'Mazda', '3', 2022, 'VIC12345', 'Active', 18000, 5, 'Petrol', 'Automatic', 55.00, 'B002', 'VC001'),
('V006', 'Toyota', 'Camry', 2023, 'VIC23456', 'Active', 10000, 5, 'Petrol', 'Automatic', 70.00, 'B002', 'VC002'),
('V007', 'Audi', 'A6', 2022, 'VIC34567', 'Active', 12000, 5, 'Petrol', 'Automatic', 130.00, 'B002', 'VC003'),
-- Brisbane branch vehicles
('V008', 'Hyundai', 'i30', 2022, 'QLD12345', 'Active', 22000, 5, 'Petrol', 'Manual', 45.00, 'B003', 'VC001'),
('V009', 'Kia', 'Sorento', 2023, 'QLD23456', 'Active', 8000, 7, 'Diesel', 'Automatic', 90.00, 'B003', 'VC005'),
-- International branch vehicles
('V010', 'Toyota', 'Hiace', 2022, 'NZ12345', 'Active', 30000, 12, 'Diesel', 'Manual', 110.00, 'B006', 'VC004'),
('V011', 'Hyundai', 'Tucson', 2023, 'SG12345', 'Active', 5000, 5, 'Petrol', 'Automatic', 80.00, 'B007', 'VC005'),
('V012', 'Honda', 'City', 2022, 'TH12345', 'Active', 15000, 5, 'Petrol', 'Automatic', 60.00, 'B008', 'VC001'),
('V013', 'Toyota', 'Fortuner', 2023, 'ID12345', 'Active', 10000, 7, 'Diesel', 'Automatic', 95.00, 'B009', 'VC005'),
('V014', 'Proton', 'X70', 2022, 'MY12345', 'Active', 12000, 5, 'Petrol', 'Automatic', 70.00, 'B010', 'VC002');

INSERT INTO PricedService (pricedServiceId, price, pricingStartDate, pricingEndDate, approverManagerId, serviceId, branchId)
VALUES 
-- Sydney branch priced services
('PS001', 55.00, '2023-01-01', '2023-12-31', 'M001', 'S001', 'B001'),
('PS002', 110.00, '2023-01-01', '2023-12-31', 'M001', 'S002', 'B001'),
('PS003', 160.00, '2023-06-01', '2023-08-31', 'M001', 'S005', 'B001'),
-- Melbourne branch priced services
('PS004', 60.00, '2023-01-01', '2023-12-31', 'M002', 'S001', 'B002'),
('PS005', 320.00, '2023-01-01', '2023-12-31', 'M002', 'S006', 'B002'),
-- Brisbane branch priced services
('PS006', 50.00, '2023-01-01', '2023-12-31', 'M003', 'S001', 'B003'),
('PS007', 420.00, '2023-12-01', '2024-01-31', 'M003', 'S010', 'B003'),
-- International branch priced services
('PS008', 65.00, '2023-01-01', '2023-12-31', 'M001', 'S001', 'B006'), -- NZ
('PS009', 85.00, '2023-01-01', '2023-12-31', 'M001', 'S001', 'B007'), -- SG
('PS010', 850.00, '2023-01-01', '2023-12-31', 'M001', 'S009', 'B008'); -- TH

INSERT INTO ExtraService (extraServiceId, name, description, advertisedRate)
VALUES 
('ES001', 'Child Seat', 'Safety seat for children', 10.00),
('ES002', 'GPS Navigator', 'Satellite navigation system', 15.00),
('ES003', 'Additional Driver', 'Extra authorized driver', 20.00),
('ES004', 'Insurance Upgrade', 'Premium coverage insurance', 25.00),
('ES005', 'Roof Rack', 'Vehicle roof storage system', 30.00),
('ES006', 'WiFi Hotspot', 'Mobile internet access', 12.00),
('ES007', 'Winter Tyres', 'Snow and ice tyres', 40.00),
('ES008', 'Airport Fee', 'Airport location surcharge', 35.00);

INSERT INTO Driver (driverId, name, licenseInformation, contactNumbers)
VALUES 
('D001', 'Alan Parker', 'NSW98765432', '+61400987654'),
('D002', 'Betty White', 'VIC87654321', '+61411876543'),
('D003', 'Charles Green', 'QLD76543210', '+61422765432'),
('D004', 'Diana Black', 'WA65432109', '+61433654321'),
('D005', 'Edward King', 'NZ98765432', '+6499876543'),
('D006', 'Fiona Hill', 'SG87654321', '+6587654321'),
('D007', 'George Stone', 'TH76543210', '+6676543210');

INSERT INTO Booking (bookingId, modeOfBooking, bookingDate, customerInformation, numberOfPricedServices, numberOfVehicles, serviceStartDate, serviceEndDate, paymentMethod, bookingDeposit, bookingStatus, customerId)
VALUES 
-- Confirmed bookings
('BK001', 'Website', '2023-05-01 10:00:00', 'C001', 1, 1, '2023-06-15', '2023-06-18', 'Credit Card', 50.00, 'Confirmed', 'C001'),
('BK002', 'App', '2023-05-10 14:30:00', 'C002', 1, 1, '2023-07-01', '2023-07-08', 'Credit Card', 100.00, 'Confirmed', 'C002'),
('BK003', 'Phone', '2023-05-15 11:20:00', 'C003', 1, 2, '2023-06-20', '2023-06-27', 'Debit Card', 150.00, 'Confirmed', 'C003'),
-- Serviced bookings (completed rentals)
('BK004', 'In-person', '2023-04-01 09:15:00', 'C004', 1, 1, '2023-04-15', '2023-04-17', 'Cash', 30.00, 'Serviced', 'C004'),
('BK005', 'Website', '2023-04-05 16:45:00', 'C005', 1, 1, '2023-04-20', '2023-04-25', 'Credit Card', 75.00, 'Serviced', 'C005'),
-- Cancelled bookings
('BK006', 'App', '2023-05-20 13:10:00', 'C006', 1, 1, '2023-07-10', '2023-07-15', 'Credit Card', 50.00, 'Cancelled', 'C006'),
-- International bookings
('BK007', 'Website', '2023-05-25 08:30:00', 'C007', 1, 1, '2023-07-05', '2023-07-12', 'Credit Card', 65.00, 'Confirmed', 'C007'),
('BK008', 'Phone', '2023-05-28 15:20:00', 'C008', 1, 1, '2023-08-01', '2023-08-10', 'Credit Card', 85.00, 'Confirmed', 'C008'),
('BK009', 'App', '2023-06-01 10:45:00', 'C009', 1, 1, '2023-09-15', '2023-09-30', 'Credit Card', 200.00, 'Confirmed', 'C009'),
('BK010', 'Website', '2023-06-05 12:00:00', 'C010', 1, 1, '2023-08-20', '2023-08-25', 'Debit Card', 70.00, 'Confirmed', 'C010');

INSERT INTO Booking_PricedService (bookingId, pricedServiceId)
VALUES 
('BK001', 'PS001'),
('BK002', 'PS003'),
('BK003', 'PS005'),
('BK004', 'PS004'),
('BK005', 'PS002'),
('BK006', 'PS006'),
('BK007', 'PS008'),
('BK008', 'PS009'),
('BK009', 'PS010'),
('BK010', 'PS007');

INSERT INTO Booking_Vehicle (bookingId, vehicleId)
VALUES 
('BK001', 'V001'),
('BK002', 'V003'),
('BK003', 'V006'),
('BK003', 'V007'),
('BK004', 'V005'),
('BK005', 'V002'),
('BK006', 'V008'),
('BK007', 'V010'),
('BK008', 'V011'),
('BK009', 'V012'),
('BK010', 'V009');

INSERT INTO Booking_Driver (bookingId, driverId)
VALUES 
('BK002', 'D001'),
('BK005', 'D002'),
('BK008', 'D006'),
('BK009', 'D007');

INSERT INTO Booking_ExtraService (bookingId, extraServiceId, quantity)
VALUES 
('BK001', 'ES002', 1),
('BK002', 'ES001', 2),
('BK002', 'ES003', 1),
('BK003', 'ES004', 1),
('BK004', 'ES002', 1),
('BK005', 'ES001', 1),
('BK007', 'ES003', 1),
('BK008', 'ES006', 1),
('BK009', 'ES005', 1),
('BK010', 'ES001', 2);

INSERT INTO RegularService_VehicleCategory (serviceId, categoryId)
VALUES 
('S001', 'VC001'),
('S001', 'VC002'),
('S001', 'VC003'),
('S001', 'VC005'),
('S002', 'VC003'),
('S003', 'VC001'),
('S003', 'VC002'),
('S003', 'VC005'),
('S004', 'VC004');

INSERT INTO PackageService_VehicleCategory (serviceId, categoryId)
VALUES 
('S005', 'VC001'),
('S005', 'VC002'),
('S006', 'VC002'),
('S007', 'VC001'),
('S007', 'VC002'),
('S007', 'VC005'),
('S008', 'VC001'),
('S008', 'VC002'),
('S008', 'VC004'),
('S009', 'VC003'),
('S010', 'VC005');

INSERT INTO VehicleTransaction (transactionId, transactionType, actualDateTime, vehicleCondition, mileageReading, fuelLevel, additionalCharges, pickupDateTime, returnDateTime, pickupEmployeeId, returnEmployeeId, bookingId, vehicleId, employeeId)
VALUES 
-- Completed rental transactions
('VT001', 'Pickup', '2023-04-15 09:00:00', 'Excellent condition, no visible damage', 18000, 100, 0.00, '2023-04-15 09:00:00', NULL, 'A001', NULL, 'BK004', 'V005', 'A001'),
('VT002', 'Return', '2023-04-17 14:30:00', 'Small scratch on rear bumper', 18250, 75, 50.00, '2023-04-15 09:00:00', '2023-04-17 14:30:00', 'A001', 'A002', 'BK004', 'V005', 'A002'),
('VT003', 'Pickup', '2023-04-20 10:15:00', 'Excellent condition, no visible damage', 20000, 100, 0.00, '2023-04-20 10:15:00', NULL, 'A003', NULL, 'BK005', 'V002', 'A003'),
('VT004', 'Return', '2023-04-25 16:45:00', 'Clean interior, minor wear on tires', 20500, 50, 0.00, '2023-04-20 10:15:00', '2023-04-25 16:45:00', 'A003', 'A004', 'BK005', 'V002', 'A004'),
-- Upcoming pickup transactions
('VT005', 'Pickup', '2023-06-15 08:00:00', 'Excellent condition, no visible damage', 15000, 100, 0.00, '2023-06-15 08:00:00', NULL, 'A001', NULL, 'BK001', 'V001', 'A001'),
('VT006', 'Pickup', '2023-07-01 09:30:00', 'Excellent condition, no visible damage', 5000, 100, 0.00, '2023-07-01 09:30:00', NULL, 'A002', NULL, 'BK002', 'V003', 'A002'),
('VT007', 'Pickup', '2023-06-20 10:00:00', 'Excellent condition, no visible damage', 10000, 100, 0.00, '2023-06-20 10:00:00', NULL, 'A003', NULL, 'BK003', 'V006', 'A003'),
('VT008', 'Pickup', '2023-06-20 10:15:00', 'Excellent condition, no visible damage', 12000, 100, 0.00, '2023-06-20 10:15:00', NULL, 'A003', NULL, 'BK003', 'V007', 'A003');

INSERT INTO Invoice(invoiceId, baseRentalCharges, extraServiceCharges, totalLatePenalty, totalDamagePenalty, totalDiscount, finalAmount, paymentMethod, discountApprovedBy, loyaltyDiscountApplied, bookingId, employeeId)
VALUES 
-- Invoice for BK004
('IN001', 110.00, 15.00, 0.00, 50.00, 5.50, 169.50, 'Cash', NULL, 1, 'BK004', 'A002'),
-- Invoice for BK005
('IN002', 600.00, 10.00, 0.00, 0.00, 60.00, 550.00, 'Credit Card', NULL, 1, 'BK005', 'A004');
GO