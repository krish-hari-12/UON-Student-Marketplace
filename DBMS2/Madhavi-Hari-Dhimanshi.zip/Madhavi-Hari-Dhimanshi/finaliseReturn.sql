USE Madhavi_Hari_Dhimanshi;

CREATE TYPE VehicleReturnList AS TABLE (
    vehicleId VARCHAR(10),
    vehicleCondition TEXT,
    mileageReading INT,
    fuelLevel TINYINT,
    damagePenalty DECIMAL(10,2),
    lateHours INT
);
GO
-- Enhanced return processing procedure
CREATE OR ALTER PROCEDURE usp_ProcessReturn
    @bookingId VARCHAR(10),
    @employeeId VARCHAR(10),
    @vehicleReturns VehicleReturnList READONLY,
    @discountAmount DECIMAL(10,2) = 0,
    @discountReason VARCHAR(100) = NULL
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Validate parameters
        IF NOT EXISTS (SELECT 1 FROM Booking WHERE bookingId = @bookingId)
        BEGIN
            RAISERROR('Booking not found.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Check if booking is confirmed
        DECLARE @bookingStatus VARCHAR(20);
        SELECT @bookingStatus = bookingStatus FROM Booking WHERE bookingId = @bookingId;
        
        IF @bookingStatus != 'Confirmed'
        BEGIN
            RAISERROR('Booking is not in Confirmed status.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Check if employee exists
        IF NOT EXISTS (SELECT 1 FROM Employee WHERE employeeId = @employeeId)
        BEGIN
            RAISERROR('Employee does not exist.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Check if all vehicles in booking are being returned
        DECLARE @expectedVehicleCount INT;
        DECLARE @returnedVehicleCount INT;
        
        SELECT @expectedVehicleCount = COUNT(*) 
        FROM Booking_Vehicle 
        WHERE bookingId = @bookingId;
        
        SELECT @returnedVehicleCount = COUNT(*) 
        FROM @vehicleReturns;
        
        IF @expectedVehicleCount != @returnedVehicleCount
        BEGIN
            RAISERROR('Not all vehicles in this booking are being returned.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Check if all returned vehicles belong to this booking
        IF EXISTS (
            SELECT 1 FROM @vehicleReturns vr
            WHERE NOT EXISTS (
                SELECT 1 FROM Booking_Vehicle bv
                WHERE bv.bookingId = @bookingId AND bv.vehicleId = vr.vehicleId
            )
        )
        BEGIN
            RAISERROR('One or more vehicles do not belong to this booking.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Get booking details
        DECLARE @customerId VARCHAR(10);
        DECLARE @serviceStartDate DATE;
        DECLARE @serviceEndDate DATE;
        DECLARE @bookingDeposit DECIMAL(10,2);
        DECLARE @paymentMethod VARCHAR(20);
        DECLARE @loyaltyTier VARCHAR(20);
        DECLARE @loyaltyDiscount DECIMAL(3,2);
        
        SELECT 
            @customerId = customerId,
            @serviceStartDate = serviceStartDate,
            @serviceEndDate = serviceEndDate,
            @bookingDeposit = bookingDeposit,
            @paymentMethod = paymentMethod
        FROM Booking 
        WHERE bookingId = @bookingId;
        
        SELECT 
            @loyaltyTier = loyaltyTier,
            @loyaltyDiscount = tierDiscountPercentage
        FROM Customer 
        WHERE customerId = @customerId;

        -- Process each vehicle return
        DECLARE @totalBaseRentalCharges DECIMAL(10,2) = 0;
        DECLARE @totalExtraServiceCharges DECIMAL(10,2) = 0;
        DECLARE @totalLatePenalty DECIMAL(10,2) = 0;
        DECLARE @totalDamagePenalty DECIMAL(10,2) = 0;
        DECLARE @totalFuelCharge DECIMAL(10,2) = 0;
        
        DECLARE @vehicleId VARCHAR(10);
        DECLARE @condition NVARCHAR(MAX); -- Changed from TEXT to NVARCHAR(MAX)
        DECLARE @mileage INT;
        DECLARE @fuelLevel TINYINT;
        DECLARE @damagePenalty DECIMAL(10,2);
        DECLARE @lateHours INT;
        
        DECLARE return_cursor CURSOR FOR 
        SELECT 
            vehicleId, 
            vehicleCondition, 
            mileageReading, 
            fuelLevel, 
            damagePenalty, 
            lateHours 
        FROM @vehicleReturns;
        
        OPEN return_cursor;
        FETCH NEXT FROM return_cursor INTO @vehicleId, @condition, @mileage, @fuelLevel, @damagePenalty, @lateHours;
        
        WHILE @@FETCH_STATUS = 0
        BEGIN
            -- Get pickup transaction for this vehicle
            DECLARE @pickupDateTime DATETIME;
            DECLARE @pickupEmployeeId VARCHAR(10);
            
            SELECT 
                @pickupDateTime = pickupDateTime,
                @pickupEmployeeId = pickupEmployeeId
            FROM VehicleTransaction
            WHERE bookingId = @bookingId 
              AND vehicleId = @vehicleId
              AND transactionType = 'Pickup';
            
            IF @pickupDateTime IS NULL
            BEGIN
                RAISERROR('Pickup transaction not found for vehicle %s', @vehicleId, 16, 1);
                ROLLBACK;
                RETURN;
            END
            
            -- Calculate rental days (original and actual)
            DECLARE @originalDays INT = DATEDIFF(DAY, @serviceStartDate, @serviceEndDate) + 1;
            DECLARE @actualDays INT = DATEDIFF(HOUR, @pickupDateTime, GETDATE()) / 24;
            IF DATEDIFF(HOUR, @pickupDateTime, GETDATE()) % 24 > 0 SET @actualDays = @actualDays + 1;
            
            -- Calculate late penalty if not provided
            DECLARE @latePenalty DECIMAL(10,2) = 0;
            DECLARE @lateFeePerHour DECIMAL(10,2) = 10.00; -- Standard late fee
            
            IF @lateHours IS NULL OR @lateHours = 0
            BEGIN
                IF @actualDays > @originalDays
                BEGIN
                    SET @lateHours = (@actualDays - @originalDays) * 24;
                    SET @latePenalty = @lateHours * @lateFeePerHour;
                END
            END
            ELSE
            BEGIN
                SET @latePenalty = @lateHours * @lateFeePerHour;
            END
            
            -- Get base rental rate from vehicle and category
            DECLARE @baseRentalRate DECIMAL(10,2);
            DECLARE @dailyRateMultiplier DECIMAL(3,2);
            
            SELECT 
                @baseRentalRate = v.baseRentalRate,
                @dailyRateMultiplier = vc.dailyRateMultiplier
            FROM Vehicle v
            JOIN VehicleCategory vc ON v.categoryId = vc.categoryId
            WHERE v.vehicleId = @vehicleId;
            
            -- Calculate base rental charges for this vehicle
            DECLARE @baseRentalCharges DECIMAL(10,2) = @baseRentalRate * @dailyRateMultiplier * @originalDays;
            SET @totalBaseRentalCharges = @totalBaseRentalCharges + @baseRentalCharges;
            
            -- Calculate fuel charge if not returned with full tank
            DECLARE @fuelCharge DECIMAL(10,2) = 0;
            DECLARE @fuelCostPerLiter DECIMAL(5,2) = 1.80; -- Average fuel cost
            
            IF @fuelLevel < 100
            BEGIN
                -- Assuming 50L tank capacity for calculation
                SET @fuelCharge = (100 - @fuelLevel) * 0.5 * @fuelCostPerLiter;
                SET @totalFuelCharge = @totalFuelCharge + @fuelCharge;
            END
            
            -- Accumulate penalties
            SET @totalLatePenalty = @totalLatePenalty + @latePenalty;
            SET @totalDamagePenalty = @totalDamagePenalty + ISNULL(@damagePenalty, 0);
            
            -- Update vehicle status and mileage
            UPDATE Vehicle
            SET mileage = @mileage,
                status = 'Active' -- Ensure vehicle is marked as available
            WHERE vehicleId = @vehicleId;
            
            -- Insert return transaction for this vehicle
            INSERT INTO VehicleTransaction (
                transactionId, transactionType, actualDateTime, vehicleCondition, 
                mileageReading, fuelLevel, additionalCharges, pickupDateTime, 
                returnDateTime, pickupEmployeeId, returnEmployeeId, bookingId, 
                vehicleId, employeeId
            )
            VALUES (
                'VT' + RIGHT('0000' + CAST(ABS(CHECKSUM(NEWID())) % 10000 AS VARCHAR(4)), 4),
                'Return', GETDATE(), @condition,
                @mileage, @fuelLevel, ISNULL(@damagePenalty, 0) + @latePenalty + @fuelCharge, 
                @pickupDateTime, GETDATE(), 
                @pickupEmployeeId, @employeeId, @bookingId, 
                @vehicleId, @employeeId
            );
            
            FETCH NEXT FROM return_cursor INTO @vehicleId, @condition, @mileage, @fuelLevel, @damagePenalty, @lateHours;
        END
        
        CLOSE return_cursor;
        DEALLOCATE return_cursor;
        
        -- Calculate extra service charges (shared across all vehicles)
        SELECT @totalExtraServiceCharges = ISNULL(SUM(es.advertisedRate * bes.quantity), 0)
        FROM Booking_ExtraService bes
        JOIN ExtraService es ON bes.extraServiceId = es.extraServiceId
        WHERE bes.bookingId = @bookingId;
        
        -- Handle discounts
        DECLARE @discountApprovedBy VARCHAR(10) = NULL;
        DECLARE @loyaltyDiscountApplied BIT = 0;
        DECLARE @totalDiscount DECIMAL(10,2) = 0;
        
        -- Check if discount is being applied
        IF @discountAmount > 0
        BEGIN
            -- Check if employee is authorized to approve discounts
            DECLARE @employeePosition VARCHAR(20);
            SELECT @employeePosition = position FROM Employee WHERE employeeId = @employeeId;
            
            -- For non-loyalty discounts, require manager approval
            IF @discountAmount > (@totalBaseRentalCharges * @loyaltyDiscount)
            BEGIN
                IF @employeePosition != 'Manager'
                BEGIN
                    RAISERROR('Only managers can approve additional discounts beyond loyalty benefits.', 16, 1);
                    ROLLBACK;
                    RETURN;
                END
                SET @discountApprovedBy = @employeeId;
            END
            
            -- Apply loyalty discount automatically
            IF @loyaltyDiscount > 0
            BEGIN
                SET @loyaltyDiscountApplied = 1;
                SET @totalDiscount = @totalBaseRentalCharges * @loyaltyDiscount;
                
                -- Add any additional approved discount
                IF @discountAmount > @totalDiscount
                BEGIN
                    SET @totalDiscount = @discountAmount;
                END
            END
            ELSE
            BEGIN
                -- Non-loyalty customer discount (must be approved by manager)
                SET @totalDiscount = @discountAmount;
            END
        END
        ELSE IF @loyaltyDiscount > 0
        BEGIN
            -- Apply standard loyalty discount
            SET @loyaltyDiscountApplied = 1;
            SET @totalDiscount = @totalBaseRentalCharges * @loyaltyDiscount;
        END
        
        -- Calculate final amount (ensure it's never negative)
        DECLARE @finalAmount DECIMAL(10,2) = 
            @totalBaseRentalCharges - @totalDiscount + 
            @totalExtraServiceCharges + @totalLatePenalty + 
            @totalDamagePenalty + @totalFuelCharge;
            
        -- Apply booking deposit
        SET @finalAmount = @finalAmount - ISNULL(@bookingDeposit, 0);
        
        -- Ensure final amount is never negative
        IF @finalAmount < 0 
            SET @finalAmount = 0;
            
        -- Update booking status
        UPDATE Booking
        SET bookingStatus = 'Serviced'
        WHERE bookingId = @bookingId;
        
        -- Insert invoice (with all required values)
        INSERT INTO Invoice (
            invoiceId, baseRentalCharges, extraServiceCharges, totalLatePenalty,
            totalDamagePenalty, totalDiscount, finalAmount, paymentMethod,
            discountApprovedBy, loyaltyDiscountApplied, bookingId, employeeId
        )
        VALUES (
            'INV' + RIGHT('0000' + CAST(ABS(CHECKSUM(NEWID())) % 10000 AS VARCHAR(4)), 4),
            ISNULL(@totalBaseRentalCharges, 0),
            ISNULL(@totalExtraServiceCharges, 0),
            ISNULL(@totalLatePenalty, 0),
            ISNULL(@totalDamagePenalty, 0),
            ISNULL(@totalDiscount, 0),
            ISNULL(@finalAmount, 0),
            ISNULL(@paymentMethod, 'Unknown'),
            @discountApprovedBy,
            @loyaltyDiscountApplied,
            @bookingId,
            @employeeId
        );
        
        COMMIT;
        
        -- Return invoice summary
        SELECT 
            @bookingId AS BookingID,
            @totalBaseRentalCharges AS BaseRentalCharges,
            @totalExtraServiceCharges AS ExtraServiceCharges,
            @totalLatePenalty AS LatePenalty,
            @totalDamagePenalty AS DamagePenalty,
            @totalFuelCharge AS FuelCharge,
            @totalDiscount AS Discount,
            @bookingDeposit AS DepositApplied,
            @finalAmount AS FinalAmountToPay;
            
        PRINT 'Return processed successfully. Final amount: ' + CAST(@finalAmount AS VARCHAR);
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        PRINT 'Error occurred: ' + ERROR_MESSAGE();
    END CATCH
END;
GO