USE Madhavi_Hari_Dhimanshi;
GO
;

CREATE TYPE PricedServiceList AS TABLE (
    pricedServiceId VARCHAR(10)
);

CREATE TYPE VehicleList AS TABLE (
    vehicleId VARCHAR(10)
);

CREATE TYPE DriverList AS TABLE (
    driverId VARCHAR(10)
);
GO
-- Create the ExtraServiceList table type for stored procedures
CREATE TYPE ExtraServiceList AS TABLE (
    extraServiceId VARCHAR(10),
    quantity INT
);
GO

-- Create stored procedures
CREATE OR ALTER PROCEDURE usp_CreateBooking
    @bookingId VARCHAR(10),
    @customerId VARCHAR(10),
    @modeOfBooking VARCHAR(20),
    @serviceStartDate DATE,
    @serviceEndDate DATE,
    @paymentMethod VARCHAR(20),
    @pricedServiceIds PricedServiceList READONLY,
    @vehicleIds VehicleList READONLY,
    @employeeId VARCHAR(10),
    @driverIds DriverList READONLY,
    @extraServices ExtraServiceList READONLY,
    @cancelImmediately BIT = 0,
    @cancellationReason VARCHAR(100) = NULL
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Validate parameters
        IF @serviceEndDate < @serviceStartDate
        BEGIN
            RAISERROR('Service end date must be after start date.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Check if customer exists
        IF NOT EXISTS (SELECT 1 FROM Customer WHERE customerId = @customerId)
        BEGIN
            RAISERROR('Customer does not exist.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Check if employee exists
        IF NOT EXISTS (SELECT 1 FROM Employee WHERE employeeId = @employeeId)
        BEGIN
            RAISERROR('Employee does not exist.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Validate priced services
        DECLARE @pricedServiceCount INT = (SELECT COUNT(*) FROM @pricedServiceIds);
        IF @pricedServiceCount = 0
        BEGIN
            RAISERROR('At least one priced service must be selected.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Validate vehicles
        DECLARE @vehicleCount INT = (SELECT COUNT(*) FROM @vehicleIds);
        IF @vehicleCount = 0
        BEGIN
            RAISERROR('At least one vehicle must be selected.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Check if all priced services exist and are available
        IF EXISTS (
            SELECT 1 FROM @pricedServiceIds ps
            WHERE NOT EXISTS (
                SELECT 1 FROM PricedService p
                JOIN Service s ON p.serviceId = s.serviceId
                WHERE p.pricedServiceId = ps.pricedServiceId 
                AND s.status = 'Available'
                AND @serviceStartDate >= p.pricingStartDate
                AND @serviceEndDate <= p.pricingEndDate
            )
        )
        BEGIN
            RAISERROR('One or more priced services are not available for the selected dates.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Skip availability check if we're cancelling immediately
        IF @cancelImmediately = 0 AND EXISTS (
            SELECT v.vehicleId
            FROM @vehicleIds v
            JOIN Booking_Vehicle bv ON v.vehicleId = bv.vehicleId
            JOIN Booking b ON b.bookingId = bv.bookingId
            WHERE b.bookingStatus = 'Confirmed'
              AND (
                (@serviceStartDate BETWEEN b.serviceStartDate AND b.serviceEndDate) OR
                (@serviceEndDate BETWEEN b.serviceStartDate AND b.serviceEndDate) OR
                (b.serviceStartDate BETWEEN @serviceStartDate AND @serviceEndDate)
              )
        )
        BEGIN
            RAISERROR('One or more vehicles are already booked for the selected dates.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Check if number of drivers exceeds number of vehicles
        DECLARE @driverCount INT = (SELECT COUNT(*) FROM @driverIds);
        IF @driverCount > @vehicleCount
        BEGIN
            RAISERROR('Number of drivers cannot exceed number of vehicles.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Check if all drivers exist
        IF @driverCount > 0 AND EXISTS (
            SELECT 1 FROM @driverIds d
            WHERE NOT EXISTS (SELECT 1 FROM Driver WHERE driverId = d.driverId)
        )
        BEGIN
            RAISERROR('One or more drivers do not exist.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Calculate rental days
        DECLARE @rentalDays INT = DATEDIFF(DAY, @serviceStartDate, @serviceEndDate) + 1;
        
        -- Calculate total base price from all priced services
        DECLARE @totalBasePrice DECIMAL(10,2) = 0;
        SELECT @totalBasePrice = SUM(ps.price)
        FROM @pricedServiceIds psi
        JOIN PricedService ps ON psi.pricedServiceId = ps.pricedServiceId;
        
        -- Calculate deposit (20% of estimated total)
        DECLARE @estimatedTotal DECIMAL(10,2) = @totalBasePrice * @rentalDays;
        DECLARE @bookingDeposit DECIMAL(10,2) = ROUND(@estimatedTotal * 0.2, 2);

        -- Determine initial booking status
        DECLARE @initialBookingStatus VARCHAR(20) = CASE WHEN @cancelImmediately = 1 THEN 'Cancelled' ELSE 'Confirmed' END;

        -- Insert Booking
        INSERT INTO Booking (
            bookingId, modeOfBooking, bookingDate, customerInformation,
            numberOfPricedServices, numberOfVehicles, serviceStartDate, serviceEndDate,
            paymentMethod, bookingDeposit, bookingStatus, customerId
        )
        VALUES (
            @bookingId, @modeOfBooking, GETDATE(), @customerId,
            @pricedServiceCount, 
            @vehicleCount, 
            @serviceStartDate, @serviceEndDate,
            @paymentMethod, @bookingDeposit, @initialBookingStatus, @customerId
        );

        -- Link priced services
        INSERT INTO Booking_PricedService (bookingId, pricedServiceId)
        SELECT @bookingId, pricedServiceId FROM @pricedServiceIds;

        -- Link vehicles
        INSERT INTO Booking_Vehicle (bookingId, vehicleId)
        SELECT @bookingId, vehicleId FROM @vehicleIds;

        -- Add drivers if provided
        IF @driverCount > 0
        BEGIN
            INSERT INTO Booking_Driver (bookingId, driverId)
            SELECT @bookingId, driverId FROM @driverIds;
        END

        -- Add extra services if provided
        IF EXISTS (SELECT 1 FROM @extraServices)
        BEGIN
            INSERT INTO Booking_ExtraService (bookingId, extraServiceId, quantity)
            SELECT @bookingId, extraServiceId, quantity
            FROM @extraServices;
        END

        -- Record transactions based on cancellation status
        DECLARE @currentDateTime DATETIME = GETDATE();
        DECLARE @vehicleId VARCHAR(10);
        
        DECLARE vehicle_cursor CURSOR FOR SELECT vehicleId FROM @vehicleIds;
        OPEN vehicle_cursor;
        FETCH NEXT FROM vehicle_cursor INTO @vehicleId;
        
        WHILE @@FETCH_STATUS = 0
        BEGIN
            IF @cancelImmediately = 1
            BEGIN
                -- For cancellations, use 'Return' as transaction type (since your constraint doesn't allow 'Cancellation')
                INSERT INTO VehicleTransaction (
                    transactionId, transactionType, actualDateTime, vehicleCondition, 
                    mileageReading, fuelLevel, additionalCharges, pickupDateTime, 
                    returnDateTime, pickupEmployeeId, returnEmployeeId, bookingId, 
                    vehicleId, employeeId
                )
                VALUES (
                    'VT' + RIGHT('0000' + CAST(ABS(CHECKSUM(NEWID())) % 10000 AS VARCHAR(4)), 4),
                    'Return', -- Using 'Return' instead of 'Cancellation' to match your CHECK constraint
                    @currentDateTime, 
                    CASE WHEN @cancellationReason IS NOT NULL 
                         THEN 'Booking cancelled: ' + @cancellationReason 
                         ELSE 'Booking cancelled immediately after creation' END,
                    0, 100, 0.00, @currentDateTime,
                    @currentDateTime, -- Using current time for returnDateTime
                    @employeeId, -- pickupEmployeeId
                    @employeeId, -- returnEmployeeId
                    @bookingId, 
                    @vehicleId, 
                    @employeeId
                );
            END
            ELSE
            BEGIN
                -- For confirmed bookings, create pickup record as before
                INSERT INTO VehicleTransaction (
                    transactionId, transactionType, actualDateTime, vehicleCondition, 
                    mileageReading, fuelLevel, additionalCharges, pickupDateTime, 
                    returnDateTime, pickupEmployeeId, returnEmployeeId, bookingId, 
                    vehicleId, employeeId
                )
                VALUES (
                    'VT' + RIGHT('0000' + CAST(ABS(CHECKSUM(NEWID())) % 10000 AS VARCHAR(4)), 4),
                    'Pickup', @currentDateTime, 'New booking - vehicle not yet picked up',
                    0, 100, 0.00, @serviceStartDate, NULL, @employeeId, NULL, 
                    @bookingId, @vehicleId, @employeeId
                );
            END
            
            FETCH NEXT FROM vehicle_cursor INTO @vehicleId;
        END
        
        CLOSE vehicle_cursor;
        DEALLOCATE vehicle_cursor;

        -- Handle immediate cancellation if requested
        IF @cancelImmediately = 1
        BEGIN
            -- Check if any priced services are package services
            DECLARE @isPackageService BIT = 0;
            DECLARE @gracePeriod INT = 0;
            DECLARE @packagePrice DECIMAL(10,2) = 0;
            DECLARE @cancellationPenalty DECIMAL(10,2) = 0;
            
            SELECT TOP 1
                @isPackageService = CASE WHEN psd.serviceId IS NOT NULL THEN 1 ELSE 0 END,
                @gracePeriod = ISNULL(psd.gracePeriod, 0),
                @packagePrice = ps.price
            FROM @pricedServiceIds psi
            JOIN PricedService ps ON psi.pricedServiceId = ps.pricedServiceId
            JOIN Service s ON ps.serviceId = s.serviceId
            LEFT JOIN PackageServiceDetails psd ON s.serviceId = psd.serviceId AND s.serviceType = 'Package'
            WHERE s.serviceType = 'Package';
            
            -- Check if cancellation is within grace period for package services
            DECLARE @daysUntilService INT = DATEDIFF(DAY, GETDATE(), @serviceStartDate);
            
            IF @isPackageService = 1 AND @daysUntilService < @gracePeriod
            BEGIN
                -- Apply 25% penalty for package services cancelled after grace period
                SET @cancellationPenalty = @packagePrice * 0.25;
                
                -- Update the cancellation transactions with the penalty amount
                UPDATE VehicleTransaction
                SET additionalCharges = @cancellationPenalty
                WHERE bookingId = @bookingId AND transactionType = 'Cancellation';
                
                -- If penalty exceeds deposit, charge the difference
                IF @cancellationPenalty > @bookingDeposit
                BEGIN
                    PRINT 'Additional cancellation charge of ' + CAST((@cancellationPenalty - @bookingDeposit) AS VARCHAR) + ' will be applied.';
                END
                ELSE
                BEGIN
                    PRINT 'Partial deposit refund of ' + CAST((@bookingDeposit - @cancellationPenalty) AS VARCHAR) + ' will be issued.';
                END
            END
            ELSE
            BEGIN
                PRINT 'Full deposit refund of ' + CAST(@bookingDeposit AS VARCHAR) + ' will be issued.';
            END

            -- Release vehicles by updating their status to Active
            UPDATE v
            SET v.status = 'Active'
            FROM Vehicle v
            JOIN @vehicleIds vi ON v.vehicleId = vi.vehicleId;
        END

        COMMIT;
        
        PRINT 'Booking ' + @initialBookingStatus + ' successfully. Booking ID: ' + @bookingId;
        PRINT 'Number of vehicles: ' + CAST(@vehicleCount AS VARCHAR);
        PRINT 'Number of priced services: ' + CAST(@pricedServiceCount AS VARCHAR);
        
        IF @cancelImmediately = 1
        BEGIN
            PRINT 'Booking was cancelled immediately after creation.';
            IF @cancellationPenalty > 0
                PRINT 'Cancellation penalty applied: ' + CAST(@cancellationPenalty AS VARCHAR);
        END
        ELSE
        BEGIN
            PRINT 'Deposit amount: ' + CAST(@bookingDeposit AS VARCHAR);
        END
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        PRINT 'Error occurred: ' + ERROR_MESSAGE();
    END CATCH
END;
GO