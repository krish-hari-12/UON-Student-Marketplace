USE Madhavi_Hari_Dhimanshi;

-- Test Case 1: Standard booking with 1 vehicle and 1 service
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS001');

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V001');

EXEC usp_CreateBooking 
    @bookingId = 'BK011',
    @customerId = 'C001',
    @modeOfBooking = 'Website',
    @serviceStartDate = '2023-08-01',
    @serviceEndDate = '2023-08-03',
    @paymentMethod = 'Credit Card',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A001';

-- Test Case 2: Booking with 2 vehicles and 2 services
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS001'), ('PS002');

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V001'), ('V002');

EXEC usp_CreateBooking 
    @bookingId = 'BK012',
    @customerId = 'C002',
    @modeOfBooking = 'App',
    @serviceStartDate = '2023-08-05',
    @serviceEndDate = '2023-08-10',
    @paymentMethod = 'Debit Card',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A002';

-- Test Case 3: Booking with driver and extra services
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS002');

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V003');

DECLARE @drivers DriverList;
INSERT INTO @drivers VALUES ('D001');

DECLARE @extras ExtraServiceList;
INSERT INTO @extras VALUES ('ES001', 2), ('ES003', 1);

EXEC usp_CreateBooking 
    @bookingId = 'BK013',
    @customerId = 'C003',
    @modeOfBooking = 'Phone',
    @serviceStartDate = '2023-08-15',
    @serviceEndDate = '2023-08-20',
    @paymentMethod = 'Credit Card',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A003',
    @driverIds = @drivers,
    @extraServices = @extras;

-- Test Case 4: Booking created and cancelled immediately
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS005'); -- Corporate Package

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V006'); -- Toyota Camry

EXEC usp_CreateBooking 
    @bookingId = 'BK014',
    @customerId = 'C004',
    @modeOfBooking = 'In-person',
    @serviceStartDate = '2023-08-25',
    @serviceEndDate = '2023-08-30',
    @paymentMethod = 'Cash',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A004',
    @cancelImmediately = 1,
    @cancellationReason = 'Customer changed plans';

-- Test Case 5: Attempt to create booking with invalid dates
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS001');

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V001');

EXEC usp_CreateBooking 
    @bookingId = 'BK015',
    @customerId = 'C001',
    @modeOfBooking = 'Website',
    @serviceStartDate = '2023-08-05',
    @serviceEndDate = '2023-08-01',
    @paymentMethod = 'Credit Card',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A001';

-- Test Case 6: Attempt to create booking with invalid customer
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS001');

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V001');

EXEC usp_CreateBooking 
    @bookingId = 'BK016',
    @customerId = 'C999',
    @modeOfBooking = 'Website',
    @serviceStartDate = '2023-08-01',
    @serviceEndDate = '2023-08-03',
    @paymentMethod = 'Credit Card',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A001';

-- Test Case 7: Attempt to book already booked vehicle
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS001');

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V001');

EXEC usp_CreateBooking 
    @bookingId = 'BK017',
    @customerId = 'C002',
    @modeOfBooking = 'Website',
    @serviceStartDate = '2023-06-15',
    @serviceEndDate = '2023-06-18',
    @paymentMethod = 'Credit Card',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A001';

-- Test Case 8: Attempt to assign more drivers than vehicles
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS001');

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V001');

DECLARE @drivers DriverList;
INSERT INTO @drivers VALUES ('D001'), ('D002');

EXEC usp_CreateBooking 
    @bookingId = 'BK018',
    @customerId = 'C003',
    @modeOfBooking = 'Website',
    @serviceStartDate = '2023-09-01',
    @serviceEndDate = '2023-09-03',
    @paymentMethod = 'Credit Card',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A001',
    @driverIds = @drivers;