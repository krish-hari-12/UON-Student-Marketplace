
USE Madhavi_Hari_Dhimanshi;
GO

-- Test Case 1: Normal vehicle return with no issues
DECLARE @returns VehicleReturnList;
INSERT INTO @returns VALUES ('V001', 'Excellent condition', 15100, 100, 0, 0);

EXEC usp_ProcessReturn 
    @bookingId = 'BK001',
    @employeeId = 'A001',
    @vehicleReturns = @returns;

-- Test Case 2: Return with late fee and damage penalty
DECLARE @returns VehicleReturnList;
INSERT INTO @returns VALUES ('V003', 'Scratch on rear bumper', 5200, 75, 200, 5);

EXEC usp_ProcessReturn 
    @bookingId = 'BK002',
    @employeeId = 'A002',
    @vehicleReturns = @returns;

-- Test Case 3: Return with automatic loyalty discount
-- First create test booking
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS001');

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V001');

EXEC usp_CreateBooking 
    @bookingId = 'BK_LOYALTY_TEST',
    @customerId = 'C002',
    @modeOfBooking = 'Website',
    @serviceStartDate = '2023-09-10',
    @serviceEndDate = '2023-09-13',
    @paymentMethod = 'Credit Card',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A002';

-- Then process return
DECLARE @returns VehicleReturnList;
INSERT INTO @returns VALUES ('V001', 'Excellent condition', 15200, 100, 0, 0);

EXEC usp_ProcessReturn 
    @bookingId = 'BK_LOYALTY_TEST',
    @employeeId = 'A002',
    @vehicleReturns = @returns;

-- Test Case 4: Return with manager-approved additional discount
-- First create test booking
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS001');

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V001');

EXEC usp_CreateBooking 
    @bookingId = 'BK_MGR_TEST',
    @customerId = 'C002',
    @modeOfBooking = 'Website',
    @serviceStartDate = '2023-09-15',
    @serviceEndDate = '2023-09-18',
    @paymentMethod = 'Credit Card',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A001';

-- Then process return with manager discount
DECLARE @returns VehicleReturnList;
INSERT INTO @returns VALUES ('V001', 'Excellent condition', 15200, 100, 0, 0);

EXEC usp_ProcessReturn 
    @bookingId = 'BK_MGR_TEST',
    @employeeId = 'M001',
    @vehicleReturns = @returns,
    @discountAmount = 50,
    @discountReason = 'Manager-approved customer compensation';

-- Test Case 5: Attempt to process return for non-existent booking
DECLARE @returns VehicleReturnList;
INSERT INTO @returns VALUES ('V001', 'Good condition', 15000, 100, 0, 0);

EXEC usp_ProcessReturn 
    @bookingId = 'BK999',
    @employeeId = 'A001',
    @vehicleReturns = @returns;

-- Test Case 6: Attempt to return already returned booking
DECLARE @returns VehicleReturnList;
INSERT INTO @returns VALUES ('V001', 'Good condition', 15100, 100, 0, 0);

EXEC usp_ProcessReturn 
    @bookingId = 'BK001',
    @employeeId = 'A001',
    @vehicleReturns = @returns;

-- Test Case 7: Attempt to apply discount without authorization
-- First create test booking
DECLARE @pricedServices PricedServiceList;
INSERT INTO @pricedServices VALUES ('PS001');

DECLARE @vehicles VehicleList;
INSERT INTO @vehicles VALUES ('V008');

EXEC usp_CreateBooking 
    @bookingId = 'BK_TEST1',
    @customerId = 'C002',
    @modeOfBooking = 'Website',
    @serviceStartDate = '2023-08-01',
    @serviceEndDate = '2023-08-03',
    @paymentMethod = 'Credit Card',
    @pricedServiceIds = @pricedServices,
    @vehicleIds = @vehicles,
    @employeeId = 'A001';

-- Then attempt unauthorized discount
DECLARE @returns VehicleReturnList;
INSERT INTO @returns VALUES ('V008', 'Excellent condition', 22000, 100, 0, 0);

EXEC usp_ProcessReturn 
    @bookingId = 'BK_TEST1',
    @employeeId = 'A002',
    @vehicleReturns = @returns,
    @discountAmount = 30,
    @discountReason = 'Customer satisfaction';

-- Test Case 8: Attempt to return only some vehicles from booking
DECLARE @returns VehicleReturnList;
INSERT INTO @returns VALUES ('V006', 'Excellent condition', 10200, 100, 0, 0);

EXEC usp_ProcessReturn 
    @bookingId = 'BK003',
    @employeeId = 'A003',
    @vehicleReturns = @returns;

-- Test Case 9: Attempt to return vehicle not in booking
UPDATE Booking SET bookingStatus = 'Confirmed' WHERE bookingId = 'BK001';

DECLARE @returns VehicleReturnList;
INSERT INTO @returns VALUES ('V010', 'Excellent condition', 30500, 100, 0, 0);

EXEC usp_ProcessReturn 
    @bookingId = 'BK001',
    @employeeId = 'A001',
    @vehicleReturns = @returns;
