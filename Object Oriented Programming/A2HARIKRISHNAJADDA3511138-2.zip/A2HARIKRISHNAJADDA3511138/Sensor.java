//Student ID: 3511138
//Name: Hari Krishna Jadda
/**
 * Represents a sensor that can be attached to a UAV
 * Contains type, grade, and quantity information
 */
public class Sensor {
    private String type;        // Type of sensor (Temperature, Pressure, etc.)
    private int grade;          // Quality grade (1-5, 1 being highest)
    private int quantity;       // Number of sensors available

    // Valid sensor types
    public static final String[] VALID_TYPES = {"Temperature", "Pressure", "Windspeed", "Humidity"};

    //Constructor to create a new Sensor
    public Sensor(String newType, int newGrade, int newQuantity) {
        this.type = newType;
        this.grade = newGrade;
        this.quantity = newQuantity;
    }

    // Getter methods
    public String getType() { return type; }
    public int getGrade() { return grade; }
    public int getQuantity() { return quantity; }

    // Setter methods
    public void setType(String type) { this.type = type; }
    public void setGrade(int grade) { this.grade = grade; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    //Checks if a sensor type is valid
    public static boolean isValidType(String type) {
        for (int i = 0; i < VALID_TYPES.length; i++) {
            if (VALID_TYPES[i].equalsIgnoreCase(type)) {
                return true;
            }
        }
        return false;
    }

    //Runs test cases for Sensor class
    public static String testCases() {
        String results = "";
        
        // Test Case 1: getType()
        Sensor sensor1 = new Sensor("Temperature", 1, 10);
        results += "Test Case 1: getType()\nExpected: Temperature\nActual: " + sensor1.getType() + "\n\n";
        
        // Test Case 2: setType()
        sensor1.setType("Pressure");
        results += "Test Case 2: setType()\nExpected: Pressure\nActual: " + sensor1.getType() + "\n\n";
        
        // Test Case 3: getGrade()
        results += "Test Case 3: getGrade()\nExpected: 1\nActual: " + sensor1.getGrade() + "\n\n";
        
        // Test Case 4: setGrade()
        sensor1.setGrade(2);
        results += "Test Case 4: setGrade()\nExpected: 2\nActual: " + sensor1.getGrade() + "\n\n";
        
        // Test Case 5: getQuantity()
        results += "Test Case 5: getQuantity()\nExpected: 10\nActual: " + sensor1.getQuantity() + "\n\n";
        
        // Test Case 6: setQuantity()
        sensor1.setQuantity(15);
        results += "Test Case 6: setQuantity()\nExpected: 15\nActual: " + sensor1.getQuantity() + "\n\n";
        
        // Test Case 7: isValidType() with valid types
        results += "Test Case 7: isValidType() with valid types\n";
        results += "Temperature: " + isValidType("Temperature") + " (Expected: true)\n";
        results += "pressure: " + isValidType("pressure") + " (Expected: true)\n\n";
        
        // Test Case 8: isValidType() with invalid types
        results += "Test Case 8: isValidType() with invalid types\n";
        results += "Invalid: " + isValidType("Invalid") + " (Expected: false)\n";
        results += "Empty: " + isValidType("") + " (Expected: false)\n";
        
        return results;
    }
}