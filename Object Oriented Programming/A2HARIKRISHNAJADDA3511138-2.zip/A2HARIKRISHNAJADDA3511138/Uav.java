//Student ID: 3511138
//Name: Hari Krishna Jadda
/**
 * Represents an Unmanned Aerial Vehicle (UAV) that can carry sensors
 */
public class Uav {
    private String name;                // Name of UAV
    private double operationalCost;     // Operational cost per hour
    private int availability;           // Availability level (0-5)
    private Sensor[] sensors;           // Array of sensors (max 3)

    //Constructor to create new UAV
    public Uav(String newName, double newOperationalCost, int newAvailability) {
        this.name = newName;
        this.operationalCost = newOperationalCost;
        this.availability = newAvailability;
        this.sensors = new Sensor[3];  // Each UAV can have up to 3 sensors
    }

    // Getter methods
    public String getName() { return name; }
    public double getOperationalCost() { return operationalCost; }
    public int getAvailability() { return availability; }
    public Sensor[] getSensors() { return sensors; }

    // Setter methods
    public void setName(String name) { this.name = name; }
    public void setOperationalCost(double operationalCost) { this.operationalCost = operationalCost; }
    public void setAvailability(int availability) { this.availability = availability; }

    //Adds a sensor to the UAV if space is available
    public void addSensor(Sensor sensor) {
        for (int i = 0; i < sensors.length; i++) {
            if (sensors[i] == null) {
                sensors[i] = sensor;
                return;
            }
        }
    }

    //Checks if all sensor slots are filled
    public boolean checkThreeSensors() {
        for (int i = 0; i < sensors.length; i++) {
            if (sensors[i] == null) {
                return false;
            }
        }
        return true;
    }

    //Removes a sensor of specified type
    public void removeSensor(String type) {
        for (int i = 0; i < sensors.length; i++) {
            if (sensors[i] != null && sensors[i].getType().equalsIgnoreCase(type)) {
                sensors[i] = null;
                return;
            }
        }
    }

    //Checks if UAV meets sensor requirements
    public boolean meetSensorRequirements(String type, int grade, int quantity) {
        for (int i = 0; i < sensors.length; i++) {
            if (sensors[i] != null && 
                sensors[i].getType().equalsIgnoreCase(type) && 
                sensors[i].getGrade() >= grade && 
                sensors[i].getQuantity() >= quantity) {
                return true;
            }
        }
        return false;
    }

    //Checks if UAV has a specific sensor type
    public boolean hasSensorType(String type) {
        for (int i = 0; i < sensors.length; i++) {
            if (sensors[i] != null && sensors[i].getType().equalsIgnoreCase(type)) {
                return true;
            }
        }
        return false;
    }

    //Gets sensor by type
    public Sensor getSensorByType(String type) {
        for (int i = 0; i < sensors.length; i++) {
            if (sensors[i] != null && sensors[i].getType().equalsIgnoreCase(type)) {
                return sensors[i];
            }
        }
        return null;
    }

    //Calculates total number of sensors on this UAV
    public int getTotalSensors() {
        int total = 0;
        for (int i = 0; i < sensors.length; i++) {
            if (sensors[i] != null) {
                total += sensors[i].getQuantity();
            }
        }
        return total;
    }

    //Runs test cases for Uav class
    public static String testCases() {
        String results = "";
        
        // Test Case 1: getName()
        Uav uav1 = new Uav("TestUAV1", 100.0, 5);
        results += "Test Case 1: getName()\nExpected: TestUAV1\nActual: " + uav1.getName() + "\n\n";
        
        // Test Case 2: setName()
        uav1.setName("UpdatedUAV");
        results += "Test Case 2: setName()\nExpected: UpdatedUAV\nActual: " + uav1.getName() + "\n\n";
        
        // Test Case 3: getOperationalCost()
        results += "Test Case 3: getOperationalCost()\nExpected: 100.0\nActual: " + uav1.getOperationalCost() + "\n\n";
        
        // Test Case 4: setOperationalCost()
        uav1.setOperationalCost(150.0);
        results += "Test Case 4: setOperationalCost()\nExpected: 150.0\nActual: " + uav1.getOperationalCost() + "\n\n";
        
        // Test Case 5: getAvailability()
        results += "Test Case 5: getAvailability()\nExpected: 5\nActual: " + uav1.getAvailability() + "\n\n";
        
        // Test Case 6: setAvailability()
        uav1.setAvailability(3);
        results += "Test Case 6: setAvailability()\nExpected: 3\nActual: " + uav1.getAvailability() + "\n\n";
        
        // Test Case 7: addSensor() and checkThreeSensors()
        results += "Test Case 7: addSensor() and checkThreeSensors()\n";
        Sensor sensor1 = new Sensor("Temperature", 1, 10);
        Sensor sensor2 = new Sensor("Pressure", 2, 5);
        Sensor sensor3 = new Sensor("Humidity", 3, 8);
        
        uav1.addSensor(sensor1);
        results += "After 1 sensor: " + uav1.checkThreeSensors() + " (Expected: false)\n";
        uav1.addSensor(sensor2);
        results += "After 2 sensors: " + uav1.checkThreeSensors() + " (Expected: false)\n";
        uav1.addSensor(sensor3);
        results += "After 3 sensors: " + uav1.checkThreeSensors() + " (Expected: true)\n\n";
        
        // Test Case 8: hasSensorType()
        results += "Test Case 8: hasSensorType()\n";
        results += "Temperature: " + uav1.hasSensorType("Temperature") + " (Expected: true)\n";
        results += "Windspeed: " + uav1.hasSensorType("Windspeed") + " (Expected: false)\n\n";
        
        // Test Case 9: getSensorByType()
        results += "Test Case 9: getSensorByType()\n";
        Sensor tempSensor = uav1.getSensorByType("Temperature");
        results += "Temperature grade: " + (tempSensor != null ? tempSensor.getGrade() : "null") + " (Expected: 1)\n";
        Sensor windSensor = uav1.getSensorByType("Windspeed");
        results += "Windspeed sensor: " + (windSensor != null ? "exists" : "null") + " (Expected: null)\n\n";
        
        // Test Case 10: meetSensorRequirements()
        results += "Test Case 10: meetSensorRequirements()\n";
        results += "Temp, grade 1, qty 5: " + uav1.meetSensorRequirements("Temperature", 1, 5) + " (Expected: true)\n";
        results += "Temp, grade 1, qty 15: " + uav1.meetSensorRequirements("Temperature", 1, 15) + " (Expected: false)\n";
        results += "Temp, grade 5, qty 5: " + uav1.meetSensorRequirements("Temperature", 5, 5) + " (Expected: true)\n";
        results += "Windspeed, grade 1, qty 1: " + uav1.meetSensorRequirements("Windspeed", 1, 1) + " (Expected: false)\n";
        
        return results;
    }
}