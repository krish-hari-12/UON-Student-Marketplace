//Student ID: 3511138
//Name: Hari Krishna Jadda
import javax.swing.JOptionPane;
import java.io.PrintWriter;
import java.io.File;

//Provides user interface for managing UAVs and sensors
public class UavInterface {
    private Uav[] uavs;        // Array to store UAVs (max 4)
    private String option;     // Stores user menu selection

    //Constructor initializes UAV array
    public UavInterface() {
        uavs = new Uav[4];     // Maximum of 4 UAVs allowed
    }

    //Main program loop displaying menu and handling user input
    public void run() {
        do {
            // Display menu options
            String menu = "UAV Management System\n\n" +
                         "1. Add UAV\n" +
                         "2. Remove UAV\n" +
                         "3. Add Sensor to UAV\n" +
                         "4. Remove Sensor from UAV\n" +
                         "5. Find Best UAV for Task\n" +
                         "6. List Sensors on UAV\n" +
                         "7. Find UAVs with Sensor Type\n" +
                         "8. List All UAVs\n" +
                         "9. Export to File\n" +
                         "10. Run Test Cases\n" +
                         "11. Exit\n\n" +
                         "Enter your choice:";
            
            option = JOptionPane.showInputDialog(menu);

            // Handle to close the program
            if (option == null) {
                System.exit(0);
            }

            // Menu 
            switch (option.trim()) {
                case "1": addUav(); break;
                case "2": removeUav(); break;
                case "3": addSensorToUav(); break;
                case "4": removeSensorUav(); break;
                case "5": getBestUav(); break;
                case "6": getlistOfSensors(); break;
                case "7": getListOfUavsOnSensorType(); break;
                case "8": getListOfUavs(); break; 
                case "9": exportToFile(); break;
                case "10": runTestCases(); break;
                case "11": System.exit(0); break;
                default: JOptionPane.showMessageDialog(null, "Invalid option");
            }
        } while (!option.equals("11"));
    }

    //Main method - Program running starts from here
    public static void main(String[] args) {
        UavInterface controller = new UavInterface();
        controller.run();
    }

    //Adds a new UAV after validating inputs
    private void addUav() {
        try {
            if (checkUavSlots() >= 0) {
                createUav();
            } else {
                JOptionPane.showMessageDialog(null, "Maximum of 4 UAVs allowed");
            }
        } catch (Exception e) {
            showError("Error adding UAV", e);
        }
    }

    //Creates a new UAV with user-provided details
    private void createUav() {
        try {
            // validate UAV name
            String name = getValidName();
            if (name == null) return;  // User cancelled

            // validate operational cost
            double cost = getValidCost();
            if (cost < 0) return;  // Invalid input

            // validate availability
            int availability = getValidAvailability();
            if (availability < 0) return;  // Invalid input

            // Create and store UAV
            Uav uav = new Uav(name, cost, availability);
            int slot = checkUavSlots(); //check which slot is available for adding new UAV
            if (slot >= 0) {
                uavs[slot] = uav;
                JOptionPane.showMessageDialog(null, 
                    "UAV added successfully!\nName: " + name + 
                    "\nCost: " + cost + 
                    "\nAvailability: " + availability);
            }
        } catch (NumberFormatException e) {
            showError("Invalid number format", e);
        } catch (Exception e) {
            showError("Error creating UAV", e);
        }
    }

    //Helper method to get a valid UAV name or null if cancelled
    private String getValidName() {
        String name = JOptionPane.showInputDialog("Enter UAV Name:");
        if (name == null || name.trim().isEmpty()) {
            return null;
        }

        while (!checkUavName(name)) {
            name = JOptionPane.showInputDialog("Name exists. Try again:");
            if (name == null || name.trim().isEmpty()) {
                return null;
            }
        }
        return name;
    }

    //Helper method to get valid operational cost or -1 if cancelled
    private double getValidCost() {
        String input = JOptionPane.showInputDialog("Enter Operational Cost:");
        if (input == null) return -1;
        
        double cost = Double.parseDouble(input);
        while (!checkUavOperationalCost(cost)) {
            input = JOptionPane.showInputDialog("Cost must be positive. Try again:");
            if (input == null) return -1;
            cost = Double.parseDouble(input);
        }
        return cost;
    }

    //Helper method to get valid availability  or -1 if cancelled
    private int getValidAvailability() {
        String input = JOptionPane.showInputDialog("Enter Availability (0-5):");
        if (input == null) return -1;
        
        int availability = Integer.parseInt(input);
        while (!checkUavAvailability(availability)) {
            input = JOptionPane.showInputDialog("Must be 0-5. Try again:");
            if (input == null) return -1;
            availability = Integer.parseInt(input);
        }
        return availability;
    }

    //Removes a UAV by name
    private void removeUav() {
        try {
            String name = JOptionPane.showInputDialog("Enter UAV name to remove:");
            if (name == null || name.trim().isEmpty()) return;

            for (int i = 0; i < uavs.length; i++) {
                if (uavs[i] != null && uavs[i].getName().equalsIgnoreCase(name)) {
                    uavs[i] = null;
                    JOptionPane.showMessageDialog(null, name + " removed successfully.");
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "UAV not found.");
        } catch (Exception e) {
            showError("Error removing UAV", e);
        }
    }

    //Adds a sensor to a specified UAV
    private void addSensorToUav() {
        try {
            if (checkUavSlots() == (uavs.length - 1)) {
                JOptionPane.showMessageDialog(null, "No UAVs available to add sensors. Please add a UAV first!");
                return;
            }
            
            String uavName = JOptionPane.showInputDialog("Enter UAV name:");
            if (uavName == null || uavName.trim().isEmpty()) return;

            Uav uav = findUav(uavName);
            if (uav == null) {
                JOptionPane.showMessageDialog(null, "UAV not found.");
                return;
            }

            if (uav.checkThreeSensors()) {
                JOptionPane.showMessageDialog(null, uavName + " already has 3 sensors.");
                return;
            }

            // Show available sensor types
            String sensorTypes = "Available Sensor Types:\n";
            for (int i = 0; i < Sensor.VALID_TYPES.length; i++) {
                sensorTypes += "- " + Sensor.VALID_TYPES[i] + "\n";
            }
            sensorTypes += "Enter Sensor Type:";
            
            String type = JOptionPane.showInputDialog(sensorTypes);
            if (type == null || type.trim().isEmpty()) return;

            while (!Sensor.isValidType(type)) {
                type = JOptionPane.showInputDialog("Invalid type. Please enter one of: " + 
                        String.join(", ", Sensor.VALID_TYPES));
                if (type == null || type.trim().isEmpty()) return;
            }

            if (uav.hasSensorType(type)) {
                JOptionPane.showMessageDialog(null, type + " sensor already exists on " + uavName);
                return;
            }

            // Get sensor grade
            int grade = getValidGrade();
            if (grade < 0) return;

            // Get sensor quantity
            int quantity = getValidQuantity();
            if (quantity < 0) return;

            // Add the sensor
            Sensor sensor = new Sensor(type, grade, quantity);
            uav.addSensor(sensor);
            JOptionPane.showMessageDialog(null, type + " sensor added successfully to " + uavName);
        } catch (NumberFormatException e) {
            showError("Invalid number format", e);
        } catch (Exception e) {
            showError("Error adding sensor", e);
        }
    }

    //Helper method to get valid sensor grade (1-5) or -1 if cancelled
    private int getValidGrade() {
        String input = JOptionPane.showInputDialog("Enter Sensor Grade (1-5):");
        if (input == null) return -1;
        
        int grade = Integer.parseInt(input);
        while (!checkSensorGrade(grade)) {
            input = JOptionPane.showInputDialog("Grade must be 1-5. Try again:");
            if (input == null) return -1;
            grade = Integer.parseInt(input);
        }
        return grade;
    }

    //Helper method to get valid sensor quantity (>0) or -1 if cancelled
    private int getValidQuantity() {
        String input = JOptionPane.showInputDialog("Enter Sensor Quantity:");
        if (input == null) return -1;
        
        int quantity = Integer.parseInt(input);
        while (!checkSensorQuantity(quantity)) {
            input = JOptionPane.showInputDialog("Quantity must be positive. Try again:");
            if (input == null) return -1;
            quantity = Integer.parseInt(input);
        }
        return quantity;
    }

    //Removes a sensor from a specified UAV
    private void removeSensorUav() {
        try {
            String uavName = JOptionPane.showInputDialog("Enter UAV name:");
            if (uavName == null || uavName.trim().isEmpty()) return;

            Uav uav = findUav(uavName);
            if (uav == null) {
                JOptionPane.showMessageDialog(null, "UAV not found.");
                return;
            }

            // Check if UAV has any sensors
            boolean hasSensors = false;
            for (int i = 0; i < uav.getSensors().length; i++) {
                if (uav.getSensors()[i] != null) {
                    hasSensors = true;
                    break;
                }
            }

            if (!hasSensors) {
                JOptionPane.showMessageDialog(null, uavName + " has no sensors.");
                return;
            }

            // Show available sensor types on this UAV
            String availableTypes = "Available Sensor Types on " + uavName + ":\n";
            for (int i = 0; i < uav.getSensors().length; i++) {
                if (uav.getSensors()[i] != null) {
                    availableTypes += "- " + uav.getSensors()[i].getType() + "\n";
                }
            }
            availableTypes += "Enter Sensor Type to remove:";
            
            String type = JOptionPane.showInputDialog(availableTypes);
            if (type == null || type.trim().isEmpty()) return;

            while (!Sensor.isValidType(type)) {
                type = JOptionPane.showInputDialog("Invalid type. Please enter one of: " + 
                        String.join(", ", Sensor.VALID_TYPES));
                if (type == null || type.trim().isEmpty()) return;
            }

            Sensor sensor = uav.getSensorByType(type);
            if (sensor == null) {
                JOptionPane.showMessageDialog(null, type + " sensor not found on " + uavName);
                return;
            }

            // Get quantity to remove
            int quantityToRemove = getValidRemovalQuantity(sensor.getQuantity());
            if (quantityToRemove < 0) return;

            // Update or remove sensor
            sensor.setQuantity(sensor.getQuantity() - quantityToRemove);
            if (sensor.getQuantity() == 0) {
                uav.removeSensor(type);
                JOptionPane.showMessageDialog(null, type + " sensor removed from " + uavName);
            } else {
                JOptionPane.showMessageDialog(null, "Reduced quantity of " + type + 
                    " sensor. Remaining: " + sensor.getQuantity());
            }
        } catch (NumberFormatException e) {
            showError("Invalid number format", e);
        } catch (Exception e) {
            showError("Error removing sensor", e);
        }
    }

    //Helper method to get valid quantity to remove or -1 if cancelled by passing maxQuantity as a parameter
    private int getValidRemovalQuantity(int maxQuantity) {
        String input = JOptionPane.showInputDialog("Enter quantity to remove (max " + maxQuantity + "):");
        if (input == null) return -1;
        
        int quantity = Integer.parseInt(input);
        while (!checkSensorQuantity(quantity) || quantity > maxQuantity) {
            if (quantity > maxQuantity) {
                input = JOptionPane.showInputDialog("Cannot remove more than available. Try again:");
            } else {
                input = JOptionPane.showInputDialog("Quantity must be positive. Try again:");
            }
            if (input == null) return -1;
            quantity = Integer.parseInt(input);
        }
        return quantity;
    }

    /**
     * Finds the best UAV for a given sensor requirement
     */
    private void getBestUav() {
        try {
            // Get sensor type
            String sensorTypes = "Available Sensor Types:\n";
            for (int i = 0; i < Sensor.VALID_TYPES.length; i++) {
                sensorTypes += "- " + Sensor.VALID_TYPES[i] + "\n";
            }
            sensorTypes += "Enter Sensor Type:";
            
            String type = JOptionPane.showInputDialog(sensorTypes);
            if (type == null || type.trim().isEmpty()) return;

            while (!Sensor.isValidType(type)) {
                type = JOptionPane.showInputDialog("Invalid type. Please enter one of: " + 
                        String.join(", ", Sensor.VALID_TYPES));
                if (type == null || type.trim().isEmpty()) return;
            }

            // Get minimum grade
            int grade = getValidGrade();
            if (grade < 0) return;

            // Get minimum quantity
            int quantity = getValidQuantity();
            if (quantity < 0) return;

            // Find best UAV
            Uav bestUav = null;
            for (int i = 0; i < uavs.length; i++) {
                if (uavs[i] != null && uavs[i].meetSensorRequirements(type, grade, quantity)) {
                    if (bestUav == null || 
                        uavs[i].getOperationalCost() < bestUav.getOperationalCost() ||
                        (uavs[i].getOperationalCost() == bestUav.getOperationalCost() && 
                         uavs[i].getAvailability() > bestUav.getAvailability())) {
                        bestUav = uavs[i];
                    }
                }
            }

            if (bestUav == null) {
                JOptionPane.showMessageDialog(null, "No UAV meets the requirements.");
            } else {
                JOptionPane.showMessageDialog(null, "Best UAV:\nName: " + bestUav.getName() + 
                    "\nCost: " + bestUav.getOperationalCost() + 
                    "\nAvailability: " + bestUav.getAvailability());
            }
        } catch (NumberFormatException e) {
            showError("Invalid number format", e);
        } catch (Exception e) {
            showError("Error finding best UAV", e);
        }
    }

    /**
     * Lists all sensors on a specified UAV
     */
    private void getlistOfSensors() {
        try {
            String uavName = JOptionPane.showInputDialog("Enter UAV name:");
            if (uavName == null || uavName.trim().isEmpty()) return;

            Uav uav = findUav(uavName);
            if (uav == null) {
                JOptionPane.showMessageDialog(null, "UAV not found.");
                return;
            }

            String sensorList = "";
            for (int i = 0; i < uav.getSensors().length; i++) {
                if (uav.getSensors()[i] != null) {
                    sensorList += uav.getSensors()[i].getType() + " sensor, Grade " +
                                 uav.getSensors()[i].getGrade() + ", Quantity " +
                                 uav.getSensors()[i].getQuantity() + "\n";
                }
            }

            if (sensorList.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No sensors on " + uavName);
            } else {
                JOptionPane.showMessageDialog(null, "Sensors on " + uavName + ":\n" + sensorList);
            }
        } catch (Exception e) {
            showError("Error getting sensor list", e);
        }
    }

    /**
     * Lists all UAVs that have a specific sensor type
     */
    private void getListOfUavsOnSensorType() {
        try {
            // Show available sensor types
            String sensorTypes = "Available Sensor Types:\n";
            for (int i = 0; i < Sensor.VALID_TYPES.length; i++) {
                sensorTypes += "- " + Sensor.VALID_TYPES[i] + "\n";
            }
            sensorTypes += "Enter Sensor Type:";
            
            String type = JOptionPane.showInputDialog(sensorTypes);
            if (type == null || type.trim().isEmpty()) return;

            while (!Sensor.isValidType(type)) {
                type = JOptionPane.showInputDialog("Invalid type. Please enter one of: " + 
                        String.join(", ", Sensor.VALID_TYPES));
                if (type == null || type.trim().isEmpty()) return;
            }

            String result = "";
            for (int i = 0; i < uavs.length; i++) {
                if (uavs[i] != null) {
                    for (int j = 0; j < uavs[i].getSensors().length; j++) {
                        if (uavs[i].getSensors()[j] != null && 
                            uavs[i].getSensors()[j].getType().equalsIgnoreCase(type)) {
                            result += type + " sensor is on " + uavs[i].getName() + 
                                     ", Grade " + uavs[i].getSensors()[j].getGrade() + 
                                     ", Quantity " + uavs[i].getSensors()[j].getQuantity() + "\n";
                        }
                    }
                }
            }

            if (result.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No UAVs have " + type + " sensors");
            } else {
                JOptionPane.showMessageDialog(null, result);
            }
        } catch (Exception e) {
            showError("Error getting UAV list by sensor", e);
        }
    }

    /**
     * Lists all UAVs with their total sensor counts (sorted alphabetically by name)
     * Implements functionality #8 using only arrays and loops
     */
    private void getListOfUavs() {
        // Create array of non-null UAVs
        Uav[] nonNullUavs = new Uav[uavs.length];
        int count = 0;
        for (int i = 0; i < uavs.length; i++) {
            if (uavs[i] != null) {
                nonNullUavs[count] = uavs[i];
                count++;
            }
        }

        // If no UAVs exist
        if (count == 0) {
            JOptionPane.showMessageDialog(null, "No UAV exists");
            return;
        }

        // Sort UAVs alphabetically by name using bubble sort
        for (int i = 0; i < count - 1; i++) {
            for (int j = 0; j < count - i - 1; j++) {
                if (nonNullUavs[j].getName().compareToIgnoreCase(nonNullUavs[j+1].getName()) > 0) {
                    // Swap UAVs
                    Uav temp = nonNullUavs[j];
                    nonNullUavs[j] = nonNullUavs[j+1];
                    nonNullUavs[j+1] = temp;
                }
            }
        }

        // Build output string
        String output = "";
        for (int i = 0; i < count; i++) {
            int totalSensors = 0;
            // Calculate total sensors for this UAV
            for (int j = 0; j < nonNullUavs[i].getSensors().length; j++) {
                if (nonNullUavs[i].getSensors()[j] != null) {
                    totalSensors += nonNullUavs[i].getSensors()[j].getQuantity();
                }
            }
            output += "UAV " + nonNullUavs[i].getName() + " has " + totalSensors + " sensors\n";
        }

        JOptionPane.showMessageDialog(null, output);
    }

    /**
     * Exports UAV and sensor information to a file
     */
    private void exportToFile() {
        try {
            String fileName = JOptionPane.showInputDialog("Enter file name (without extension):");
            if (fileName == null || fileName.trim().isEmpty()) return;
            
            PrintWriter writer = new PrintWriter(new File(fileName + ".txt"));
            
            boolean hasUavs = false;
            for (int i = 0; i < uavs.length; i++) {
                if (uavs[i] != null) {
                    hasUavs = true;
                    int totalSensors = 0;
                    for (int j = 0; j < uavs[i].getSensors().length; j++) {
                        if (uavs[i].getSensors()[j] != null) {
                            totalSensors += uavs[i].getSensors()[j].getQuantity();
                        }
                    }
                    writer.println("UAV " + uavs[i].getName() + " has " + totalSensors + " sensors");
                }
            }
            
            if (!hasUavs) {
                writer.println("No UAV exists");
            }
            
            writer.close();
            JOptionPane.showMessageDialog(null, "Data exported to " + fileName + ".txt");
        } catch (Exception e) {
            showError("Error exporting to file", e);
        }
    }

    /**
     * Runs test cases for Sensor and Uav classes
     */
    private void runTestCases() {
        try {
            String testResults = "=== Sensor Test Cases ===\n";
            testResults += Sensor.testCases() + "\n\n";
            
            testResults += "=== Uav Test Cases ===\n";
            testResults += Uav.testCases();
            
            System.out.println(testResults);  // Print to console
            JOptionPane.showMessageDialog(null, "please check console for test cases");
        } catch (Exception e) {
            showError("Error running test cases", e);
        }
    }

    // Helper methods for validation

    //Checks if a UAV name is unique return true if unique, false if exists
    private boolean checkUavName(String name) {
        if (name == null || name.trim().isEmpty()) return false;
        for (int i = 0; i < uavs.length; i++) {
            if (uavs[i] != null && uavs[i].getName().equalsIgnoreCase(name)) {
                return false;
            }
        }
        return true;
    }

    //Checks if operational cost is positive return true if valid, false otherwise
    private boolean checkUavOperationalCost(double cost) {
        return cost > 0;
    }

    //Checks if availability is between 0-5  availability  to check return true if valid, false otherwise
    private boolean checkUavAvailability(int availability) {
        return availability >= 0 && availability <= 5;
    }

    //Checks if sensor grade is between 1-5  Grade to check return true if valid, false otherwise
    private boolean checkSensorGrade(int grade) {
        return grade >= 1 && grade <= 5;
    }

    //Checks if sensor quantity is positive
    private boolean checkSensorQuantity(int quantity) {
        return quantity > 0;
    }

    //Finds the first available slot in UAV array
    private int checkUavSlots() {
        for (int i = 0; i < uavs.length; i++) {
            if (uavs[i] == null) {
                return i;
            }
        }
        return -1;
    }

    //Finds a UAV by name
    private Uav findUav(String name) {
        for (int i = 0; i < uavs.length; i++) {
            if (uavs[i] != null && uavs[i].getName().equalsIgnoreCase(name)) {
                return uavs[i];
            }
        }
        return null;
    }

    //Displays error message
    private void showError(String message, Exception e) {
        JOptionPane.showMessageDialog(null, message + ": " + e.getMessage());
    }
}