//Name: Hari Krishna Jadda
//Student Id: 3511138
// Sensor Class with instant variables of type, grade, quantity
public class Sensor {
    private String type; //Acts as the type of Sensor (Type must be any of the following: "Temperature", "Pressure", "Windspeed", "Humidity")
    private int grade; // Acts as grade of Sensor(1 to 5 only)
    private int quantity; //Acts as quantity of Sensor(must be positive only)

    // Parameterized Sensor Constructor
    public Sensor(String type, int grade, int quantity) {
        this.type = type;
        this.grade = grade;
        this.quantity = quantity;
    }

    //Getter method for the sensortype
    public String getType() {
        return type;
    }
    //Setter method for the sensor type
    public void setType(String type) {
        this.type = type;
    }
    //Getter method for the sensor grade
    public int getGrade() {
        return grade;
    }
    //Setter method for the sensor grade
    public void setGrade(int grade) {
        this.grade = grade;
    }
    //Getter method for the sensor quantity
    public int getQuantity() {
        return quantity;
    }
    //Setter method for the sensor quantity
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}