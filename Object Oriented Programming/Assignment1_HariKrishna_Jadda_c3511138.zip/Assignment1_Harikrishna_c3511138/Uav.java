//Name: Hari Krishna Jadda
//Student Id: 3511138
// UAV Class with instant variables of name, operationalcost, availability
public class Uav {
    private String name; //Denotes the name of UAV
    private double operationalCost; //Denotes the operational cost of UAV
    private int availability; //Denotes the availability of UAV
    private Sensor sensor1; //Acts as first sensor linked to UAV
    private Sensor sensor2; //Acts as second sensor linked to UAV
    private Sensor sensor3; //Acts as third sensor linked to UAV

      //Parameterized UAV constructor
    public Uav(String name, double operationalCost, int availability) {
        this.name = name;
        this.operationalCost = operationalCost;
        this.availability = availability;
    }

    //Getter method for UAV name
    public String getName() {
        return name;
    }
    //Setter method for UAV name
    public void setName(String name) {
        this.name = name;
    }
    //Getter method for UAV operational cost
    public double getOperationalCost() {
        return operationalCost;
    }
    //Setter method for the UAV operational cost
    public void setOperationalCost(double operationalCost) {
        this.operationalCost = operationalCost;
    }
    //Getter method for the UAV availablity
    public int getAvailability() {
        return availability;
    }
    //Setter method for the UAV availablity
    public void setAvailability(int availability) {
        this.availability = availability;
    }
    //Getter method for first sensor linked to UAV
    public Sensor getSensor1() {
        return sensor1;
    }
    //Setter method for the first sensor linked to UAV
    public void setSensor1(Sensor sensor1) {
        this.sensor1 = sensor1;
    }
    //Getter method for second sensor linked to UAV
    public Sensor getSensor2() {
        return sensor2;
    }
    //Setter method for the second sensor linked to UAV
    public void setSensor2(Sensor sensor2) {
        this.sensor2 = sensor2;
    }
    //Getter method for third sensor linked to UAV
    public Sensor getSensor3() {
        return sensor3;
    }
    //Setter method for the third sensor linked to UAV
    public void setSensor3(Sensor sensor3) {
        this.sensor3 = sensor3;
    }

    //Method for Adding Sensor to UAV.beofre linking the UAV, check if the sensor is null
    public void addSensor(Sensor sensor) {
        if (sensor1 == null) {
            sensor1 = sensor;
        } else if (sensor2 == null) {
            sensor2 = sensor;
        } else if (sensor3 == null) {
            sensor3 = sensor;
        }
    }

    //Method to check all three sensors empty or not
    public boolean checkThreeSensors() {
        return sensor1 != null && sensor2 != null && sensor3 != null;
    }

    //Method for removing the sensor based on type. Checking sensor is not empty and its type
    public void removeSensor(String type) {
        if (sensor1 != null && sensor1.getType().equalsIgnoreCase(type)) {
            sensor1 = null;
        } else if (sensor2 != null && sensor2.getType().equalsIgnoreCase(type)) {
            sensor2 = null;
        } else if (sensor3 != null && sensor3.getType().equalsIgnoreCase(type)) {
            sensor3 = null;
        }
    }

    //Method for check if any sensor meets the requirements based on type, grade and quantity
    public boolean meetSensorRequirements(String type, int grade, int quantity) {
        return (sensor1 != null && sensor1.getType().equalsIgnoreCase(type) && sensor1.getGrade() >= grade && sensor1.getQuantity() >= quantity) ||
                (sensor2 != null && sensor2.getType().equalsIgnoreCase(type) && sensor2.getGrade() >= grade && sensor2.getQuantity() >= quantity) ||
                (sensor3 != null && sensor3.getType().equalsIgnoreCase(type) && sensor3.getGrade() >= grade && sensor3.getQuantity() >= quantity);
    }

    // Method for checking if the UAV has a specific sensor type
    public boolean hasSensorType(String type) {
        return (sensor1 != null && sensor1.getType().equalsIgnoreCase(type)) ||
                (sensor2 != null && sensor2.getType().equalsIgnoreCase(type)) ||
                (sensor3 != null && sensor3.getType().equalsIgnoreCase(type));
    }
}