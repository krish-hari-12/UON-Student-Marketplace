//Name: Hari Krishna Jadda
//Student Id: 3511138
// UavInterface Class 
import javax.swing.JOptionPane;

public class UavInterface {
    public Uav uav1; // Denotes the first UAV
    private Uav uav2; // Denotes the second UAV
    private Uav uav3; // Denotes the third UAV
    private Uav uav4; // Denotes the fourth UAV
    String option;

    public void run() {
        do {
            // Display the message to the user using GUI implementation
            String message = "1. Add Uav\n" +
                    "2. Remove UAV\n" +
                    "3. Add Sensor To Uav\n" +
                    "4. Remove Sensor From UAV\n" +
                    "5. Get Best Uav on Sensor\n" +
                    "6. Get List Of Sensors On UAV\n" +
                    "7. Get Sensor Type on All UAVs\n" +
                    "8. Exit\n" +
                    "Enter your Option: ";
            option = JOptionPane.showInputDialog(message); // Dialog box for user input for selecting the option

            // If the user clicks "Cancel" or closes the dialog, exit the program
            if (option == null) {
                System.exit(0);
            }

            // Implement the user option after taking the user-input by using switch method
            switch (option.trim()) {
                case "1":
                    addUav(); // Add UAV
                    break;
                case "2":
                    removeUav(); // Remove UAV
                    break;
                case "3":
                    addSensorToUav(); // Add sensor to UAV
                    break;
                case "4":
                    removeSensorUav(); // Remove sensor from UAV
                    break;
                case "5":
                    getBestUav(); // Get the best UAV based on sensor requirement
                    break;
                case "6":
                    getlistOfSensors(); // Get all the sensor linked to UAV
                    break;
                case "7":
                    getListOfUavsOnSensorType(); // Get list of UAVs with particular sensor type
                    break;
                case "8":
                    System.exit(0); // Exit the program
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option"); // Print error message for invalid input
            }
        } while (!option.equals("8")); // Continue the loop as long as the user chooses exit(8) option
    }

    // Main method
    public static void main(String[] args) {
        UavInterface myControl = new UavInterface(); // Instance of UavInterface
        myControl.run(); // Program running starts from here
    }

    // Method for Add UAV only after checking the UAV is null
    private void addUav() {
        if (uav1 == null || uav2 == null || uav3 == null || uav4 == null) {
            createUav(); // Create and allocate data if UAV is empty
        } else {
            JOptionPane.showMessageDialog(null, "You can add only 4 UAVs"); // Print error message if all 4 UAVs are not null
        }
    }

    // Method for creating a new UAV object based on name, operational cost, and availability
    private void createUav() {
        String name = JOptionPane.showInputDialog("Enter UAV Name: ");
        if (name == null || name.trim().isEmpty()) {
            return; // Exit if the user clicks "Cancel" or provides an empty name
        }

        while (!checkUavName(name)) { // Check if the UAV name is unique; if not, ask for input again
            name = JOptionPane.showInputDialog( name+ " UAV already exists. Please try again: ");
            if (name == null || name.trim().isEmpty()) {
                return; // Exit if the user clicks "Cancel" or provides an empty name
            }
        }

        String operationalCostInput = JOptionPane.showInputDialog("Enter Operational Cost: ");
        if (operationalCostInput == null) {
            return; // Exit if the user clicks "Cancel"
        }
        double operationalCost = Double.parseDouble(operationalCostInput);

        while (!checkUavOperationalCost(operationalCost)) { // Check if the operational cost is positive
            operationalCostInput = JOptionPane.showInputDialog("Operational cost must be positive. Please try again: ");
            if (operationalCostInput == null) {
                return; // Exit if the user clicks "Cancel"
            }
            operationalCost = Double.parseDouble(operationalCostInput);
        }

        String availabilityInput = JOptionPane.showInputDialog("Enter Availability (0-5): ");
        if (availabilityInput == null) {
            return; // Exit if the user clicks "Cancel"
        }
        int availability = Integer.parseInt(availabilityInput);

        while (!checkUavAvailability(availability)) { // Check if availability is between 0 and 5
            availabilityInput = JOptionPane.showInputDialog("Availability must be between 0 and 5. Please try again: ");
            if (availabilityInput == null) {
                return; // Exit if the user clicks "Cancel"
            }
            availability = Integer.parseInt(availabilityInput);
        }

        Uav uav = new Uav(name, operationalCost, availability); // Create UAV object
        if (uav1 == null) {
            uav1 = uav; // Assign to UAV1
        } else if (uav2 == null) {
            uav2 = uav; // Assign to UAV2
        } else if (uav3 == null) {
            uav3 = uav; // Assign to UAV3
        } else {
            uav4 = uav; // Assign to UAV4
        }

        JOptionPane.showMessageDialog(null, "UAV added successfully!  name:" + name+" / Operational Cost: "+operationalCost+" / Availability: "+availability); // Print success message
    }

    // Method for removing UAV based on UAV name
    private void removeUav() {
        String name = JOptionPane.showInputDialog("Enter UAV name to remove: ");
        if (name == null || name.trim().isEmpty()) {
            return; // Exit if the user clicks "Cancel" or provides an empty name
        }

        if (uav1 != null && uav1.getName().equalsIgnoreCase(name)) {
            uav1 = null; // Remove UAV1
            JOptionPane.showMessageDialog(null, name + " removed successfully.");
        } else if (uav2 != null && uav2.getName().equalsIgnoreCase(name)) {
            uav2 = null; // Remove UAV2
            JOptionPane.showMessageDialog(null, name + " removed successfully.");
        } else if (uav3 != null && uav3.getName().equalsIgnoreCase(name)) {
            uav3 = null; // Remove UAV3
            JOptionPane.showMessageDialog(null, name + " removed successfully.");
        } else if (uav4 != null && uav4.getName().equalsIgnoreCase(name)) {
            uav4 = null; // Remove UAV4
            JOptionPane.showMessageDialog(null, name + " removed successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "UAV not found."); // Print error message if UAV is not found
        }
    }

    // Method for adding a sensor to a UAV
    private void addSensorToUav() {
        String uavName = JOptionPane.showInputDialog("Enter UAV name: ");
        if (uavName == null || uavName.trim().isEmpty()) {
            return; // Exit if the user clicks "Cancel" or provides an empty name
        }

        Uav uav = findUav(uavName); // Find the UAV
        if (uav == null) {
            JOptionPane.showMessageDialog(null, "UAV not found.");
            return;
        }

        if (uav.checkThreeSensors()) { // Check if the UAV already has 3 sensors
            JOptionPane.showMessageDialog(null, uavName+ " UAV already has 3 sensors.");
            return;
        }

        String type = JOptionPane.showInputDialog("Enter Sensor Type (Temperature, Pressure, Windspeed, Humidity): ");
        if (type == null || type.trim().isEmpty()) {
            return; // Exit if the user clicks "Cancel" or provides an empty type
        }

        while (!checkSensorType(type)) { // Validate sensor type
            type = JOptionPane.showInputDialog("Please try again: Sensor Type must be following names(Temperature, Pressure, Windspeed, Humidity) ");
            if (type == null || type.trim().isEmpty()) {
                return; // Exit if the user clicks "Cancel" or provides an empty type
            }
        }

        if ((uav.getSensor1() != null && uav.getSensor1().getType().equalsIgnoreCase(type)) ||
                (uav.getSensor2() != null && uav.getSensor2().getType().equalsIgnoreCase(type)) ||
                (uav.getSensor3() != null && uav.getSensor3().getType().equalsIgnoreCase(type))) {
            JOptionPane.showMessageDialog(null, type +" Sensor already exists on this "+ uavName);
            return;
        }

        String gradeInput = JOptionPane.showInputDialog("Enter Sensor Grade (1-5): ");
        if (gradeInput == null) {
            return; // Exit if the user clicks "Cancel"
        }
        int grade = Integer.parseInt(gradeInput);

        while (!checkSensorGrade(grade)) { // Validate sensor grade
            gradeInput = JOptionPane.showInputDialog("Grade must be between 1 and 5. Please try again: ");
            if (gradeInput == null) {
                return; // Exit if the user clicks "Cancel"
            }
            grade = Integer.parseInt(gradeInput);
        }

        String quantityInput = JOptionPane.showInputDialog("Enter Sensor Quantity: ");
        if (quantityInput == null) {
            return; // Exit if the user clicks "Cancel"
        }
        int quantity = Integer.parseInt(quantityInput);

        while (!checkSensorQuantity(quantity)) { // Validate sensor quantity
            quantityInput = JOptionPane.showInputDialog("Quantity must be positive. Please try again: ");
            if (quantityInput == null) {
                return; // Exit if the user clicks "Cancel"
            }
            quantity = Integer.parseInt(quantityInput);
        }

        Sensor sensor = new Sensor(type, grade, quantity); // Create sensor object
        uav.addSensor(sensor); // Add sensor to UAV
        JOptionPane.showMessageDialog(null, type+" Sensor added successfully to " + uav.getName());
    }

    // Method for removing a sensor from a UAV
    private void removeSensorUav() {
        String uavName = JOptionPane.showInputDialog("Enter UAV name: ");
        if (uavName == null || uavName.trim().isEmpty()) {
            return; // Exit if the user clicks "Cancel" or provides an empty name
        }

        Uav uav = findUav(uavName); // Find the UAV
        if (uav == null) {
            JOptionPane.showMessageDialog(null, "UAV not found.");
            return;
        }
        if(uav.getSensor1()==null && uav.getSensor2()==null && uav.getSensor3()==null){
            JOptionPane.showMessageDialog(null, uav.getName()+" does not have any sensors");
            return;
        }

        String type = JOptionPane.showInputDialog("Enter Sensor Type to remove(Temperature, Pressure, Windspeed, Humidity): ");
        if (type == null || type.trim().isEmpty()) {
            return; // Exit if the user clicks "Cancel" or provides an empty type
        }

        while (!checkSensorType(type)) { // Validate sensor type
            type = JOptionPane.showInputDialog("Invalid sensor type. type must be(Temperature, Pressure, Windspeed, Humidity): ");
            if (type == null || type.trim().isEmpty()) {
                return; // Exit if the user clicks "Cancel" or provides an empty type
            }
        }

        Sensor sensor1 = uav.getSensor1();
        Sensor sensor2 = uav.getSensor2();
        Sensor sensor3 = uav.getSensor3();

        if (sensor1 != null && sensor1.getType().equalsIgnoreCase(type)) {
            removeSensorFromUav(uav, sensor1, type); // Remove sensor1
        } else if (sensor2 != null && sensor2.getType().equalsIgnoreCase(type)) {
            removeSensorFromUav(uav, sensor2, type); // Remove sensor2
        } else if (sensor3 != null && sensor3.getType().equalsIgnoreCase(type)) {
            removeSensorFromUav(uav, sensor3, type); // Remove sensor3
        } else {
            JOptionPane.showMessageDialog(null, type + " Sensor not found on this "+uavName);
        }
    }

    // Method to remove a sensor from a UAV
    private void removeSensorFromUav(Uav uav, Sensor sensor, String type) {
        String quantityInput = JOptionPane.showInputDialog("Enter quantity to remove: ");
        if (quantityInput == null) {
            return; // Exit if the user clicks "Cancel"
        }
        int quantity = Integer.parseInt(quantityInput);

        while (!checkSensorQuantity(quantity)) { // Validate quantity
            quantityInput = JOptionPane.showInputDialog("Quantity must be positive. Please try again: ");
            if (quantityInput == null) {
                return; // Exit if the user clicks "Cancel"
            }
            quantity = Integer.parseInt(quantityInput);
        }

        if (sensor.getQuantity() < quantity) { // Check if the requested quantity exceeds available quantity
            JOptionPane.showMessageDialog(null, "Requested quantity exceeds available quantity.");
            return;
        }

        sensor.setQuantity(sensor.getQuantity() - quantity); // Update sensor quantity
        if (sensor.getQuantity() == 0) { // Remove sensor if quantity becomes zero
            uav.removeSensor(type);
            JOptionPane.showMessageDialog(null, type+ " Sensor removed from " + uav.getName());
        } else {
            JOptionPane.showMessageDialog(null, "Quantity reduced for " + sensor.getType() + " sensor. remaining quantity: "+ sensor.getQuantity());
        }
    }

    // Method to get the best UAV for a given sensor
    private void getBestUav() {
        String type = JOptionPane.showInputDialog("Enter Sensor Type(Temperature, Pressure, Windspeed, Humidity): ");
        if (type == null || type.trim().isEmpty()) {
            return; // Exit if the user clicks "Cancel" or provides an empty type
        }

        while (!checkSensorType(type)) { // Validate sensor type
            type = JOptionPane.showInputDialog("Invalid sensor type. type must be(Temperature, Pressure, Windspeed, Humidity): ");
            if (type == null || type.trim().isEmpty()) {
                return; // Exit if the user clicks "Cancel" or provides an empty type
            }
        }

        String gradeInput = JOptionPane.showInputDialog("Enter Sensor Grade (1-5): ");
        if (gradeInput == null) {
            return; // Exit if the user clicks "Cancel"
        }
        int grade = Integer.parseInt(gradeInput);

        while (!checkSensorGrade(grade)) { // Validate sensor grade
            gradeInput = JOptionPane.showInputDialog("Grade must be between 1 and 5. Please try again: ");
            if (gradeInput == null) {
                return; // Exit if the user clicks "Cancel"
            }
            grade = Integer.parseInt(gradeInput);
        }

        String quantityInput = JOptionPane.showInputDialog("Enter Sensor Quantity: ");
        if (quantityInput == null) {
            return; // Exit if the user clicks "Cancel"
        }
        int quantity = Integer.parseInt(quantityInput);

        while (!checkSensorQuantity(quantity)) { // Validate sensor quantity
            quantityInput = JOptionPane.showInputDialog("Quantity must be positive. Please try again: ");
            if (quantityInput == null) {
                return; // Exit if the user clicks "Cancel"
            }
            quantity = Integer.parseInt(quantityInput);
        }

        Uav bestUav = null; // Store the best UAV
        if (uav1 != null && uav1.meetSensorRequirements(type, grade, quantity)) {
            bestUav = uav1;
        }
        if (uav2 != null && uav2.meetSensorRequirements(type, grade, quantity)) {
            if (bestUav == null || uav2.getOperationalCost() < bestUav.getOperationalCost() ||
                    (uav2.getOperationalCost() == bestUav.getOperationalCost() && uav2.getAvailability() > bestUav.getAvailability())) {
                bestUav = uav2;
            }
        }
        if (uav3 != null && uav3.meetSensorRequirements(type, grade, quantity)) {
            if (bestUav == null || uav3.getOperationalCost() < bestUav.getOperationalCost() ||
                    (uav3.getOperationalCost() == bestUav.getOperationalCost() && uav3.getAvailability() > bestUav.getAvailability())) {
                bestUav = uav3;
            }
        }
        if (uav4 != null && uav4.meetSensorRequirements(type, grade, quantity)) {
            if (bestUav == null || uav4.getOperationalCost() < bestUav.getOperationalCost() ||
                    (uav4.getOperationalCost() == bestUav.getOperationalCost() && uav4.getAvailability() > bestUav.getAvailability())) {
                bestUav = uav4;
            }
        }

        if (bestUav == null) {
            JOptionPane.showMessageDialog(null, "No UAV meets the requirements.");
        } else {
            JOptionPane.showMessageDialog(null, "Best UAV: name:" + bestUav.getName()+" / Operational Cost: "+bestUav.getOperationalCost()+" / Availability: "+bestUav.getAvailability());
        }
    }

    // Method to get the list of sensors on a UAV
    private void getlistOfSensors() {
        String uavName = JOptionPane.showInputDialog("Enter UAV name: ");
        String str = "";
        if (uavName == null || uavName.trim().isEmpty()) {
            return; // Exit if the user clicks "Cancel" or provides an empty name
        }

        Uav uav = findUav(uavName); // Find the UAV
        if (uav == null) {
            JOptionPane.showMessageDialog(null, "UAV not found.");
            return;
        }

        if(uav.getSensor1()!=null){
            str = str+uav.getSensor1().getType()+" sensor, Grade "+uav.getSensor1().getGrade()+", Quantity "+uav.getSensor1().getQuantity()+"\n";
        }
        if(uav.getSensor2()!=null){
            str = str+uav.getSensor2().getType()+" sensor, Grade "+uav.getSensor2().getGrade()+", Quantity "+uav.getSensor2().getQuantity()+"\n";
        }
        if(uav.getSensor3()!=null){
            str = str+uav.getSensor3().getType()+" sensor, Grade "+uav.getSensor3().getGrade()+", Quantity "+uav.getSensor3().getQuantity()+"\n";
        }
        if(str.equals("")){
            String message = "No Sensors on "+uav.getName();
            JOptionPane.showMessageDialog(null, message);//print error message if no sensors found
        }else{
            JOptionPane.showMessageDialog(null, str);//Print the sensors list on UAV
        }

    }

    // Method to get the list of UAVs with a specific sensor type
    private void getListOfUavsOnSensorType() {
        String type = JOptionPane.showInputDialog("Enter Sensor Type(Temperature, Pressure, Windspeed, Humidity): ");
        if (type == null || type.trim().isEmpty()) {
            return; // Exit if the user clicks "Cancel" or provides an empty type
        }

        while (!checkSensorType(type)) { // Validate sensor type
            type = JOptionPane.showInputDialog("Invalid sensor type. Type must be in(): Please try again(Temperature, Pressure, Windspeed, Humidity): ");
            if (type == null || type.trim().isEmpty()) {
                return; // Exit if the user clicks "Cancel" or provides an empty type
            }
        }

        String str = "";
        str = str+getListOfUavsOnSensorsType(uav1, type)+getListOfUavsOnSensorsType(uav2, type)+getListOfUavsOnSensorsType(uav3, type)+getListOfUavsOnSensorsType(uav4, type); //get List of all UAVs
        if(str.equals("")){
            JOptionPane.showMessageDialog(null, "Sensor Type Doesn't exists");//print error message if no sensor exists
        }else{
            JOptionPane.showMessageDialog(null, str);//print list of all UAV's
        }
    }
    //Support method purpose to get list of uavs based on sensor type
    private String getListOfUavsOnSensorsType(Uav uav, String type){
        String str = "";
        if(uav!=null){
            if(uav.getSensor1()!=null && type.equalsIgnoreCase(uav.getSensor1().getType())){
                str = str+uav.getSensor1().getType()+"Sensor is on "+uav.getName()+", Grade "+uav.getSensor1().getGrade()+", Quantity"+uav.getSensor1().getQuantity()+"\n";
            }if(uav.getSensor2()!=null && type.equalsIgnoreCase(uav.getSensor2().getType())){
                str = str+uav.getSensor2().getType()+"Sensor is on "+uav.getName()+", Grade "+uav.getSensor2().getGrade()+", Quantity"+uav.getSensor2().getQuantity()+"\n";
            }if(uav.getSensor3()!=null && type.equalsIgnoreCase(uav.getSensor3().getType())){
                str = str+uav.getSensor3().getType()+"Sensor is on "+uav.getName()+", Grade "+uav.getSensor3().getGrade()+", Quantity"+uav.getSensor3().getQuantity()+"\n";
            }
            return str;
        }
        return str;
    }

    // Method to check if a UAV name is valid and unique
    private boolean checkUavName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        if ((uav1 != null && uav1.getName().equalsIgnoreCase(name)) ||
                (uav2 != null && uav2.getName().equalsIgnoreCase(name)) ||
                (uav3 != null && uav3.getName().equalsIgnoreCase(name)) ||
                (uav4 != null && uav4.getName().equalsIgnoreCase(name))) {
            return false;
        }
        return true;
    }

    // Method to check if the operational cost is valid
    private boolean checkUavOperationalCost(double cost) {
        return cost > 0;
    }

    // Method to check if the availability is valid
    private boolean checkUavAvailability(int availability) {
        return availability >= 0 && availability <= 5;
    }

    // Method to check if the sensor type is valid
    private boolean checkSensorType(String type) {
        return type.equalsIgnoreCase("temperature") || type.equalsIgnoreCase("pressure") ||
                type.equalsIgnoreCase("windspeed") || type.equalsIgnoreCase("humidity");
    }

    // Method to check if the sensor grade is valid
    private boolean checkSensorGrade(int grade) {
        return grade >= 1 && grade <= 5;
    }

    // Method to check if the sensor quantity is valid
    private boolean checkSensorQuantity(int quantity) {
        return quantity > 0;
    }

    // Method to find a UAV by name
    private Uav findUav(String name) {
        if (uav1 != null && uav1.getName().equalsIgnoreCase(name)) {
            return uav1;
        }
        if (uav2 != null && uav2.getName().equalsIgnoreCase(name)) {
            return uav2;
        }
        if (uav3 != null && uav3.getName().equalsIgnoreCase(name)) {
            return uav3;
        }
        if (uav4 != null && uav4.getName().equalsIgnoreCase(name)) {
            return uav4;
        }
        return null;
    }
}